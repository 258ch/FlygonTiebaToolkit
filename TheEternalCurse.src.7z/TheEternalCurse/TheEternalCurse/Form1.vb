﻿Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Threading
Imports Sunisoft.IrisSkin
Imports TheEternalCurse.Utility

Public Class Form1

    Private Ori_ID As String
    Private Ori_PW As String
    Private BS As String
    Private RegTr As Thread
    Private SW_ID As StreamWriter
    Private UseEnter As Boolean = False
    'Private PrList As String()
    'Private TimeOut As Integer
    'Private ReUse As Integer

    Private ToTest As String()
    Private TestTimeout As Integer
    Private SucProxys As String
    Private EndCount As Integer

    Private Skin As SkinEngine


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub OutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OutButton.Click
        If SaveFileDialog1.ShowDialog = DialogResult.OK Then
            Dim sw As New StreamWriter(SaveFileDialog1.FileName, False, Encoding.Default)
            sw.Write(SucTextBox.Text)
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导出完毕！")
        End If
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        If MsgBox("真的要清空么？", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            SucTextBox.Clear()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已清空。")
        End If
    End Sub

    Private Sub SeizeProxy()
        Try
            ProxyTextBox.Clear()
            Dim wc As New WizardHTTP
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://proxy.ipcn.org/proxylist.html")
            Dim re As New Regex("\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}.\d{2,5}")
            Dim rms As MatchCollection = re.Matches(retstr)
            For Each rm As Match In rms
                ProxyTextBox.AppendText(rm.Value + vbCrLf)
            Next
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            Exit Sub
        End Try
        SeizeButton.Enabled = True
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            Ori_ID = IDTextBox.Text
            Ori_PW = PWTextBox.Text

            If Ori_ID = "" Or Ori_PW = "" Then
                Throw New Exception("请填写用户名和密码！")
            End If
            '初始化代理
            'PrList = ProxyTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
            'TimeOut = TimeoutNumeric.Value
            'Reuse = ReUseNumeric.Value
            SW_ID = New StreamWriter(Directory.GetCurrentDirectory() + "\成功区.txt", True, Encoding.Default)
            SW_ID.AutoFlush = True

            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "注册开始...")
            RegTr = New Thread(AddressOf Reg)
            RegTr.Start()
            BSTextBox.Enabled = True
            CheckButton.Enabled = False
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub Reg()
        'Dim i_Pr As Integer = -1
        'If PrList.Length <> 0 Then i_Pr = 0
        Dim jam As New Jammer()
        Dim re As New Regex("JSESSIONID=.{12}")
        Dim wc As New WizardHTTP
        wc.Encoding = Encoding.UTF8

        While True
            Try
                Dim un As String = jam.Jammer(Ori_ID)
                Dim pw As String = jam.Jammer(Ori_PW)
                wc.Headers.Remove(HttpRequestHeader.Cookie)
                wc.Headers.Remove(HttpRequestHeader.Referer)

                '获取验证码
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://fmail.21cn.com/freeinterface/jsp/register/reg_moblie.htm")
                Dim left As Integer = retstr.IndexOf("token=") + 6
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim token As String = retstr.Substring(left, right - left)

                wc.SetDefaultHeader()
                Dim picdata As Byte() = wc.DownloadData("http://fmail.21cn.com/freeinterface/ValidateCodeServlet?token=" + token)
                Dim rm As Match = re.Match(wc.ResponseHeaders.Get("Set-Cookie"))
                Dim jsession As String = rm.Value
                Dim pic As Image = Image.FromStream(New MemoryStream(picdata))
                BSPictureBox.Image = pic
                BS = ""
                While BS = "" : Thread.Sleep(200) : End While

                '注册
                Dim poststr As String = "refererUrl=&returnUrl=%2Findex.jsp&friendemail=null&userName=" _
                                        + un + "&passwd=" + pw + "&confirmPasswd=" + pw + "&verifyCode=" + BS _
                                        + "&captchaToken=" + token + "&agree2=y"
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Cookie, jsession + "; path=/")
                wc.Headers.Set(HttpRequestHeader.Referer, "http://fmail.21cn.com/freeinterface/jsp/register/reg_moblie.htm")
                'If i_Pr <> -1 Then
                '    wc.Proxy = New WebProxy(PrList(i_Pr))
                'End If
                retstr = wc.UploadString("http://fmail.21cn.com/freeinterface/jsp/register/registerFormCommon.jsp", poststr)
                left = retstr.IndexOf("alert(") + 7
                right = retstr.IndexOf("'", left)
                Dim msg As String = retstr.Substring(left, right - left)

                If msg.IndexOf("注册成功") <> -1 Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + un + " 注册成功！")
                    Dim tmpid As String = un + "@21cn.com"
                    SucTextBox.AppendText(tmpid + ":" + pw + vbCrLf)
                    SW_ID.WriteLine(tmpid + ":" + pw)
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + un + " 注册失败！" + msg)
                    'If i_Pr <> -1 Then i_Pr = TheNext(i_Pr, 1, PrList.Length) '换代理
                End If
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
                'If i_Pr <> -1 Then i_Pr = TheNext(i_Pr, 1, PrList.Length) '换代理
            End Try
        End While
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        RegTr.Abort()
        SW_ID.Close()
        BSPictureBox.Image = Nothing
        BSTextBox.Text = ""
        CheckButton.Enabled = True
        BSTextBox.Enabled = False
        StartButton.Enabled = True
        StopButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已停止...")
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Sub CheckButton_OnStart()
        If ProxyTextBox.Text = "" Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "无待检测代理！")
            Exit Sub
        End If
        ToTest = ProxyTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
        ProgressBar1.Maximum = ToTest.Length
        ProgressBar1.Value = 0
        TestTimeout = TimeoutNumeric.Value
        EndCount = 10
        SucProxys = ""
        
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "开始检测...")
        Dim tr As New Thread(AddressOf TestInit)
        tr.Start()
        SeizeButton.Visible = False
        CheckButton.Text = "停止"
    End Sub

    Private Sub CheckButton_OnStop()
        
        TestEnd()
    End Sub

    Private Sub CheckButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckButton.Click
        If CheckButton.Text = "检测" Then
            CheckButton_OnStart()
        Else
            CheckButton_OnStop()
        End If
    End Sub

    Private Sub TestInit()
        Dim tr(10 - 1) As Thread

        For i As Integer = 0 To 9
            tr(i) = New Thread(AddressOf TestProxy)
            tr(i).Start(i)
        Next

        While EndCount <> 0 : Thread.Sleep(200) : End While
        For i As Integer = 0 To 9
            tr(i).Abort()
        Next

        TestEnd()
    End Sub

    Private Sub TestProxy(ByVal index As Integer)
        For i As Integer = index To ToTest.Length - 1 Step 10
            Try
                ProgressBar1.PerformStep()
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                wc.Proxy = New WebProxy(ToTest(i))
                wc.TimeOut = TestTimeout
                wc.ReadWriteTimeOut = TestTimeout
                Dim retstr = wc.DownloadString("http://tieba.baidu.com/dc/common/tbs")
                If InStr(retstr, "tbs") <> 0 Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + ToTest(i) + " 检测成功！")
                    SucProxys += ToTest(i) + vbCrLf
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + ToTest(i) + " 检测失败！")
                End If
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ToTest(i) + " " + ex.Message)
            End Try
        Next
        Interlocked.Decrement(EndCount)
    End Sub

    Private Sub TestEnd()
        CheckButton.Text = "检测"
        ProxyTextBox.Text = SucProxys
        SeizeButton.Visible = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已结束。")
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        Skin = New SkinEngine(Me, New MemoryStream(My.Resources.Calmness))
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub BSTextBox_TextChanged(sender As System.Object, e As System.EventArgs) Handles BSTextBox.TextChanged
        If Not UseEnter And BSTextBox.TextLength = 6 Then
            BS = BSTextBox.Text
            BSTextBox.Text = ""
            BSPictureBox.Image = Nothing
        End If
    End Sub

    Private Sub SeizeButton_Click(sender As System.Object, e As System.EventArgs) Handles SeizeButton.Click
        SeizeButton.Enabled = False
        Dim tr As New Thread(AddressOf SeizeProxy)
        tr.Start()
    End Sub

    Private Sub EnterCheckBox_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles EnterCheckBox.CheckedChanged
        UseEnter = EnterCheckBox.Checked
    End Sub

    Private Sub BSTextBox_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles BSTextBox.KeyPress
        If e.KeyChar = ChrW(13) Then
            If BSTextBox.Text = "" Then
                BS = "jump"
            Else
                BS = BSTextBox.Text
            End If
            BSTextBox.Text = ""
            BSPictureBox.Image = Nothing
        End If
    End Sub
End Class
