﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ReUseNumeric = New System.Windows.Forms.NumericUpDown()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TimeoutNumeric = New System.Windows.Forms.NumericUpDown()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BSTextBox = New System.Windows.Forms.TextBox()
        Me.BSPictureBox = New System.Windows.Forms.PictureBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.OutButton = New System.Windows.Forms.Button()
        Me.SucTextBox = New System.Windows.Forms.TextBox()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.CheckButton = New System.Windows.Forms.Button()
        Me.ProxyTextBox = New System.Windows.Forms.TextBox()
        Me.SeizeButton = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.EnterCheckBox = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.ReUseNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.ReUseNumeric)
        Me.GroupBox1.Controls.Add(Me.LinkLabel2)
        Me.GroupBox1.Controls.Add(Me.LinkLabel1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.TimeoutNumeric)
        Me.GroupBox1.Controls.Add(Me.PWTextBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.IDTextBox)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 160)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 12)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "代理复用"
        '
        'ReUseNumeric
        '
        Me.ReUseNumeric.Enabled = False
        Me.ReUseNumeric.Location = New System.Drawing.Point(66, 112)
        Me.ReUseNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.ReUseNumeric.Name = "ReUseNumeric"
        Me.ReUseNumeric.Size = New System.Drawing.Size(128, 21)
        Me.ReUseNumeric.TabIndex = 12
        Me.ReUseNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(82, 0)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 11
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "联系作者"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(141, 0)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 2
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "获取更新"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 87)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "超时(ms)"
        '
        'TimeoutNumeric
        '
        Me.TimeoutNumeric.Enabled = False
        Me.TimeoutNumeric.Location = New System.Drawing.Point(66, 85)
        Me.TimeoutNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.TimeoutNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TimeoutNumeric.Name = "TimeoutNumeric"
        Me.TimeoutNumeric.Size = New System.Drawing.Size(128, 21)
        Me.TimeoutNumeric.TabIndex = 8
        Me.TimeoutNumeric.Value = New Decimal(New Integer() {4000, 0, 0, 0})
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(66, 58)
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.Size = New System.Drawing.Size(128, 21)
        Me.PWTextBox.TabIndex = 3
        Me.PWTextBox.Text = "%c%c%c%i%i%i"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "密码"
        '
        'IDTextBox
        '
        Me.IDTextBox.Location = New System.Drawing.Point(66, 31)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(128, 21)
        Me.IDTextBox.TabIndex = 1
        Me.IDTextBox.Text = "%c%c%c%c%i%i%i%i"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "用户名"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.EnterCheckBox)
        Me.GroupBox2.Controls.Add(Me.BSTextBox)
        Me.GroupBox2.Controls.Add(Me.BSPictureBox)
        Me.GroupBox2.Location = New System.Drawing.Point(218, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(199, 131)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "验证码"
        '
        'BSTextBox
        '
        Me.BSTextBox.Enabled = False
        Me.BSTextBox.Location = New System.Drawing.Point(6, 87)
        Me.BSTextBox.Name = "BSTextBox"
        Me.BSTextBox.Size = New System.Drawing.Size(187, 21)
        Me.BSTextBox.TabIndex = 1
        '
        'BSPictureBox
        '
        Me.BSPictureBox.BackColor = System.Drawing.SystemColors.Control
        Me.BSPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox.Location = New System.Drawing.Point(6, 31)
        Me.BSPictureBox.Name = "BSPictureBox"
        Me.BSPictureBox.Size = New System.Drawing.Size(187, 48)
        Me.BSPictureBox.TabIndex = 0
        Me.BSPictureBox.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ClearButton)
        Me.GroupBox3.Controls.Add(Me.OutButton)
        Me.GroupBox3.Controls.Add(Me.SucTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 178)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 180)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "成功区"
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(104, 151)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(92, 23)
        Me.ClearButton.TabIndex = 2
        Me.ClearButton.Text = "清空"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'OutButton
        '
        Me.OutButton.Location = New System.Drawing.Point(6, 151)
        Me.OutButton.Name = "OutButton"
        Me.OutButton.Size = New System.Drawing.Size(92, 23)
        Me.OutButton.TabIndex = 1
        Me.OutButton.Text = "导出"
        Me.OutButton.UseVisualStyleBackColor = True
        '
        'SucTextBox
        '
        Me.SucTextBox.BackColor = System.Drawing.Color.White
        Me.SucTextBox.Location = New System.Drawing.Point(6, 20)
        Me.SucTextBox.Multiline = True
        Me.SucTextBox.Name = "SucTextBox"
        Me.SucTextBox.ReadOnly = True
        Me.SucTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SucTextBox.Size = New System.Drawing.Size(188, 125)
        Me.SucTextBox.TabIndex = 0
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(218, 149)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(95, 23)
        Me.StartButton.TabIndex = 3
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(323, 149)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(95, 23)
        Me.StopButton.TabIndex = 4
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.CheckButton)
        Me.GroupBox4.Controls.Add(Me.ProxyTextBox)
        Me.GroupBox4.Controls.Add(Me.SeizeButton)
        Me.GroupBox4.Controls.Add(Me.ProgressBar1)
        Me.GroupBox4.Enabled = False
        Me.GroupBox4.Location = New System.Drawing.Point(218, 178)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(199, 180)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "代理（无需设置）"
        '
        'CheckButton
        '
        Me.CheckButton.Location = New System.Drawing.Point(104, 151)
        Me.CheckButton.Name = "CheckButton"
        Me.CheckButton.Size = New System.Drawing.Size(89, 23)
        Me.CheckButton.TabIndex = 3
        Me.CheckButton.Text = "检测"
        Me.CheckButton.UseVisualStyleBackColor = True
        '
        'ProxyTextBox
        '
        Me.ProxyTextBox.BackColor = System.Drawing.Color.White
        Me.ProxyTextBox.Location = New System.Drawing.Point(6, 20)
        Me.ProxyTextBox.Multiline = True
        Me.ProxyTextBox.Name = "ProxyTextBox"
        Me.ProxyTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.ProxyTextBox.Size = New System.Drawing.Size(187, 125)
        Me.ProxyTextBox.TabIndex = 1
        '
        'SeizeButton
        '
        Me.SeizeButton.Location = New System.Drawing.Point(6, 151)
        Me.SeizeButton.Name = "SeizeButton"
        Me.SeizeButton.Size = New System.Drawing.Size(89, 23)
        Me.SeizeButton.TabIndex = 2
        Me.SeizeButton.Text = "一键抓取"
        Me.SeizeButton.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(6, 151)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(89, 23)
        Me.ProgressBar1.Step = 1
        Me.ProgressBar1.TabIndex = 4
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "*.txt"
        Me.SaveFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'EnterCheckBox
        '
        Me.EnterCheckBox.AutoSize = True
        Me.EnterCheckBox.Location = New System.Drawing.Point(121, 0)
        Me.EnterCheckBox.Name = "EnterCheckBox"
        Me.EnterCheckBox.Size = New System.Drawing.Size(72, 16)
        Me.EnterCheckBox.TabIndex = 2
        Me.EnterCheckBox.Text = "回车提交"
        Me.EnterCheckBox.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(429, 370)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "永恒の诅咒·21CNMailRegister - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.ReUseNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents BSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BSPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents OutButton As System.Windows.Forms.Button
    Friend WithEvents SucTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckButton As System.Windows.Forms.Button
    Friend WithEvents SeizeButton As System.Windows.Forms.Button
    Friend WithEvents ProxyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TimeoutNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ReUseNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents EnterCheckBox As System.Windows.Forms.CheckBox

End Class
