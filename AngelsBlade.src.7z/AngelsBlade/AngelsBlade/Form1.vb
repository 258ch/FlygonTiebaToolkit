﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports AngelsBlade.Utility
Imports SkinSharp

Public Class Form1

    Private IDList As New List(Of ID)
    Private ListOccupy As Boolean = False
    Private TB As String
    Private SPage As Integer
    Private EPage As Integer
    Private Delay As Integer
    Private NdStop As Boolean
    Private TrNum As Integer
    Private Ori_Co As String
    Private EndCount As Integer
    Private Skin As SkinH_Net

    Private Sub ChooseButton_Click(sender As System.Object, e As System.EventArgs) Handles MJChsButton.Click
        If ListOccupy Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("请等待其他任务结束！")
            Exit Sub
        End If
        If MJOpenFileDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            MJTextBox.Text = MJOpenFileDialog.FileName
            IDList.Clear()
            Dim tmp As String() = File.ReadAllLines(MJOpenFileDialog.FileName, Encoding.Default)
            For Each x As String In tmp
                Dim left As Integer = x.IndexOf(",")
                If left = -1 Then Continue For
                Dim un As String = x.Substring(1, left - 1)
                If un = "" Then Continue For
                left += 1
                Dim right As Integer = x.IndexOf(")", left)
                If right = -1 Then Continue For
                Dim pw As String = x.Substring(left, right - left)
                right += 2
                Dim cookie As String = x.Substring(right, x.Length - 1 - right)
                Dim tmpid As New ID With {.UN = un, .PW = pw, .Cookie = cookie}
                IDList.Add(tmpid)
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导入完毕，共导入{0}个马甲！", IDList.Count)
        End If
    End Sub

    Private Sub StartButton_Click(sender As System.Object, e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If ListOccupy Then Throw New Exception("请等待其他任务结束！")
            If IDList.Count = 0 Then Throw New Exception("请先选择马甲！")

            TB = TBTextBox.Text
            If TB = "" Then Throw New Exception("请填写贴吧！")
            SPage = SPNumeric.Value
            EPage = EPNumeric.Value
            If SPage > EPage Then Throw New Exception("起始页数应小于等于终止页数！")

            Ori_Co = CoTextBox.Text
            If Ori_Co = "" Then Throw New Exception("请填写内容！")
            Delay = DelayNumeric.Value
            TrNum = TrNumeric.Value
            EndCount = TrNum
            NdStop = False

            Dim tr As New Thread(AddressOf SendInit)
            tr.Start()
            ListOccupy = True
            EndButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub SendInit()
        For i As Integer = 0 To TrNum - 1
            Dim tr As New Thread(AddressOf SendMsg)
            tr.Start(i)
        Next

        While EndCount <> 0 : Thread.Sleep(200) : End While
        SendEnd()
    End Sub

    Private Sub SendMsg(ByVal index As Integer)
        Dim kw_gbk As String = URLEncoding(TB, Encoding.Default)
        Dim i_id As Integer = TheNext(index, 0, IDList.Count)
        Dim wc As New WizardHTTP
        Dim re_cookie As New Regex("BDUSS=.{192}")
        Dim jam As New Jammer(Environment.TickCount + index)
        For i As Integer = SPage + index To EPage Step TrNum
            Try : If NdStop Then Exit For
                Dim list As List(Of String) = GetUNList(wc, kw_gbk, i)
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "第" + i.ToString() + "页会员获取完毕...")
                For Each tar_un As String In list
                    Try : If NdStop Then Exit For
                        Dim tmp_id = IDList(i_id)
                        Dim rm_cookie = re_cookie.Match(tmp_id.Cookie)
                        If Not rm_cookie.Success Then Throw New Exception("Cookie格式错误！")
                        tmp_id.Cookie = rm_cookie.Value

                        wc.SetDefaultHeader()
                        Dim retstr = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoding(tar_un, Encoding.Default))
                        Dim left As Integer = retstr.IndexOf("creator"":{""id")
                        left += 15
                        Dim right As Integer = retstr.IndexOf(",", left)
                        Dim com_id As String = retstr.Substring(left, right - left)

                        wc.SetDefaultHeader()
                        retstr = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoding(tmp_id.UN, Encoding.Default))
                        left = retstr.IndexOf("creator"":{""id")
                        left += 15
                        right = retstr.IndexOf(",", left)
                        Dim user_id As String = retstr.Substring(left, right - left)

                        Dim content As String = jam.Jammer(Ori_Co)
                        wc.SetDefaultHeader(True)
                        Dim cid As String = GetStampMobile(True)
                        Dim poststr As String = tmp_id.Cookie + "&_client_id=" + cid + _
                                                "&_client_type=2&_client_version=5.2.2&_phone_imei=000000000000000&com_id=" + _
                                                com_id + "&content=" + content + _
                                                "&from=baidu_appstore&last_msg_id=0&net_type=1&user_id=" + user_id
                        Dim sign As String = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                        poststr = tmp_id.Cookie + "&_client_id=" + cid + _
                                  "&_client_type=2&_client_version=5.2.2&_phone_imei=000000000000000&com_id=" + _
                                  com_id + "&content=" + URLEncoding(content, Encoding.UTF8) + _
                                  "&from=baidu_appstore&last_msg_id=0&net_type=1&user_id=" + user_id + "&sign=" + sign
                        retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/addmsg", poststr)

                        left = retstr.IndexOf("error_code")
                        left += 13
                        right = retstr.IndexOf("""", left)
                        Dim errno As String = retstr.Substring(left, right - left)

                        If (errno = "0") Then
                            left = retstr.IndexOf("errno")
                            left += 8
                            right = retstr.IndexOf("""", left)
                            errno = retstr.Substring(left, right - left)
                            If (errno = "0") Then
                                Console.ForegroundColor = ConsoleColor.Green
                                Console.WriteLine(Time() + tmp_id.UN + " -> " + tar_un + " 发送成功！")
                            Else
                                left = retstr.IndexOf("usermsg")
                                left += 10
                                right = retstr.IndexOf("""", left)
                                Dim errmsg As String = retstr.Substring(left, right - left)
                                Console.ForegroundColor = ConsoleColor.Red
                                Console.WriteLine(Time() + tmp_id.UN + " -> " + tar_un + _
                                                  " 发送失败！错误信息：" + UnicodeDeco(errmsg))
                            End If
                        Else
                            left = retstr.IndexOf("error_msg")
                            left += 12
                            right = retstr.IndexOf("""", left)
                            Dim errmsg As String = retstr.Substring(left, right - left)
                            Console.ForegroundColor = ConsoleColor.Red
                            Console.WriteLine(Time() + tmp_id.UN + " -> " + tar_un + _
                                              " 发送失败！错误信息：" + UnicodeDeco(errmsg))
                        End If

                        i_id = TheNext(i_id, TrNum, IDList.Count)
                        Thread.Sleep(Delay)
                    Catch e As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + e.Message)
                    End Try
                Next
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        Interlocked.Decrement(EndCount)
    End Sub

    Private Sub SendEnd()
        ListOccupy = False
        StartButton.Enabled = True
        EndButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "发送完毕！")
    End Sub

    Private Function GetUNList(ByVal wc As WizardHTTP, ByVal kw_gbk As String, _
                               ByVal pg As Integer) As List(Of String)
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/furank?kw=" + _
                                                 kw_gbk + "&pn=" + pg.ToString())
        Dim left As Integer = 0
        Dim list As New List(Of String)
        While True
            left = retstr.IndexOf("username=""", left)
            If left = -1 Then Exit While
            left = retstr.IndexOf(">", left) + 1
            Dim right As Integer = retstr.IndexOf("</", left)
            If right = -1 Then Exit While
            Dim un As String = retstr.Substring(left, right - left)
            list.Add(un)
            left = right
        End While
        Return list
    End Function

    Private Sub EndButton_Click(sender As System.Object, e As System.EventArgs) Handles EndButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "任务正在中止，请等待当前线程结束！")
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        Skin = New SkinH_Net()
        Skin.AttachRes(My.Resources.黑色流光, My.Resources.黑色流光.Length, "", 0, 0, 0)
        Skin.SetAero(1)

        'load data
        If File.Exists(Directory.GetCurrentDirectory() + "\content.dat") Then
            CoTextBox.Text = File.ReadAllText(Directory.GetCurrentDirectory() + "\content.dat", Encoding.Default)
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        'save data
        File.WriteAllText(Directory.GetCurrentDirectory() + "\content.dat", CoTextBox.Text, Encoding.Default)

        End
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub
End Class
