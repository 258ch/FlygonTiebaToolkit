﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MJTextBox = New System.Windows.Forms.TextBox()
        Me.MJChsButton = New System.Windows.Forms.Button()
        Me.TBTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SPNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.EPNumeric = New System.Windows.Forms.NumericUpDown()
        Me.CoTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.EndButton = New System.Windows.Forms.Button()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.MJOpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SPNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "马甲"
        '
        'MJTextBox
        '
        Me.MJTextBox.BackColor = System.Drawing.Color.White
        Me.MJTextBox.Location = New System.Drawing.Point(64, 17)
        Me.MJTextBox.Name = "MJTextBox"
        Me.MJTextBox.ReadOnly = True
        Me.MJTextBox.Size = New System.Drawing.Size(241, 21)
        Me.MJTextBox.TabIndex = 1
        '
        'MJChsButton
        '
        Me.MJChsButton.Location = New System.Drawing.Point(311, 16)
        Me.MJChsButton.Name = "MJChsButton"
        Me.MJChsButton.Size = New System.Drawing.Size(54, 23)
        Me.MJChsButton.TabIndex = 2
        Me.MJChsButton.Text = "选择"
        Me.MJChsButton.UseVisualStyleBackColor = True
        '
        'TBTextBox
        '
        Me.TBTextBox.Location = New System.Drawing.Point(64, 44)
        Me.TBTextBox.Name = "TBTextBox"
        Me.TBTextBox.Size = New System.Drawing.Size(108, 21)
        Me.TBTextBox.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "贴吧"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(257, 44)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(108, 21)
        Me.DelayNumeric.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(198, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "间隔(ms)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "页数"
        '
        'SPNumeric
        '
        Me.SPNumeric.Location = New System.Drawing.Point(64, 71)
        Me.SPNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.SPNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.SPNumeric.Name = "SPNumeric"
        Me.SPNumeric.Size = New System.Drawing.Size(51, 21)
        Me.SPNumeric.TabIndex = 7
        Me.SPNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(198, 74)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 12)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "线程"
        '
        'EPNumeric
        '
        Me.EPNumeric.Location = New System.Drawing.Point(121, 71)
        Me.EPNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.EPNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.EPNumeric.Name = "EPNumeric"
        Me.EPNumeric.Size = New System.Drawing.Size(51, 21)
        Me.EPNumeric.TabIndex = 9
        Me.EPNumeric.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'CoTextBox
        '
        Me.CoTextBox.Location = New System.Drawing.Point(64, 98)
        Me.CoTextBox.Name = "CoTextBox"
        Me.CoTextBox.Size = New System.Drawing.Size(301, 21)
        Me.CoTextBox.TabIndex = 12
        Me.CoTextBox.Text = "贴吧工具|刷粉刷经验盖楼召唤|尽在苍海国际|www.258ch.com|%i%i%i%c%c%c"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 101)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 12)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "内容"
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(159, 125)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(100, 23)
        Me.StartButton.TabIndex = 13
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'EndButton
        '
        Me.EndButton.Enabled = False
        Me.EndButton.Location = New System.Drawing.Point(265, 125)
        Me.EndButton.Name = "EndButton"
        Me.EndButton.Size = New System.Drawing.Size(100, 23)
        Me.EndButton.TabIndex = 14
        Me.EndButton.Text = "停止"
        Me.EndButton.UseVisualStyleBackColor = True
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(257, 71)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(108, 21)
        Me.TrNumeric.TabIndex = 15
        Me.TrNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'MJOpenFileDialog
        '
        Me.MJOpenFileDialog.DefaultExt = "icid"
        Me.MJOpenFileDialog.FileName = "OpenFileDialog1"
        Me.MJOpenFileDialog.Filter = "数据文件(*.icid)|*.icid"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(17, 130)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 23
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "联系作者"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(76, 130)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 24
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "获取更新"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(387, 165)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.TrNumeric)
        Me.Controls.Add(Me.EndButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.CoTextBox)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.EPNumeric)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.SPNumeric)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DelayNumeric)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TBTextBox)
        Me.Controls.Add(Me.MJChsButton)
        Me.Controls.Add(Me.MJTextBox)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "天使之刃·消息群发机高级版 - 飞龙"
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SPNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MJTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MJChsButton As System.Windows.Forms.Button
    Friend WithEvents TBTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SPNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents EPNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents CoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents EndButton As System.Windows.Forms.Button
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents MJOpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel

End Class
