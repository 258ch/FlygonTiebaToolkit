﻿Imports DragonDepth.MyFunctions
Imports System.Threading

Public Class BSForm

    Public Shared NdShowBS As Boolean = False
    Public Shared NdHide As Boolean = False

    Private EnterSub As Boolean = False

    Public Sub DoWork()
        While True
            If BSForm.NdShowBS Then
                BSForm.NdShowBS = False
                ShowBS()
            End If
            If BSForm.NdHide Then
                BSForm.NdHide = False
                Clear()
                Me.Hide()
                Exit Sub
            End If
            Thread.Sleep(200)
        End While
    End Sub

    Private Sub ClearImg()
        BSPictureBox1.Image = Nothing
        BSPictureBox2.Image = Nothing
        BSPictureBox3.Image = Nothing
        BSPictureBox4.Image = Nothing
        BSPictureBox5.Image = Nothing
    End Sub

    Private Sub Clear()
        BSTextBox.Clear()
        ClearImg()
    End Sub

    Private Sub ShowBS()
        ClearImg()
        If Form1.BSQ.Count > 0 Then
            BSPictureBox1.Image = Form1.BSQ.Pic(0)
        End If
        If Form1.BSQ.Count > 1 Then
            BSPictureBox2.Image = Form1.BSQ.Pic(1)
        End If
        If Form1.BSQ.Count > 2 Then
            BSPictureBox3.Image = Form1.BSQ.Pic(2)
        End If
        If Form1.BSQ.Count > 3 Then
            BSPictureBox4.Image = Form1.BSQ.Pic(3)
        End If
        If Form1.BSQ.Count > 4 Then
            BSPictureBox5.Image = Form1.BSQ.Pic(4)
        End If
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 And Form1.BSQ.Count <> 0 And EnterSub = False Then
            Dim index As Integer = Form1.BSQ.InitialIndex
            Form1.BSQ.BS(index) = BSTextBox.Text
            BSTextBox.Clear()
            Form1.BSQ.Refresh() '刷新
            ShowBS() '显示
        End If
    End Sub

    Private Sub BSForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
    End Sub

    Private Sub TopCheckBox_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles TopCheckBox.CheckedChanged
        Me.TopMost = TopCheckBox.Checked
    End Sub

    Private Sub SubCheckBox_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles SubCheckBox.CheckedChanged
        EnterSub = SubCheckBox.Checked
    End Sub

    Private Sub BSTextBox_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles BSTextBox.KeyPress
        If e.KeyChar = Chr(13) And Form1.BSQ.Count <> 0 Then
            Dim index As Integer = Form1.BSQ.InitialIndex
            If BSTextBox.Text = "" Then : Form1.BSQ.BS(index) = "q"
            Else : Form1.BSQ.BS(index) = BSTextBox.Text : End If
            BSTextBox.Clear()
            Form1.BSQ.Refresh() '刷新
            ShowBS() '显示
        End If
    End Sub
End Class