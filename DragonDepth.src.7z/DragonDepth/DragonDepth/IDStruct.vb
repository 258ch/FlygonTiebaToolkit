﻿Public Structure ID
    Public UN As String
    Public PW As String
    Public Cookie As String
End Structure