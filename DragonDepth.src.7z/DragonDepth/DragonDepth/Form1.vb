﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports DragonDepth.MyFunctions

Public Class Form1

    'General
    Public Shared IDList As New List(Of ID)
    Public Shared PRList As New List(Of String)
    Public Shared TaskRunning As Boolean = False
    Public Shared BSQ As BSQueue

    Private CdsIndex As Integer
    Private TitleList(-1) As String
    Private CoList(-1) As String
    Private TBList(-1) As TBStruct
    Private TidList(-1) As String

    Private TBOrder As Integer
    Private TidOrder As Integer
    Private TitleOrder As Integer
    Private CoOrder As Integer
    Private IDOrder As Integer
    Private PrOrder As Integer

    Private Delay As Integer
    Private Timeout As Integer
    Private Reuse As Integer
    Private Way As Integer
    Private Anonymous As Boolean
    Private Anti As Boolean
    Private UsePr As Boolean

    Private BetterTr As Thread

    Public Const HTTP As Integer = 0
    Public Const WAP As Integer = 1
    Public Const IPHONE As Integer = 2
    Public Const ANDROID As Integer = 3
    Public Const RANDOM As Integer = 4

    Private BZTestTB As String

    Public Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal hProcess As Integer, ByVal dwMinimumWorkingSetSize As Integer, ByVal dwMaximumWorkingSetSize As Integer) As Integer

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        TitleComboBox.SelectedIndex = 0
        CoComboBox.SelectedIndex = 0
        TBComboBox.SelectedIndex = 0
        TidComboBox.SelectedIndex = 0
        WayComboBox.SelectedIndex = 0
        ModeComboBox.SelectedIndex = 0

        BetterTr = New Thread(AddressOf Bettermem)
        BetterTr.Start(BetterNumeric.Value)

        CdsIndex = AntiVcode.LoadCdsFromBuffer(My.Resources.baidutieba, My.Resources.baidutieba.Length)
    End Sub

    Private Sub Bettermem(ByVal delay As Integer)
        While True
            SetProcessWorkingSetSize(-1, -1, -1)
            Thread.Sleep(delay)
        End While
    End Sub

    Private Sub SetButton_Click(sender As System.Object, e As System.EventArgs) Handles SetButton.Click
        BetterTr.Abort()
        BetterTr = New Thread(AddressOf Bettermem)
        BetterTr.Start(BetterNumeric.Value)
    End Sub

    Private Sub SettingsInit()
        TBOrder = TBComboBox.SelectedIndex
        TidOrder = TidComboBox.SelectedIndex
        TitleOrder = TitleComboBox.SelectedIndex
        CoOrder = CoComboBox.SelectedIndex

        Delay = DelayNumeric.Value
        Timeout = TimeoutNumeric.Value
        Reuse = PrReuseNumeric.Value
        Way = WayComboBox.SelectedIndex
        Anonymous = AnonyCheckBox.Checked
        'UsePr = PrCheckBox.Checked
        Anti = AntiCheckBox.Checked
    End Sub

    Private Sub TitleInit()
        Dim count As Integer = TitleListView.Items.Count
        ReDim TitleList(count - 1)
        For i As Integer = 0 To count - 1
            TitleList(i) = TitleListView.Items(i).Text
        Next
    End Sub

    Private Sub CoInit()
        Dim count As Integer = CoListView.Items.Count
        ReDim CoList(count - 1)
        For i As Integer = 0 To count - 1
            CoList(i) = CoListView.Items(i).Text
        Next
    End Sub

    Private Sub TBInit()
        Dim count As Integer = TBListView.Items.Count
        ReDim TBList(count - 1)
        For i As Integer = 0 To count - 1
            Dim tmp As New TBStruct With {.TBName = TBListView.Items(i).Text, .Fid = TBListView.Items(i).SubItems(1).Text}
            TBList(i) = tmp
        Next
    End Sub

    Private Sub TidInit()
        Dim count As Integer = TidListView.Items.Count
        ReDim TidList(count - 1)
        For i As Integer = 0 To count - 1
            TidList(i) = TidListView.Items(i).Text
        Next
    End Sub

    Private Sub ToolStripStatusLabel2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel2.Click
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub ToolStripStatusLabel3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel3.Click
        Process.Start("http://www.yy.com/go.html#653238")
    End Sub

    Private Sub ToolStripStatusLabel4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel4.Click
        Process.Start("http://www.258ch.com/forum.php")
    End Sub

    Private Sub ToolStripStatusLabel1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel1.Click
        Dim tr As New Thread(AddressOf SaveData)
        tr.Start()
    End Sub

    Private Sub ToolStripStatusLabel5_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel5.Click
        SetProcessWorkingSetSize(-1, -1, -1)
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "优化完毕！")
    End Sub

    Private Sub id_LoadButton_Click(sender As System.Object, e As System.EventArgs) Handles id_LoadButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("请等待其他任务结束！")
            Exit Sub
        End If
        If id_OpenFileDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            id_TextBox.Text = id_OpenFileDialog.FileName
            IDList.Clear()
            Dim tmp As String() = File.ReadAllLines(id_OpenFileDialog.FileName, Encoding.Default)
            For Each x As String In tmp
                Dim left As Integer = x.IndexOf(",")
                If left = -1 Then Continue For
                Dim un As String = x.Substring(1, left - 1)
                If un = "" Then Continue For
                left += 1
                Dim right As Integer = x.IndexOf(")", left)
                If right = -1 Then Continue For
                Dim pw As String = x.Substring(left, right - left)
                right += 2
                Dim cookie As String = x.Substring(right, x.Length - 1 - right)
                Dim tmpid As New ID With {.UN = un, .PW = pw, .Cookie = cookie}
                IDList.Add(tmpid)
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导入完毕，共导入{0}个马甲！", IDList.Count)
        End If
    End Sub

    Private Sub id_CleanButton_Click(sender As System.Object, e As System.EventArgs) Handles id_CleanButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("请等待其他任务结束！")
            Exit Sub
        End If
        IDList.Clear()
        id_TextBox.Clear()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已清除")
    End Sub

    Private Sub pr_LoadButton_Click(sender As System.Object, e As System.EventArgs) Handles pr_LoadButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("请等待其他任务结束！")
            Exit Sub
        End If
        If pr_OpenFileDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            pr_TextBox.Text = pr_OpenFileDialog.FileName
            PRList.Clear()
            Dim tmp As String() = File.ReadAllLines(pr_OpenFileDialog.FileName, Encoding.Default)
            PRList.AddRange(tmp)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导入完毕，共导入{0}个代理！", PRList.Count)
        End If
    End Sub

    Private Sub pr_CleanButton_Click(sender As System.Object, e As System.EventArgs) Handles pr_CleanButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("请等待其他任务结束！")
            Exit Sub
        End If
        PRList.Clear()
        pr_TextBox.Clear()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已清除")
    End Sub

    Private Function GetVcodeFromBSQ(ByVal picdata As Byte(), ByVal index As Integer) As String
        Dim pic As Image = Image.FromStream(New MemoryStream(picdata))
        Dim bsqi As New BSQItem With {.index = index, .pic = pic}
        Form1.BSQ.Add(bsqi)
        BSForm.NdShowBS = True
        Form1.BSQ.BS(index) = ""
        While Form1.BSQ.BS(index) = ""
            Thread.Sleep(200)
        End While
        Return Form1.BSQ.BS(index)
    End Function

    Private Function GetVcodeFromAnti(ByVal picdata As Byte()) As String
        Dim bsdata(64 - 1) As Byte
        AntiVcode.GetVcodeFromBuffer(CdsIndex, picdata, picdata.Length, bsdata)
        Dim bs As String = Encoding.Default.GetString(bsdata).Replace(Chr(0), "")
        Return bs
    End Function

    Private Sub SaveData()

        Dim sw As New StreamWriter(Directory.GetCurrentDirectory() + "\title.dat", False, Encoding.Default)
        For Each x As ListViewItem In TitleListView.Items
            sw.WriteLine(x.Text)
        Next
        sw.Close()

        sw = New StreamWriter(Directory.GetCurrentDirectory() + "\content.dat", False, Encoding.Default)
        For Each x As ListViewItem In CoListView.Items
            sw.WriteLine(x.Text)
        Next
        sw.Close()

        sw = New StreamWriter(Directory.GetCurrentDirectory() + "\tb.dat", False, Encoding.Default)
        For Each x As ListViewItem In TBListView.Items
            sw.WriteLine(x.Text + ":" + x.SubItems(1).Text)
        Next
        sw.Close()

        sw = New StreamWriter(Directory.GetCurrentDirectory() + "\tid.dat", False, Encoding.Default)
        For Each x As ListViewItem In TidListView.Items
            sw.WriteLine(x.Text)
        Next
        sw.Close()

        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已保存。")
    End Sub

    Private Sub LoadData()

        Dim filename As String = Directory.GetCurrentDirectory() + "\title.dat"
        If File.Exists(filename) Then
            Dim tmp As String() = File.ReadAllLines(filename, Encoding.Default)
            For Each x As String In tmp
                TitleListView.Items.Add(x)
            Next
        End If

        filename = Directory.GetCurrentDirectory() + "\content.dat"
        If File.Exists(filename) Then
            Dim tmp As String() = File.ReadAllLines(filename, Encoding.Default)
            For Each x As String In tmp
                CoListView.Items.Add(x)
            Next
        End If

        filename = Directory.GetCurrentDirectory() + "\tb.dat"
        If File.Exists(filename) Then
            Dim tmp As String() = File.ReadAllLines(filename, Encoding.Default)
            For Each x As String In tmp
                Dim tmp2 As String() = Split(x, ":")
                If tmp2.Length < 2 Then Continue For
                Dim item = TBListView.Items.Add(tmp2(0))
                item.SubItems.Add(tmp2(1))
            Next
        End If

        filename = Directory.GetCurrentDirectory() + "\tid.dat"
        If File.Exists(filename) Then
            Dim tmp As String() = File.ReadAllLines(filename, Encoding.Default)
            For Each x As String In tmp
                TidListView.Items.Add(x)
            Next
        End If

        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "信息加载完毕！")
    End Sub

    Private Sub Form1_FormClosed(sender As System.Object, e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        SaveData()
        End
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Private Sub AntiCheckBox_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles AntiCheckBox.CheckedChanged
        If AntiCheckBox.Checked Then
            If Not LoginForm.GTLv4 Then
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + "您的等级小于4，不能使用识别！")
                AntiCheckBox.Checked = False
            End If
        End If
    End Sub

    '主题菜单栏事件
    Private Sub TitleAddMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleAddMenuItem.Click
        Dim toadd As String = InputBox("请输入想添加的内容")
        If toadd <> "" Then TitleListView.Items.Add(toadd)
    End Sub

    Private Sub TitleDelMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleDelMenuItem.Click
        If TitleListView.SelectedItems.Count <> 0 Then
            For Each x As ListViewItem In TitleListView.SelectedItems
                TitleListView.Items.Remove(x)
            Next
        End If
    End Sub

    Private Sub TitleCopyMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleCopyMenuItem.Click
        If TitleListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In TitleListView.SelectedItems
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub TitleCopyAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleCopyAMenuItem.Click
        If TitleListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In TitleListView.Items
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub TitlePasteMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitlePasteMenuItem.Click
        Dim text As String() = Split(Clipboard.GetText, vbCrLf)
        For Each x As String In text
            If x <> "" Then TitleListView.Items.Add(x)
        Next
    End Sub

    Private Sub TitleDelAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleDelAMenuItem.Click
        TitleListView.Items.Clear()
    End Sub

    Private Sub TitleEditMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TitleEditMenuItem.Click
        If TitleListView.SelectedItems.Count <> 0 Then
            Dim toadd As String = InputBox("请输入想添加的内容", "", TitleListView.SelectedItems.Item(0).Text)
            If toadd <> "" Then TitleListView.SelectedItems.Item(0).Text = toadd
        End If
    End Sub

    '内容菜单栏事件
    Private Sub CoAddMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoAddMenuItem.Click
        Dim toadd As String = InputBox("请输入想添加的内容")
        If toadd <> "" Then CoListView.Items.Add(toadd)
    End Sub

    Private Sub CoEditMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoEditMenuItem.Click
        If CoListView.SelectedItems.Count <> 0 Then
            Dim toadd As String = InputBox("请输入想添加的内容", "", CoListView.SelectedItems.Item(0).Text)
            If toadd <> "" Then CoListView.SelectedItems.Item(0).Text = toadd
        End If
    End Sub

    Private Sub CoDelMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoDelMenuItem.Click
        If CoListView.SelectedItems.Count <> 0 Then
            For Each x As ListViewItem In CoListView.SelectedItems
                CoListView.Items.Remove(x)
            Next
        End If
    End Sub

    Private Sub CoCopyMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoCopyMenuItem.Click
        If CoListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In CoListView.SelectedItems
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub CoPasteMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoPasteMenuItem.Click
        Dim text As String() = Split(Clipboard.GetText, vbCrLf)
        For Each x As String In text
            If x <> "" Then CoListView.Items.Add(x)
        Next
    End Sub

    Private Sub CoCopyAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoCopyAMenuItem.Click
        If CoListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In CoListView.Items
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub CoDelAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CoDelAMenuItem.Click
        CoListView.Items.Clear()
    End Sub

    '帖子号菜单栏事件
    Private Sub TIDAddMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDAddMenuItem.Click
        Dim toadd As String = InputBox("请输入想添加的内容")
        If toadd <> "" Then TidListView.Items.Add(toadd)
    End Sub

    Private Sub TIDEditMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDEditMenuItem.Click
        If TidListView.SelectedItems.Count <> 0 Then
            Dim toadd As String = InputBox("请输入想添加的内容", "", TidListView.SelectedItems.Item(0).Text)
            If toadd <> "" Then TidListView.SelectedItems.Item(0).Text = toadd
        End If
    End Sub

    Private Sub TIDDelMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDDelMenuItem.Click
        If TidListView.SelectedItems.Count <> 0 Then
            For Each x As ListViewItem In TidListView.SelectedItems
                TidListView.Items.Remove(x)
            Next
        End If
    End Sub

    Private Sub TIDCopyMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDCopyMenuItem.Click
        If TidListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In TidListView.SelectedItems
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub TIDPasteMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDPasteMenuItem.Click
        Dim text As String() = Split(Clipboard.GetText, vbCrLf)
        For Each x As String In text
            If x <> "" Then TidListView.Items.Add(x)
        Next
    End Sub

    Private Sub TIDCopyAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDCopyAMenuItem.Click
        If TidListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In TidListView.Items
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub TIDDelAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TIDDelAMenuItem.Click
        TidListView.Items.Clear()
    End Sub

    '贴吧菜单栏事件
    Private Sub TBAddMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBAddMenuItem.Click
        Dim toadd As String = InputBox("请输入想添加的内容")
        If toadd <> "" Then
            Dim index = TBListView.Items.Add(toadd)
            Dim fid As String = GetFid(toadd)
            If fid = "" Then Exit Sub
            index.SubItems.Add(fid)
        End If
    End Sub

    Private Sub TBEditMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBEditMenuItem.Click
        If TBListView.SelectedItems.Count <> 0 Then
            Dim toadd As String = InputBox("请输入想添加的内容", "", TBListView.SelectedItems.Item(0).Text)
            If toadd <> "" Then
                Dim index = TBListView.SelectedItems.Item(0)
                index.Text = toadd
                Dim fid As String = GetFid(toadd)
                If fid = "" Then Exit Sub
                If index.SubItems.Count = 1 Then
                    index.SubItems.Add(fid)
                Else
                    index.SubItems.Item(1).Text = fid
                End If
            End If
        End If
    End Sub

    Private Sub TBDelMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBDelMenuItem.Click
        If TBListView.SelectedItems.Count <> 0 Then
            For Each x As ListViewItem In TBListView.SelectedItems
                TBListView.Items.Remove(x)
            Next
        End If
    End Sub

    Private Sub TBCopyMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBCopyMenuItem.Click
        If TBListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In TBListView.SelectedItems
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub TBPasteMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBPasteMenuItem.Click
        Exit Sub
        Dim text As String() = Split(Clipboard.GetText, vbCrLf)
        For Each x As String In text
            If x <> "" Then TBListView.Items.Add(x)
        Next
    End Sub

    Private Sub TBCopyAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBCopyAMenuItem.Click
        If TBListView.SelectedItems.Count <> 0 Then
            Dim text As String = ""
            For Each x As ListViewItem In TBListView.Items
                text += x.Text + vbCrLf
            Next
            Clipboard.SetText(text)
        End If
    End Sub

    Private Sub TBDelAMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBDelAMenuItem.Click
        TBListView.Items.Clear()
    End Sub

    Private Sub TBFidMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TBFidMenuItem.Click
        If TBListView.SelectedItems.Count <> 0 Then
            Dim index = TBListView.SelectedItems.Item(0)
            Dim fid As String = GetFid(index.Text)
            If fid = "" Then Exit Sub
            If index.SubItems.Count = 1 Then
                index.SubItems.Add(fid)
            Else
                index.SubItems.Item(1).Text = fid
            End If
        End If
    End Sub

    Private Sub StartButton_Click(sender As System.Object, e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False

            If TaskRunning Then Throw New Exception("请先结束其他任务！")
            If IDList.Count = 0 Then
                TabControl1.SelectedIndex = 1
                Throw New Exception("请先选择马甲！")
            End If
            UsePr = PrCheckBox.Checked
            If UsePr And PRList.Count = 0 Then
                TabControl1.SelectedIndex = 1
                Throw New Exception("请先选择代理！")
            End If
            If CoListView.Items.Count = 0 Then Throw New Exception("请填写回复内容！")
            CoInit()
            SettingsInit()

            Dim func As ParameterizedThreadStart
            Dim mode As Integer = ModeComboBox.SelectedIndex
            If mode = 0 Then '主题
                If TBListView.Items.Count = 0 Then Throw New Exception("请填写贴吧列表！")
                TBInit()
                If TitleListView.Items.Count = 0 Then Throw New Exception("请填写标题！")
                TitleInit()
                func = AddressOf PostTitleTr
            Else '回复
                If TidListView.Items.Count = 0 Then Throw New Exception("请填写帖子号！")
                TidInit()
                func = AddressOf PostReplyTr
            End If

            If Not Anti Then
                Dim tr As New Thread(AddressOf BSForm.DoWork)
                tr.Start()
                BSForm.Show()
            End If

            Dim trnum As Integer = TrNumeric.Value
            BSQ = New BSQueue(TrNumeric.Value)
            For i As Integer = 0 To trnum - 1
                BSQ.Tr(i) = New Thread(func)
                BSQ.Tr(i).Start(i)
            Next

            TaskRunning = True
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub PostTitleTr(ByVal index As Integer)
        Dim ran As New Random(Environment.TickCount + index)
        Dim i_id As Integer = TheNext(index, 0, IDList.Count)
        Dim i_pr As Integer = 0,
            sub_pr As Integer = 0
        If UsePr Then i_pr = TheNext(index, 0, PRList.Count)
        Dim i_title As Integer = 0
        If TitleOrder = 1 Then i_title = ran.Next(0, TitleList.Length - 1)
        Dim i_co As Integer = 0
        If CoOrder = 1 Then i_co = ran.Next(0, CoList.Length - 1)
        Dim i_tb As Integer = TheNext(index, 0, TBList.Length)
        If TBOrder = 1 Then i_tb = ran.Next(0, TBList.Length - 1)

        While True
            Try

                Dim jam As New Jammer(Environment.TickCount + index)
                Dim title As String = jam.Jammer(TitleList(i_title))
                Dim co As String = jam.Jammer(CoList(i_co))
                Dim tb As TBStruct = TBList(i_tb)
                If tb.Fid = "" Then
                    tb.Fid = GetFid(tb.TBName)
                    TBList(i_tb) = tb
                End If

                If Way = RANDOM Then '随机发帖
                    Dim j As Integer = ran.Next(1, 3)
                    If j = 1 Then : GoTo Label_HTTP
                    ElseIf j = 2 Then : GoTo Label_WAP
                    Else : GoTo Label_Client
                    End If
                ElseIf Way = HTTP Then 'HTTP发帖

Label_HTTP:         Dim wc As New WizardHTTP
                    wc.SetDefaultHeader()
                    wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                    Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/user/json_needvcode?rs1=0&rs10=1&lm=" + tb.Fid + "&word=" + URLEncoUTF8(tb.TBName))
                    Dim ndvcode As String = GetMid(retstr, "need"":", ",")

                    Dim vcode As String = "",
                        bs As String = ""
                    If ndvcode <> "0" Then
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        retstr = wc.DownloadString("http://tieba.baidu.com/f?ct=486539264&cm=59200&lm=" + tb.Fid + "&rs1=0&rs10=1&word=&tn=jsonVcode")
                        vcode = GetMid(retstr, ":""", """")
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("http://tieba.baidu.com/cgi-bin/genimg?" + vcode)
                        If Anti Then
                            bs = GetVcodeFromAnti(picdata)
                        Else
                            bs = GetVcodeFromBSQ(picdata, index)
                        End If
                    End If

                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                    wc.TimeOut = Timeout
                    wc.ReadWriteTimeOut = Timeout
                    If UsePr Then wc.Proxy = New WebProxy(PRList(i_pr))
                    Dim tbs As String = GetTbs(IDList(i_id).Cookie)
                    Dim poststr As String = "kw=" + URLEncoUTF8(tb.TBName) + "&fid=" + tb.Fid + "&tid=0&floor_num=0&vcode_md5=" + vcode + "&vcode=" + URLEncoUTF8(bs) + "&tbs=" + tbs + "&pic_url=&rich_text=1&title=" + URLEncoUTF8(title) + "&add_post_submit=%20%E5%8F%91%20%E8%A1%A8%20&content=" + URLEncoUTF8(co) + IIf(Anonymous, "&anonymous=1", "") + "&useSignName=off&ie=utf-8"
                    retstr = wc.UploadString("http://tieba.baidu.com/f/commit/thread/add", poststr)
                    Dim errno As String = GetMid(retstr, ":", ",")
                    If errno = "0" Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + tb.TBName + "吧 发帖成功！")
                    Else
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + tb.TBName + "吧 发帖失败！错误信息：" + errno)
                    End If

                ElseIf Way = WAP Then 'WAP发帖

Label_WAP:          Dim tbs As String = GetTbs(IDList(i_id).Cookie)
                    Dim poststr As String = "word1=&tbs=" + tbs + "&word=" + URLEncoUTF8(tb.TBName) + "&src=2&bs=&fid=" + tb.Fid + "&ti=" + URLEncoUTF8(title) + "&co=" + URLEncoUTF8(co) + "&tn=baiduWiseSubmit&ifpost=1&ifposta=1&post_info=0&verify=&verify_2=&cip=&pinf=1_2_0&vcode=&rlpn=&pic_info=&sub1=" + IIf(Anonymous, "%E5%8F%91%E8%A1%A8%E8%B4%B4%E5%AD%90", "%E5%8C%BF%E5%90%8D%E5%8F%91%E8%B4%B4")
                    Dim wc As New WizardHTTP
                    wc.SetDefaultHeader()
                    wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                    wc.Headers.Set(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; sdk Build/GRI34) UC AppleWebKit/534.31 (KHTML, like Gecko) Mobile Safari/534.31")
                    wc.Encoding = Encoding.UTF8
                    wc.TimeOut = Timeout
                    wc.ReadWriteTimeOut = Timeout
                    If UsePr Then wc.Proxy = New WebProxy(PRList(i_pr))
                    Dim retstr As String = wc.UploadString("http://wapp.baidu.com/f/q-0-0-wiaui_1332050392_2155-sz%40224_220%2C-1-1-0/m", poststr)
                    Dim left As Integer = retstr.IndexOf("genimg?")
                    If left <> -1 Then
                        left += 7
                        Dim right As Integer = retstr.IndexOf("""", left)
                        Dim vcode As String = retstr.Substring(left, right - left)
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("http://tieba.baidu.com/cgi-bin/genimg?" + vcode)
                        Dim bs As String
                        If Anti Then
                            bs = GetVcodeFromAnti(picdata)
                        Else
                            bs = GetVcodeFromBSQ(picdata, index)
                        End If
                        tbs = GetTbs(IDList(i_id).Cookie)
                        poststr = poststr = "word1=" + URLEncoUTF8(bs) + "&tbs=" + tbs + "&word=" + URLEncoUTF8(tb.TBName) + "&src=2&bs=" + vcode + "&fid=" + tb.Fid + "&ti=" + URLEncoUTF8(title) + "&co=" + URLEncoUTF8(co) + "&tn=baiduWiseSubmit&ifpost=1&ifposta=1&post_info=0&verify=&verify_2=&cip=&pinf=1_2_0&vcode=&rlpn=&pic_info=&sub1=" + IIf(Anonymous, "%E5%8F%91%E8%A1%A8%E8%B4%B4%E5%AD%90", "%E5%8C%BF%E5%90%8D%E5%8F%91%E8%B4%B4")
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                        wc.Headers.Set(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; sdk Build/GRI34) UC AppleWebKit/534.31 (KHTML, like Gecko) Mobile Safari/534.31")
                        wc.Encoding = Encoding.UTF8
                        wc.TimeOut = Timeout
                        wc.ReadWriteTimeOut = Timeout
                        If UsePr Then wc.Proxy = New WebProxy(PRList(i_pr))
                        retstr = wc.UploadString("http://wapp.baidu.com/f/q-0-0-wiaui_1332050392_2155-sz%40224_220%2C-1-1-0/m", poststr)
                    End If
                    If retstr.IndexOf("发帖成功") <> -1 Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + tb.TBName + "吧 发帖成功！")
                    Else
                        Dim err As String = GetMid(retstr, "light"">", "<")
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + tb.TBName + "吧 发帖失败！" + err)
                    End If

                Else '客户端发帖

Label_Client:       Dim clienttype As String = IIf(Way = IPHONE, "1", "2")
                    Dim cid As String = GetStampAndroid()
                    Dim tbs As String = GetTbs(IDList(i_id).Cookie)
                    Dim re As New Regex("BDUSS=.{192}")
                    Dim rm As Match = re.Match(IDList(i_id).Cookie)
                    If Not rm.Success Then Throw New Exception("Cookie格式不正确！")
                    Dim cookie As String = rm.Value
                    Dim poststr As String = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=" + IIf(Anonymous, "1", "0") + "&content=" + co + "&fid=" + tb.Fid + "&from=baidu_appstore&kw=" + tb.TBName + "&net_type=1&tbs=" + tbs + "&title=" + title
                    Dim sign As String = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                    poststr = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=" + IIf(Anonymous, "1", "0") + "&content=" + URLEncoUTF8(co) + "&fid=" + tb.Fid + "&from=baidu_appstore&kw=" + URLEncoUTF8(tb.TBName) + "&net_type=1&tbs=" + tbs + "&title=" + URLEncoUTF8(title) + "&sign=" + sign
                    Dim wc As New WizardHTTP
                    wc.SetDefaultHeaderAdr()
                    Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/c/thread/add", poststr)
                    Dim errno As String = GetMid(retstr, ":", ",")
                    If errno = "5" Then
                        Dim left As Integer = retstr.IndexOf("vcode_md5") + 12
                        Dim right As Integer = retstr.IndexOf("""", left)
                        Dim vcode As String = retstr.Substring(left, right - left)
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("http://tieba.baidu.com/cgi-bin/genimg?" + vcode)
                        Dim bs As String
                        If Anti Then
                            bs = GetVcodeFromAnti(picdata)
                        Else
                            bs = GetVcodeFromBSQ(picdata, index)
                        End If
                        tbs = GetTbs(IDList(i_id).Cookie)
                        poststr = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=" + IIf(Anonymous, "1", "0") + "&content=" + co + "&fid=" + tb.Fid + "&from=baidu_appstore&kw=" + tb.TBName + "&net_type=1&tbs=" + tbs + "&title=" + title + "&vcode=" + bs + "&vcode_md5=" + vcode
                        sign = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                        poststr = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=" + IIf(Anonymous, "1", "0") + "&content=" + URLEncoUTF8(co) + "&fid=" + tb.Fid + "&from=baidu_appstore&kw=" + URLEncoUTF8(tb.TBName) + "&net_type=1&tbs=" + tbs + "&title=" + URLEncoUTF8(title) + "&vcode=" + bs + "&vcode_md5=" + vcode + "&sign=" + sign
                        wc = New WizardHTTP
                        wc.SetDefaultHeaderAdr()
                        retstr = wc.UploadString("http://c.tieba.baidu.com/c/c/thread/add", poststr)
                        errno = GetMid(retstr, ":", ",")
                    End If
                    If errno = "0" Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + tb.TBName + "吧 发帖成功！")
                    Else
                        Dim Left As Integer = retstr.IndexOf("error_msg") + 12
                        Dim Right As Integer = retstr.IndexOf("""", Left)
                        Dim errmsg As String = UnicodeDeco(retstr.Substring(Left, Right - Left))
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + tb.TBName + "吧 发帖失败！" + errmsg)
                    End If
                End If

                i_id = TheNext(i_id, BSQ.TrNum, IDList.Count)
                If UsePr Then
                    sub_pr += 1
                    If sub_pr = Reuse Then
                        sub_pr = 0
                        i_pr = TheNext(i_pr, BSQ.TrNum, PRList.Count)
                    End If
                End If
                i_title = TheNext(i_title, 1, TitleList.Length)
                i_co = TheNext(i_co, 1, CoList.Length)
                i_tb = TheNext(i_tb, BSQ.TrNum, TBList.Length)
                Thread.Sleep(Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        End While
        'EndTr()
    End Sub

    Private Sub PostReplyTr(ByVal index As Integer)
        Dim ran As New Random(Environment.TickCount + index)
        Dim i_id As Integer = TheNext(index, 0, IDList.Count)
        Dim i_pr As Integer = 0,
            sub_pr As Integer = 0
        If UsePr Then i_pr = TheNext(index, 0, PRList.Count)
        Dim i_co As Integer = 0
        If CoOrder = 1 Then i_co = ran.Next(0, CoList.Length - 1)
        Dim i_tid As Integer = TheNext(index, 0, TidList.Length)
        If TidOrder = 1 Then i_tid = ran.Next(0, TidList.Length - 1)

        While True
            Try

                Dim jam As New Jammer(Environment.TickCount + index)
                Dim co As String = jam.Jammer(CoList(i_co))
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Cookie, "TIEBAUID=; TIEBA_USERTYPE=; Hm_lvt=; TIEBA_LOGINED_USER=; wise_device=0; close_liked_forum_tip=1; BAIDUID=:FG=1; BDUSS=; BAIDU_WISE_UID=")
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/p/" + TidList(i_tid))
                Dim left As Integer = retstr.IndexOf("value=") + 7
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim tb As String = retstr.Substring(left, right - left)
                Dim kw_utf8 As String = URLEncoUTF8(tb)
                left = retstr.IndexOf(",fid:'") + 6
                right = retstr.IndexOf("'", left)
                Dim fid As String = retstr.Substring(left, right - left)

                If Way = RANDOM Then '随机回帖
                    Dim j As Integer = ran.Next(1, 3)
                    If j = 1 Then : GoTo Label_HTTP
                    ElseIf j = 2 Then : GoTo Label_WAP
                    Else : GoTo Label_Client
                    End If
                ElseIf Way = HTTP Then 'HTTP回帖

Label_HTTP:         wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                    retstr = wc.DownloadString("http://tieba.baidu.com/f/user/json_needvcode?rs1=0&rs10=1&lm=" + fid + "&word=" + URLEncoUTF8(tb))
                    Dim ndvcode As String = GetMid(retstr, "need"":", ",")

                    Dim vcode As String = "",
                        bs As String = ""
                    If ndvcode <> "0" Then
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        retstr = wc.DownloadString("http://tieba.baidu.com/f?ct=486539264&cm=59200&lm=" + fid + "&rs1=0&rs10=1&word=&tn=jsonVcode")
                        vcode = GetMid(retstr, ":""", """")
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("http://tieba.baidu.com/cgi-bin/genimg?" + vcode)
                        If Anti Then
                            bs = GetVcodeFromAnti(picdata)
                        Else
                            bs = GetVcodeFromBSQ(picdata, index)
                        End If
                    End If

                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                    wc.TimeOut = Timeout
                    wc.ReadWriteTimeOut = Timeout
                    If UsePr Then wc.Proxy = New WebProxy(PRList(i_pr))
                    Dim tbs As String = GetTbs(IDList(i_id).Cookie)
                    Dim poststr As String = "tbs=" + tbs + "&tid=" + TidList(i_tid) + "&fid=" + fid + "&floor_num=1&vcode_md5=" + vcode + "&vcode=" + bs + "&rich_text=1&add_post_submit=%20%E5%8F%91%20%E8%A1%A8%20&content=" + URLEncoUTF8(co) + "&ie=1&kw=" + kw_utf8 + "&anonymous=" + IIf(Anonymous, "1", "") + "&useSignName=off"
                    retstr = wc.UploadString("http://tieba.baidu.com/f/commit/post/add", poststr)
                    Dim errno As String = GetMid(retstr, ":", ",")
                    If errno = "0" Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + TidList(i_tid) + " 回帖成功！")
                    Else
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + TidList(i_tid) + " 回帖失败！错误信息：" + errno)
                    End If

                ElseIf Way = WAP Then 'WAP回帖

Label_WAP:          Dim tbs As String = GetTbs(IDList(i_id).Cookie)
                    Dim poststr As String = "word1=&bs=&co=" + URLEncoUTF8(co) + "&src=1&word=" + kw_utf8 + "&tbs=" + tbs + "&ifpost=1&ifposta=1&post_info=0&tn=baiduWiseSubmit&fid=" + fid + "&verify=&verify_2=&pinf=1_2_0&pic_info=&z=" + TidList(i_tid) + "&last=0&pn=0&r=0&see_lz=0&no_post_pic=0&sub1=" + IIf(Anonymous, "%E5%8F%91%E8%A1%A8%E8%B4%B4%E5%AD%90", "%E5%8C%BF%E5%90%8D%E5%8F%91%E8%B4%B4")
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    wc.Headers.Set(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; sdk Build/GRI34) UC AppleWebKit/534.31 (KHTML, like Gecko) Mobile Safari/534.31")
                    wc.Encoding = Encoding.UTF8
                    retstr = wc.UploadString("http://wapp.baidu.com/f/q-0-0-wiaui_1332050392_2155-sz%40224_220%2C-1-1-0/m", poststr)
                    left = retstr.IndexOf("genimg?")
                    If left <> -1 Then
                        left += 7
                        right = retstr.IndexOf("""", left)
                        Dim vcode As String = retstr.Substring(left, right - left)
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("http://tieba.baidu.com/cgi-bin/genimg?" + vcode)
                        Dim bs As String
                        If Anti Then
                            bs = GetVcodeFromAnti(picdata)
                        Else
                            bs = GetVcodeFromBSQ(picdata, index)
                        End If
                        tbs = GetTbs(IDList(i_id).Cookie)
                        poststr = poststr = "word1=" + URLEncoUTF8(bs) + "&bs=" + vcode + "&co=" + URLEncoUTF8(co) + "&src=1&word=" + kw_utf8 + "&tbs=" + tbs + "&ifpost=1&ifposta=1&post_info=0&tn=baiduWiseSubmit&fid=" + fid + "&verify=&verify_2=&pinf=1_2_0&pic_info=&z=" + TidList(i_tid) + "&last=0&pn=0&r=0&see_lz=0&no_post_pic=0&sub1=" + IIf(Anonymous, "%E5%8F%91%E8%A1%A8%E8%B4%B4%E5%AD%90", "%E5%8C%BF%E5%90%8D%E5%8F%91%E8%B4%B4")
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        wc.Headers.Set(HttpRequestHeader.Cookie, IDList(i_id).Cookie)
                        wc.Headers.Set(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; sdk Build/GRI34) UC AppleWebKit/534.31 (KHTML, like Gecko) Mobile Safari/534.31")
                        wc.Encoding = Encoding.UTF8
                        wc.TimeOut = Timeout
                        wc.ReadWriteTimeOut = Timeout
                        If UsePr Then wc.Proxy = New WebProxy(PRList(i_pr))
                        retstr = wc.UploadString("http://wapp.baidu.com/f/q-0-0-wiaui_1332050392_2155-sz%40224_220%2C-1-1-0/m", poststr)
                    End If
                    If retstr.IndexOf("回帖成功") <> -1 Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + TidList(i_tid) + " 回帖成功！")
                    Else
                        Dim err As String = GetMid(retstr, "light"">", "<")
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + TidList(i_tid) + " 回帖失败！" + err)
                    End If

                Else '客户端回帖

Label_Client:       Dim clienttype As String = IIf(Way = IPHONE, "1", "2")
                    Dim cid As String = GetStampAndroid()
                    Dim tbs As String = GetTbs(IDList(i_id).Cookie)
                    Dim re As New Regex("BDUSS=.{192}")
                    Dim rm As Match = re.Match(IDList(i_id).Cookie)
                    If Not rm.Success Then Throw New Exception("Cookie格式不正确！")
                    Dim cookie As String = rm.Value
                    Dim poststr As String = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=0&content=" + co + "&fid=" + fid + "&from=baidu_appstore&kw=" + tb + "&net_type=1&tbs=" + tbs + "&tid=" + TidList(i_tid)
                    Dim sign As String = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                    poststr = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=0&content=" + URLEncoUTF8(co) + "&fid=" + fid + "&from=baidu_appstore&kw=" + kw_utf8 + "&net_type=1&tbs=" + tbs + "&tid=" + TidList(i_tid) + "&sign=" + sign
                    wc = New WizardHTTP
                    wc.SetDefaultHeaderAdr()
                    retstr = wc.UploadString("http://c.tieba.baidu.com/c/c/post/add", poststr)
                    Dim errno As String = GetMid(retstr, ":", ",")
                    If errno = "5" Then
                        left = retstr.IndexOf("vcode_md5") + 12
                        right = retstr.IndexOf("""", left)
                        Dim vcode As String = retstr.Substring(left, right - left)
                        wc = New WizardHTTP
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("http://tieba.baidu.com/cgi-bin/genimg?" + vcode)
                        Dim bs As String
                        If Anti Then
                            bs = GetVcodeFromAnti(picdata)
                        Else
                            bs = GetVcodeFromBSQ(picdata, index)
                        End If
                        tbs = GetTbs(IDList(i_id).Cookie)
                        poststr = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=0&content=" + co + "&fid=" + fid + "&from=baidu_appstore&kw=" + tb + "&net_type=1&tbs=" + tbs + "&tid=" + TidList(i_tid) + "&vcode=" + bs + "&vcode_md5=" + vcode
                        sign = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                        poststr = cookie + "&_client_id=" + cid + "&_client_type=" + clienttype + "&_client_version=1.0.4&_phone_imei=000000000000000&anonymous=0&content=" + URLEncoUTF8(co) + "&fid=" + fid + "&from=baidu_appstore&kw=" + kw_utf8 + "&net_type=1&tbs=" + tbs + "&tid=" + TidList(i_tid) + "&vcode=" + URLEncoUTF8(bs) + "&vcode_md5=" + vcode + "&sign=" + sign
                        wc = New WizardHTTP
                        wc.SetDefaultHeaderAdr()
                        retstr = wc.UploadString("http://c.tieba.baidu.com/c/c/post/add", poststr)
                        errno = GetMid(retstr, ":", ",")
                    End If
                    If errno = "0" Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + TidList(i_tid) + " 回帖成功！")
                    Else
                        left = retstr.IndexOf("error_msg") + 12
                        right = retstr.IndexOf("""", left)
                        Dim errmsg As String = UnicodeDeco(retstr.Substring(left, right - left))
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + IDList(i_id).UN + " " + TidList(i_tid) + " 回帖失败！" + errmsg)
                    End If
                End If

                i_id = TheNext(i_id, BSQ.TrNum, IDList.Count)
                If UsePr Then
                    sub_pr += 1
                    If sub_pr = Reuse Then
                        sub_pr = 0
                        i_pr = TheNext(i_pr, BSQ.TrNum, PRList.Count)
                    End If
                End If
                i_co = TheNext(i_co, 1, CoList.Length)
                i_tid = TheNext(i_tid, BSQ.TrNum, TidList.Length)
                Thread.Sleep(Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        End While
        'EndTr()
    End Sub

    Private Sub EndTr()
        BSQ.Abort()
        If Not Anti Then BSForm.NdHide = True
        TaskRunning = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "任务结束！")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub StopButton_Click(sender As System.Object, e As System.EventArgs) Handles StopButton.Click
        EndTr()
    End Sub

    Private Sub BZTestButton_Click(sender As System.Object, e As System.EventArgs) Handles BZTestButton.Click
        Try
            BZTestButton.Enabled = False
            If TaskRunning Then Throw New Exception("请等待其他任务结束！")
            BZTestTB = BZTBTextBox.Text
            If BZTestTB = "" Then Throw New Exception("请填写目标贴吧！")
            TaskRunning = True
            Dim tr As New Thread(AddressOf Bztest)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            BZTestButton.Enabled = True
        End Try
    End Sub

    Private Sub BzTest()
        Try
            Dim wc As New WizardHTTP()
            wc.SetDefaultHeader()
            wc.Encoding = Encoding.UTF8
            Dim retstr As String = wc.DownloadString("http://wapp.baidu.com/f/m?tn=bdBIW&word=" + URLEncoGBK(BZTestTB))
            Dim bawu As New List(Of String)
            Dim onlinenum As New Integer
            Dim left As Integer = retstr.IndexOf("吧主"),
                right As Integer = retstr.IndexOf("小吧主"),
                cutdown As Integer = retstr.IndexOf("主题")
            If left = -1 Or right = -1 Or cutdown = -1 Then
                Throw New Exception("贴吧信息获取失败！")
            End If
            Dim bz As String = retstr.Substring(left, right - left)
            Dim littlebz As String = retstr.Substring(right, cutdown - right)

            '取吧主  
            left = 0
            right = 0
            While True
                left = bz.IndexOf(""">", left) + 2
                If left = 1 Then Exit While
                right = bz.IndexOf("</a>", left)
                If right = -1 Then Exit While
                bawu.Add(bz.Substring(left, right - left))
                left = right
            End While

            '取小吧主
            left = 0
            right = 0
            While True
                left = littlebz.IndexOf(""">", left) + 2
                If left = 1 Then Exit While
                right = littlebz.IndexOf("</a>", left)
                If right = -1 Then Exit While
                bawu.Add(littlebz.Substring(left, right - left))
                left = right
            End While
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "吧务获取完毕...")

            If bawu.Count = 0 Then
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + "检测完毕，该吧没有吧主！")
            Else
                For Each x As String In bawu
                    Try
                        Dim wc0 As New WizardHTTP
                        wc0.SetDefaultHeader()
                        wc0.Encoding = Encoding.UTF8
                        Dim ret2 As String = wc0.DownloadString("http://www.baidu.com/p/" + URLEncoGBK(x))
                        If ret2.IndexOf("offline") = -1 Then
                            Console.ForegroundColor = ConsoleColor.Red
                            Console.WriteLine(Time() + x + "：在线")
                            onlinenum += 1
                        Else
                            Console.ForegroundColor = ConsoleColor.Green
                            Console.WriteLine(Time() + x + "：离线")
                        End If
                    Catch ex As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + x + "：获取失败")
                    End Try
                Next
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine("吧务共计 " + bawu.Count.ToString() + " 个，在线 " + onlinenum.ToString() + " 个。")
            End If

            Dim fid As String = GetFid(URLEncoGBK(BZTestTB))
            wc = New WizardHTTP
            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/f/user/json_needvcode?rs1=0&rs10=1&lm=" + fid + "&word=" + URLEncoUTF8(BZTestTB))
            Dim open As String = GetMid(retstr, "open_shenshou"":", ",")
            If open = "0" Then
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + "该吧没有开启超级验证码！")
            Else
                Dim lv As String = GetMid(retstr, "shenshou_lv"":", ",")
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + "该吧已开启超级验证码，等级：" + lv)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        TaskRunning = False
        BZTestButton.Enabled = True
    End Sub
End Class
