﻿Public Class AntiVcode

    Public Declare Function LoadCdsFromBuffer Lib "DuoWei.dll" (ByVal Buffer As Byte(), ByVal BuffLen As Integer) As Integer
    Public Declare Function GetVcodeFromBuffer Lib "DuoWei.dll" (ByVal CdsIndex As Integer, ByVal ImgBuffer As Byte(), ByVal ImgBufLen As Integer, ByVal Vcode As Byte()) As Boolean
End Class
