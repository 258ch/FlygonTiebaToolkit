﻿Imports System.Threading
Imports System.Text
Imports DragonDepth.MyFunctions
Imports System.Text.RegularExpressions

Public Class LoginForm

    Public Shared GTLv4 As Boolean = False

    Private UN As String
    Private PW As String
    Private Ques As Integer
    Private Ans As String
    Private Proxy As String

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        QuesComboBox.SelectedIndex = 0
    End Sub

    Private Sub LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginButton.Click
        Try
            LoginButton.Enabled = False
            UN = UNTextBox.Text
            PW = PWTextBox.Text
            If UN = "" Or PW = "" Then Throw New Exception("请填写用户名和密码！")
            Ques = QuesComboBox.SelectedIndex
            Ans = AnsTextBox.Text
            Proxy = PrTextBox.Text
            Dim tr As New Thread(AddressOf Login)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub Login()
        Try
            Dim wc As New WizardHTTP
            wc.SetDefaultHeader()
            If Proxy <> "" Then wc.Proxy = New Net.WebProxy(Proxy)
            Dim retstr As String = wc.DownloadString("http://www.258ch.com/member.php?mod=logging&action=login&referer=http%3A%2F%2Fwww.258ch.com%2Fforum.php&referer=http%3A//www.258ch.com/member.php%3Fmod%3Dregisterbbsf")
            Dim left As Integer = retstr.IndexOf("name=""formhash") + 23
            Dim right As Integer = retstr.IndexOf("""", left)
            Dim hash As String = retstr.Substring(left, right - left)
            left = retstr.IndexOf("action=""member.php") + 8
            right = retstr.IndexOf("""", left)
            Dim url As String = retstr.Substring(left, right - left)
            url = url.Replace("amp;", "")
            Dim poststr As String = "formhash=" + hash + "&referer=http%3A%2F%2Fwww.258ch.com%2Fmember.php%3Fmod%3Dregisterbbsf&username=" + URLEncoGBK(UN) + "&password=" + PW + "&questionid=" + Ques.ToString() + "&answer=" + URLEncoGBK(Ans)
            wc = New WizardHTTP
            wc.SetDefaultHeader()
            retstr = wc.UploadString("http://www.258ch.com/" + url, poststr)
            Dim rethdr As String = wc.ResponseHeaders.Get("Set-Cookie")
            Dim re As New Regex("WGMU_2132_auth=.{92}")
            If re.IsMatch(rethdr) Then
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + "登录成功！")
                '取用户组信息
                left = retstr.IndexOf("欢迎您回来，")
                left = retstr.IndexOf(">", left) + 1
                right = retstr.IndexOf("</", left)
                Dim group As String = retstr.Substring(left, right - left)
                GTLv4 = IsGTLv4(group)
                Me.Close()
                Exit Sub
            End If
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "登录失败！")
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
        End Try
        LoginButton.Enabled = True
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.258ch.com/forum.php")
    End Sub

    Private Function IsGTLv4(ByVal text As String) As Boolean
        If text.IndexOf("游客") <> -1 Then Return False
        If text.IndexOf("禁止") <> -1 Then Return False
        Dim posi As Integer = text.IndexOf("Lv")
        If posi <> -1 Then
            posi += 3
            Dim lv As Integer = Convert.ToInt32(text.Substring(posi, text.Length - posi))
            Return IIf(lv < 4, False, True)
        Else
            Return True
        End If
    End Function
End Class