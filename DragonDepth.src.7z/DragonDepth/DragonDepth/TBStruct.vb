﻿Public Structure TBStruct
    Public TBName As String
    Public Fid As String
End Structure
