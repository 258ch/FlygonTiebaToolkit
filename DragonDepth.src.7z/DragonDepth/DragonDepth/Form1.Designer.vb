﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.pr_CleanButton = New System.Windows.Forms.Button()
        Me.id_CleanButton = New System.Windows.Forms.Button()
        Me.pr_LoadButton = New System.Windows.Forms.Button()
        Me.id_LoadButton = New System.Windows.Forms.Button()
        Me.pr_TextBox = New System.Windows.Forms.TextBox()
        Me.id_TextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.TidListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TIDMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TIDAddMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDEditMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDDelMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDCopyMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDPasteMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDCopyAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDDelAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIDGetMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TBListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TBMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TBAddMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBEditMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBDelMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBCopyMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBPasteMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBCopyAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBDelAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TBFidMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CoListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CoMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CoAddMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoEditMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoDelMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoCopyMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoPasteMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoCopyAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoDelAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoGetMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TitleListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TitleMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TitleAddMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleEditMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleDelMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleCopyMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitlePasteMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleCopyAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleDelAMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleGetMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.SetButton = New System.Windows.Forms.Button()
        Me.BetterNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ModeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.AntiCheckBox = New System.Windows.Forms.CheckBox()
        Me.PrCheckBox = New System.Windows.Forms.CheckBox()
        Me.AnonyCheckBox = New System.Windows.Forms.CheckBox()
        Me.WayComboBox = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PrReuseNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TimeoutNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TidComboBox = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TBComboBox = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CoComboBox = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TitleComboBox = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pr_OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.id_OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.BZTBTextBox = New System.Windows.Forms.TextBox()
        Me.BZTestButton = New System.Windows.Forms.Button()
        Me.StatusStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TIDMenu.SuspendLayout()
        Me.TBMenu.SuspendLayout()
        Me.CoMenu.SuspendLayout()
        Me.TitleMenu.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.BetterNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PrReuseNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel5, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 415)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(741, 22)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel1.IsLink = True
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel1.Text = "保存设置"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel5.IsLink = True
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel5.Text = "优化内存"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel2.IsLink = True
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel2.Text = "联系作者"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel3.IsLink = True
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel3.Text = "风凝圣域"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel4.IsLink = True
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel4.Text = "苍海国际"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(0, 1)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(741, 411)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(733, 385)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "欢迎"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("微软雅黑", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label18.Location = New System.Drawing.Point(301, 221)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(414, 31)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "欢迎使用 发帖机·龙渊 Dragon Depth"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("微软雅黑", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label7.Location = New System.Drawing.Point(292, 122)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(433, 64)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "苍海国际·王者归来"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(733, 385)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "马甲代理"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.pr_CleanButton)
        Me.GroupBox3.Controls.Add(Me.id_CleanButton)
        Me.GroupBox3.Controls.Add(Me.pr_LoadButton)
        Me.GroupBox3.Controls.Add(Me.id_LoadButton)
        Me.GroupBox3.Controls.Add(Me.pr_TextBox)
        Me.GroupBox3.Controls.Add(Me.id_TextBox)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Location = New System.Drawing.Point(129, 126)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(475, 133)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        '
        'pr_CleanButton
        '
        Me.pr_CleanButton.Location = New System.Drawing.Point(381, 68)
        Me.pr_CleanButton.Name = "pr_CleanButton"
        Me.pr_CleanButton.Size = New System.Drawing.Size(75, 23)
        Me.pr_CleanButton.TabIndex = 7
        Me.pr_CleanButton.Text = "清除"
        Me.pr_CleanButton.UseVisualStyleBackColor = True
        '
        'id_CleanButton
        '
        Me.id_CleanButton.Location = New System.Drawing.Point(381, 41)
        Me.id_CleanButton.Name = "id_CleanButton"
        Me.id_CleanButton.Size = New System.Drawing.Size(75, 23)
        Me.id_CleanButton.TabIndex = 6
        Me.id_CleanButton.Text = "清除"
        Me.id_CleanButton.UseVisualStyleBackColor = True
        '
        'pr_LoadButton
        '
        Me.pr_LoadButton.Location = New System.Drawing.Point(300, 68)
        Me.pr_LoadButton.Name = "pr_LoadButton"
        Me.pr_LoadButton.Size = New System.Drawing.Size(75, 23)
        Me.pr_LoadButton.TabIndex = 5
        Me.pr_LoadButton.Text = "设置"
        Me.pr_LoadButton.UseVisualStyleBackColor = True
        '
        'id_LoadButton
        '
        Me.id_LoadButton.Location = New System.Drawing.Point(300, 41)
        Me.id_LoadButton.Name = "id_LoadButton"
        Me.id_LoadButton.Size = New System.Drawing.Size(75, 23)
        Me.id_LoadButton.TabIndex = 4
        Me.id_LoadButton.Text = "设置"
        Me.id_LoadButton.UseVisualStyleBackColor = True
        '
        'pr_TextBox
        '
        Me.pr_TextBox.BackColor = System.Drawing.Color.White
        Me.pr_TextBox.Location = New System.Drawing.Point(62, 70)
        Me.pr_TextBox.Name = "pr_TextBox"
        Me.pr_TextBox.ReadOnly = True
        Me.pr_TextBox.Size = New System.Drawing.Size(232, 21)
        Me.pr_TextBox.TabIndex = 3
        '
        'id_TextBox
        '
        Me.id_TextBox.BackColor = System.Drawing.Color.White
        Me.id_TextBox.Location = New System.Drawing.Point(62, 43)
        Me.id_TextBox.Name = "id_TextBox"
        Me.id_TextBox.ReadOnly = True
        Me.id_TextBox.Size = New System.Drawing.Size(232, 21)
        Me.id_TextBox.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 12)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "代理"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "马甲"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.StopButton)
        Me.TabPage3.Controls.Add(Me.StartButton)
        Me.TabPage3.Controls.Add(Me.TidListView)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.TBListView)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.CoListView)
        Me.TabPage3.Controls.Add(Me.Label2)
        Me.TabPage3.Controls.Add(Me.TitleListView)
        Me.TabPage3.Controls.Add(Me.Label1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(733, 385)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "行动"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(602, 351)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(123, 28)
        Me.StopButton.TabIndex = 9
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(458, 351)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(123, 28)
        Me.StartButton.TabIndex = 8
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'TidListView
        '
        Me.TidListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5})
        Me.TidListView.ContextMenuStrip = Me.TIDMenu
        Me.TidListView.FullRowSelect = True
        Me.TidListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.TidListView.Location = New System.Drawing.Point(458, 195)
        Me.TidListView.Name = "TidListView"
        Me.TidListView.Size = New System.Drawing.Size(267, 150)
        Me.TidListView.TabIndex = 7
        Me.TidListView.UseCompatibleStateImageBehavior = False
        Me.TidListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "tid"
        Me.ColumnHeader5.Width = 260
        '
        'TIDMenu
        '
        Me.TIDMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TIDAddMenuItem, Me.TIDEditMenuItem, Me.TIDDelMenuItem, Me.TIDCopyMenuItem, Me.TIDPasteMenuItem, Me.TIDCopyAMenuItem, Me.TIDDelAMenuItem, Me.TIDGetMenuItem})
        Me.TIDMenu.Name = "TitleMenu"
        Me.TIDMenu.Size = New System.Drawing.Size(125, 180)
        '
        'TIDAddMenuItem
        '
        Me.TIDAddMenuItem.Name = "TIDAddMenuItem"
        Me.TIDAddMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDAddMenuItem.Text = "添加"
        '
        'TIDEditMenuItem
        '
        Me.TIDEditMenuItem.Name = "TIDEditMenuItem"
        Me.TIDEditMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDEditMenuItem.Text = "编辑选中"
        '
        'TIDDelMenuItem
        '
        Me.TIDDelMenuItem.Name = "TIDDelMenuItem"
        Me.TIDDelMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDDelMenuItem.Text = "删除选中"
        '
        'TIDCopyMenuItem
        '
        Me.TIDCopyMenuItem.Name = "TIDCopyMenuItem"
        Me.TIDCopyMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDCopyMenuItem.Text = "复制选中"
        '
        'TIDPasteMenuItem
        '
        Me.TIDPasteMenuItem.Name = "TIDPasteMenuItem"
        Me.TIDPasteMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDPasteMenuItem.Text = "粘贴"
        '
        'TIDCopyAMenuItem
        '
        Me.TIDCopyAMenuItem.Name = "TIDCopyAMenuItem"
        Me.TIDCopyAMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDCopyAMenuItem.Text = "复制全部"
        '
        'TIDDelAMenuItem
        '
        Me.TIDDelAMenuItem.Name = "TIDDelAMenuItem"
        Me.TIDDelAMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDDelAMenuItem.Text = "删除全部"
        '
        'TIDGetMenuItem
        '
        Me.TIDGetMenuItem.Name = "TIDGetMenuItem"
        Me.TIDGetMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TIDGetMenuItem.Text = "获取"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(456, 180)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(137, 12)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "帖子号列表（右键操作）"
        '
        'TBListView
        '
        Me.TBListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4})
        Me.TBListView.ContextMenuStrip = Me.TBMenu
        Me.TBListView.FullRowSelect = True
        Me.TBListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.TBListView.Location = New System.Drawing.Point(458, 23)
        Me.TBListView.Name = "TBListView"
        Me.TBListView.Size = New System.Drawing.Size(267, 150)
        Me.TBListView.TabIndex = 5
        Me.TBListView.UseCompatibleStateImageBehavior = False
        Me.TBListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "贴吧名称"
        Me.ColumnHeader3.Width = 200
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "fid"
        '
        'TBMenu
        '
        Me.TBMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TBAddMenuItem, Me.TBEditMenuItem, Me.TBDelMenuItem, Me.TBCopyMenuItem, Me.TBPasteMenuItem, Me.TBCopyAMenuItem, Me.TBDelAMenuItem, Me.TBFidMenuItem})
        Me.TBMenu.Name = "TitleMenu"
        Me.TBMenu.Size = New System.Drawing.Size(142, 180)
        '
        'TBAddMenuItem
        '
        Me.TBAddMenuItem.Name = "TBAddMenuItem"
        Me.TBAddMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBAddMenuItem.Text = "添加"
        '
        'TBEditMenuItem
        '
        Me.TBEditMenuItem.Name = "TBEditMenuItem"
        Me.TBEditMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBEditMenuItem.Text = "编辑选中"
        '
        'TBDelMenuItem
        '
        Me.TBDelMenuItem.Name = "TBDelMenuItem"
        Me.TBDelMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBDelMenuItem.Text = "删除选中"
        '
        'TBCopyMenuItem
        '
        Me.TBCopyMenuItem.Name = "TBCopyMenuItem"
        Me.TBCopyMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBCopyMenuItem.Text = "复制选中"
        '
        'TBPasteMenuItem
        '
        Me.TBPasteMenuItem.Enabled = False
        Me.TBPasteMenuItem.Name = "TBPasteMenuItem"
        Me.TBPasteMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBPasteMenuItem.Text = "粘贴"
        '
        'TBCopyAMenuItem
        '
        Me.TBCopyAMenuItem.Name = "TBCopyAMenuItem"
        Me.TBCopyAMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBCopyAMenuItem.Text = "复制全部"
        '
        'TBDelAMenuItem
        '
        Me.TBDelAMenuItem.Name = "TBDelAMenuItem"
        Me.TBDelAMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBDelAMenuItem.Text = "删除全部"
        '
        'TBFidMenuItem
        '
        Me.TBFidMenuItem.Name = "TBFidMenuItem"
        Me.TBFidMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.TBFidMenuItem.Text = "取选中项Fid"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(456, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(125, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "贴吧列表（右键操作）"
        '
        'CoListView
        '
        Me.CoListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader2})
        Me.CoListView.ContextMenuStrip = Me.CoMenu
        Me.CoListView.FullRowSelect = True
        Me.CoListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.CoListView.Location = New System.Drawing.Point(8, 195)
        Me.CoListView.Name = "CoListView"
        Me.CoListView.Size = New System.Drawing.Size(444, 184)
        Me.CoListView.TabIndex = 3
        Me.CoListView.UseCompatibleStateImageBehavior = False
        Me.CoListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "内容"
        Me.ColumnHeader2.Width = 430
        '
        'CoMenu
        '
        Me.CoMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CoAddMenuItem, Me.CoEditMenuItem, Me.CoDelMenuItem, Me.CoCopyMenuItem, Me.CoPasteMenuItem, Me.CoCopyAMenuItem, Me.CoDelAMenuItem, Me.CoGetMenuItem})
        Me.CoMenu.Name = "TitleMenu"
        Me.CoMenu.Size = New System.Drawing.Size(125, 180)
        '
        'CoAddMenuItem
        '
        Me.CoAddMenuItem.Name = "CoAddMenuItem"
        Me.CoAddMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoAddMenuItem.Text = "添加"
        '
        'CoEditMenuItem
        '
        Me.CoEditMenuItem.Name = "CoEditMenuItem"
        Me.CoEditMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoEditMenuItem.Text = "编辑选中"
        '
        'CoDelMenuItem
        '
        Me.CoDelMenuItem.Name = "CoDelMenuItem"
        Me.CoDelMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoDelMenuItem.Text = "删除选中"
        '
        'CoCopyMenuItem
        '
        Me.CoCopyMenuItem.Name = "CoCopyMenuItem"
        Me.CoCopyMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoCopyMenuItem.Text = "复制选中"
        '
        'CoPasteMenuItem
        '
        Me.CoPasteMenuItem.Name = "CoPasteMenuItem"
        Me.CoPasteMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoPasteMenuItem.Text = "粘贴"
        '
        'CoCopyAMenuItem
        '
        Me.CoCopyAMenuItem.Name = "CoCopyAMenuItem"
        Me.CoCopyAMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoCopyAMenuItem.Text = "复制全部"
        '
        'CoDelAMenuItem
        '
        Me.CoDelAMenuItem.Name = "CoDelAMenuItem"
        Me.CoDelAMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoDelAMenuItem.Text = "删除全部"
        '
        'CoGetMenuItem
        '
        Me.CoGetMenuItem.Name = "CoGetMenuItem"
        Me.CoGetMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CoGetMenuItem.Text = "获取"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 180)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "内容列表（右键操作）"
        '
        'TitleListView
        '
        Me.TitleListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.TitleListView.ContextMenuStrip = Me.TitleMenu
        Me.TitleListView.FullRowSelect = True
        Me.TitleListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.TitleListView.Location = New System.Drawing.Point(8, 23)
        Me.TitleListView.Name = "TitleListView"
        Me.TitleListView.Size = New System.Drawing.Size(444, 150)
        Me.TitleListView.TabIndex = 1
        Me.TitleListView.UseCompatibleStateImageBehavior = False
        Me.TitleListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "主题"
        Me.ColumnHeader1.Width = 430
        '
        'TitleMenu
        '
        Me.TitleMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TitleAddMenuItem, Me.TitleEditMenuItem, Me.TitleDelMenuItem, Me.TitleCopyMenuItem, Me.TitlePasteMenuItem, Me.TitleCopyAMenuItem, Me.TitleDelAMenuItem, Me.TitleGetMenuItem})
        Me.TitleMenu.Name = "TitleMenu"
        Me.TitleMenu.Size = New System.Drawing.Size(125, 180)
        '
        'TitleAddMenuItem
        '
        Me.TitleAddMenuItem.Name = "TitleAddMenuItem"
        Me.TitleAddMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleAddMenuItem.Text = "添加"
        '
        'TitleEditMenuItem
        '
        Me.TitleEditMenuItem.Name = "TitleEditMenuItem"
        Me.TitleEditMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleEditMenuItem.Text = "编辑选中"
        '
        'TitleDelMenuItem
        '
        Me.TitleDelMenuItem.Name = "TitleDelMenuItem"
        Me.TitleDelMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleDelMenuItem.Text = "删除选中"
        '
        'TitleCopyMenuItem
        '
        Me.TitleCopyMenuItem.Name = "TitleCopyMenuItem"
        Me.TitleCopyMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleCopyMenuItem.Text = "复制选中"
        '
        'TitlePasteMenuItem
        '
        Me.TitlePasteMenuItem.Name = "TitlePasteMenuItem"
        Me.TitlePasteMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitlePasteMenuItem.Text = "粘贴"
        '
        'TitleCopyAMenuItem
        '
        Me.TitleCopyAMenuItem.Name = "TitleCopyAMenuItem"
        Me.TitleCopyAMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleCopyAMenuItem.Text = "复制全部"
        '
        'TitleDelAMenuItem
        '
        Me.TitleDelAMenuItem.Name = "TitleDelAMenuItem"
        Me.TitleDelAMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleDelAMenuItem.Text = "删除全部"
        '
        'TitleGetMenuItem
        '
        Me.TitleGetMenuItem.Name = "TitleGetMenuItem"
        Me.TitleGetMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.TitleGetMenuItem.Text = "获取"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "主题列表（右键操作）"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox4)
        Me.TabPage4.Controls.Add(Me.GroupBox2)
        Me.TabPage4.Controls.Add(Me.GroupBox1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(733, 385)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "设置"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.BZTestButton)
        Me.GroupBox4.Controls.Add(Me.BZTBTextBox)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Location = New System.Drawing.Point(249, 199)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(236, 180)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "吧主神兽检测"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.SetButton)
        Me.GroupBox2.Controls.Add(Me.BetterNumeric)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Location = New System.Drawing.Point(248, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(237, 187)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "内存优化"
        '
        'SetButton
        '
        Me.SetButton.Location = New System.Drawing.Point(155, 76)
        Me.SetButton.Name = "SetButton"
        Me.SetButton.Size = New System.Drawing.Size(59, 23)
        Me.SetButton.TabIndex = 12
        Me.SetButton.Text = "应用"
        Me.SetButton.UseVisualStyleBackColor = True
        '
        'BetterNumeric
        '
        Me.BetterNumeric.Location = New System.Drawing.Point(82, 76)
        Me.BetterNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.BetterNumeric.Name = "BetterNumeric"
        Me.BetterNumeric.Size = New System.Drawing.Size(67, 21)
        Me.BetterNumeric.TabIndex = 11
        Me.BetterNumeric.Value = New Decimal(New Integer() {10000, 0, 0, 0})
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(29, 80)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(53, 12)
        Me.Label17.TabIndex = 10
        Me.Label17.Text = "间隔(ms)"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ModeComboBox)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.AntiCheckBox)
        Me.GroupBox1.Controls.Add(Me.PrCheckBox)
        Me.GroupBox1.Controls.Add(Me.AnonyCheckBox)
        Me.GroupBox1.Controls.Add(Me.WayComboBox)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.PrReuseNumeric)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.TimeoutNumeric)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.DelayNumeric)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.TrNumeric)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.TidComboBox)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.TBComboBox)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.CoComboBox)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.TitleComboBox)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(237, 373)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "参数"
        '
        'ModeComboBox
        '
        Me.ModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ModeComboBox.FormattingEnabled = True
        Me.ModeComboBox.Items.AddRange(New Object() {"主题", "回帖"})
        Me.ModeComboBox.Location = New System.Drawing.Point(78, 285)
        Me.ModeComboBox.Name = "ModeComboBox"
        Me.ModeComboBox.Size = New System.Drawing.Size(121, 20)
        Me.ModeComboBox.TabIndex = 22
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(19, 288)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 12)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "操作"
        '
        'AntiCheckBox
        '
        Me.AntiCheckBox.AutoSize = True
        Me.AntiCheckBox.Location = New System.Drawing.Point(21, 333)
        Me.AntiCheckBox.Name = "AntiCheckBox"
        Me.AntiCheckBox.Size = New System.Drawing.Size(84, 16)
        Me.AntiCheckBox.TabIndex = 20
        Me.AntiCheckBox.Text = "验证码识别"
        Me.AntiCheckBox.UseVisualStyleBackColor = True
        '
        'PrCheckBox
        '
        Me.PrCheckBox.AutoSize = True
        Me.PrCheckBox.Location = New System.Drawing.Point(127, 311)
        Me.PrCheckBox.Name = "PrCheckBox"
        Me.PrCheckBox.Size = New System.Drawing.Size(72, 16)
        Me.PrCheckBox.TabIndex = 19
        Me.PrCheckBox.Text = "使用代理"
        Me.PrCheckBox.UseVisualStyleBackColor = True
        '
        'AnonyCheckBox
        '
        Me.AnonyCheckBox.AutoSize = True
        Me.AnonyCheckBox.Location = New System.Drawing.Point(21, 311)
        Me.AnonyCheckBox.Name = "AnonyCheckBox"
        Me.AnonyCheckBox.Size = New System.Drawing.Size(48, 16)
        Me.AnonyCheckBox.TabIndex = 18
        Me.AnonyCheckBox.Text = "匿名"
        Me.AnonyCheckBox.UseVisualStyleBackColor = True
        '
        'WayComboBox
        '
        Me.WayComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.WayComboBox.FormattingEnabled = True
        Me.WayComboBox.Items.AddRange(New Object() {"http", "wap", "iPhone", "Android", "随机"})
        Me.WayComboBox.Location = New System.Drawing.Point(78, 259)
        Me.WayComboBox.Name = "WayComboBox"
        Me.WayComboBox.Size = New System.Drawing.Size(121, 20)
        Me.WayComboBox.TabIndex = 17
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(19, 262)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(29, 12)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "方式"
        '
        'PrReuseNumeric
        '
        Me.PrReuseNumeric.Location = New System.Drawing.Point(78, 232)
        Me.PrReuseNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.PrReuseNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.PrReuseNumeric.Name = "PrReuseNumeric"
        Me.PrReuseNumeric.Size = New System.Drawing.Size(121, 21)
        Me.PrReuseNumeric.TabIndex = 15
        Me.PrReuseNumeric.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(19, 234)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(53, 12)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "代理复用"
        '
        'TimeoutNumeric
        '
        Me.TimeoutNumeric.Location = New System.Drawing.Point(78, 205)
        Me.TimeoutNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.TimeoutNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TimeoutNumeric.Name = "TimeoutNumeric"
        Me.TimeoutNumeric.Size = New System.Drawing.Size(121, 21)
        Me.TimeoutNumeric.TabIndex = 13
        Me.TimeoutNumeric.Value = New Decimal(New Integer() {8000, 0, 0, 0})
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(19, 207)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 12)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "超时(ms)"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(78, 178)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(121, 21)
        Me.DelayNumeric.TabIndex = 11
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(19, 180)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 12)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "间隔(ms)"
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(78, 151)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(121, 21)
        Me.TrNumeric.TabIndex = 9
        Me.TrNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(19, 153)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 12)
        Me.Label12.TabIndex = 8
        Me.Label12.Text = "线程数"
        '
        'TidComboBox
        '
        Me.TidComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TidComboBox.FormattingEnabled = True
        Me.TidComboBox.Items.AddRange(New Object() {"顺序", "随机"})
        Me.TidComboBox.Location = New System.Drawing.Point(78, 125)
        Me.TidComboBox.Name = "TidComboBox"
        Me.TidComboBox.Size = New System.Drawing.Size(121, 20)
        Me.TidComboBox.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(19, 128)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(53, 12)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "帖子列表"
        '
        'TBComboBox
        '
        Me.TBComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TBComboBox.FormattingEnabled = True
        Me.TBComboBox.Items.AddRange(New Object() {"顺序", "随机"})
        Me.TBComboBox.Location = New System.Drawing.Point(78, 99)
        Me.TBComboBox.Name = "TBComboBox"
        Me.TBComboBox.Size = New System.Drawing.Size(121, 20)
        Me.TBComboBox.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(19, 102)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 12)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "贴吧列表"
        '
        'CoComboBox
        '
        Me.CoComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CoComboBox.FormattingEnabled = True
        Me.CoComboBox.Items.AddRange(New Object() {"顺序", "随机"})
        Me.CoComboBox.Location = New System.Drawing.Point(78, 73)
        Me.CoComboBox.Name = "CoComboBox"
        Me.CoComboBox.Size = New System.Drawing.Size(121, 20)
        Me.CoComboBox.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(19, 76)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 12)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "内容列表"
        '
        'TitleComboBox
        '
        Me.TitleComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TitleComboBox.FormattingEnabled = True
        Me.TitleComboBox.Items.AddRange(New Object() {"顺序", "随机"})
        Me.TitleComboBox.Location = New System.Drawing.Point(78, 47)
        Me.TitleComboBox.Name = "TitleComboBox"
        Me.TitleComboBox.Size = New System.Drawing.Size(121, 20)
        Me.TitleComboBox.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(19, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 12)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "主题列表"
        '
        'pr_OpenFileDialog
        '
        Me.pr_OpenFileDialog.DefaultExt = "*.txt"
        Me.pr_OpenFileDialog.FileName = "OpenFileDialog1"
        Me.pr_OpenFileDialog.Filter = "文本文件(*.txt)|*.txt"
        '
        'id_OpenFileDialog
        '
        Me.id_OpenFileDialog.DefaultExt = "*.clst"
        Me.id_OpenFileDialog.FileName = "OpenFileDialog1"
        Me.id_OpenFileDialog.Filter = "数据文件(*.icid)|*.icid"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(28, 72)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(29, 12)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "贴吧"
        '
        'BZTBTextBox
        '
        Me.BZTBTextBox.Location = New System.Drawing.Point(63, 69)
        Me.BZTBTextBox.Name = "BZTBTextBox"
        Me.BZTBTextBox.Size = New System.Drawing.Size(85, 21)
        Me.BZTBTextBox.TabIndex = 1
        '
        'BZTestButton
        '
        Me.BZTestButton.Location = New System.Drawing.Point(154, 67)
        Me.BZTestButton.Name = "BZTestButton"
        Me.BZTestButton.Size = New System.Drawing.Size(59, 23)
        Me.BZTestButton.TabIndex = 2
        Me.BZTestButton.Text = "检测"
        Me.BZTestButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(741, 437)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "发帖机·龙渊 DragonDepthPoster - 飞龙"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TIDMenu.ResumeLayout(False)
        Me.TBMenu.ResumeLayout(False)
        Me.CoMenu.ResumeLayout(False)
        Me.TitleMenu.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.BetterNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PrReuseNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents pr_CleanButton As System.Windows.Forms.Button
    Friend WithEvents id_CleanButton As System.Windows.Forms.Button
    Friend WithEvents pr_LoadButton As System.Windows.Forms.Button
    Friend WithEvents id_LoadButton As System.Windows.Forms.Button
    Friend WithEvents pr_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents id_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents pr_OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents id_OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TitleListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents CoListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TBListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TidListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents TitleMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents TitleAddMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitleDelMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitleCopyMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitlePasteMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitleCopyAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitleDelAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitleGetMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TitleEditMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TidComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TBComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CoComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TitleComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents PrReuseNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TimeoutNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents WayComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents AntiCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents PrCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnonyCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents BetterNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents SetButton As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ModeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents CoMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CoAddMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoEditMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoDelMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoCopyMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoPasteMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoCopyAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoDelAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoGetMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents TIDAddMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDEditMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDDelMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDCopyMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDPasteMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDCopyAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDDelAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIDGetMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents TBAddMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBEditMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBDelMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBCopyMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBPasteMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBCopyAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBDelAMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TBFidMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents BZTBTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BZTestButton As System.Windows.Forms.Button

End Class
