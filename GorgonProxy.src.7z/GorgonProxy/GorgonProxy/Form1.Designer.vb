﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ClearAllButton = New System.Windows.Forms.Button()
        Me.ExAllButton = New System.Windows.Forms.Button()
        Me.CopyAllButton = New System.Windows.Forms.Button()
        Me.SucListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PasteButton = New System.Windows.Forms.Button()
        Me.CopyUntestButton = New System.Windows.Forms.Button()
        Me.PrTextBox = New System.Windows.Forms.TextBox()
        Me.TestButton = New System.Windows.Forms.Button()
        Me.SeizeStopButton = New System.Windows.Forms.Button()
        Me.SeizeButton = New System.Windows.Forms.Button()
        Me.SettingsButton = New System.Windows.Forms.Button()
        Me.TestStopButton = New System.Windows.Forms.Button()
        Me.GetUpdate = New System.Windows.Forms.Button()
        Me.AuthorButton = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.TestProgressBar = New System.Windows.Forms.ProgressBar()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyChsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExChsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearChsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ClearAllButton)
        Me.GroupBox1.Controls.Add(Me.ExAllButton)
        Me.GroupBox1.Controls.Add(Me.CopyAllButton)
        Me.GroupBox1.Controls.Add(Me.SucListView)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(273, 295)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "成功区（右键操作）"
        '
        'ClearAllButton
        '
        Me.ClearAllButton.Location = New System.Drawing.Point(194, 266)
        Me.ClearAllButton.Name = "ClearAllButton"
        Me.ClearAllButton.Size = New System.Drawing.Size(73, 23)
        Me.ClearAllButton.TabIndex = 3
        Me.ClearAllButton.Text = "清空全部"
        Me.ClearAllButton.UseVisualStyleBackColor = True
        '
        'ExAllButton
        '
        Me.ExAllButton.Location = New System.Drawing.Point(98, 266)
        Me.ExAllButton.Name = "ExAllButton"
        Me.ExAllButton.Size = New System.Drawing.Size(73, 23)
        Me.ExAllButton.TabIndex = 2
        Me.ExAllButton.Text = "导出全部"
        Me.ExAllButton.UseVisualStyleBackColor = True
        '
        'CopyAllButton
        '
        Me.CopyAllButton.Location = New System.Drawing.Point(6, 266)
        Me.CopyAllButton.Name = "CopyAllButton"
        Me.CopyAllButton.Size = New System.Drawing.Size(73, 23)
        Me.CopyAllButton.TabIndex = 1
        Me.CopyAllButton.Text = "复制全部"
        Me.CopyAllButton.UseVisualStyleBackColor = True
        '
        'SucListView
        '
        Me.SucListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.SucListView.ContextMenuStrip = Me.ContextMenuStrip1
        Me.SucListView.FullRowSelect = True
        Me.SucListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.SucListView.Location = New System.Drawing.Point(6, 20)
        Me.SucListView.Name = "SucListView"
        Me.SucListView.Size = New System.Drawing.Size(261, 237)
        Me.SucListView.TabIndex = 0
        Me.SucListView.UseCompatibleStateImageBehavior = False
        Me.SucListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "代理"
        Me.ColumnHeader1.Width = 150
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "超时"
        Me.ColumnHeader2.Width = 100
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PasteButton)
        Me.GroupBox2.Controls.Add(Me.CopyUntestButton)
        Me.GroupBox2.Controls.Add(Me.PrTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(291, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(242, 295)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "未检测（一行一个）"
        '
        'PasteButton
        '
        Me.PasteButton.Location = New System.Drawing.Point(124, 266)
        Me.PasteButton.Name = "PasteButton"
        Me.PasteButton.Size = New System.Drawing.Size(112, 23)
        Me.PasteButton.TabIndex = 37
        Me.PasteButton.Text = "粘贴"
        Me.PasteButton.UseVisualStyleBackColor = True
        '
        'CopyUntestButton
        '
        Me.CopyUntestButton.Location = New System.Drawing.Point(6, 266)
        Me.CopyUntestButton.Name = "CopyUntestButton"
        Me.CopyUntestButton.Size = New System.Drawing.Size(112, 23)
        Me.CopyUntestButton.TabIndex = 36
        Me.CopyUntestButton.Text = "复制"
        Me.CopyUntestButton.UseVisualStyleBackColor = True
        '
        'PrTextBox
        '
        Me.PrTextBox.Location = New System.Drawing.Point(6, 20)
        Me.PrTextBox.Multiline = True
        Me.PrTextBox.Name = "PrTextBox"
        Me.PrTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.PrTextBox.Size = New System.Drawing.Size(230, 239)
        Me.PrTextBox.TabIndex = 15
        '
        'TestButton
        '
        Me.TestButton.Location = New System.Drawing.Point(540, 154)
        Me.TestButton.Name = "TestButton"
        Me.TestButton.Size = New System.Drawing.Size(75, 23)
        Me.TestButton.TabIndex = 33
        Me.TestButton.Text = "测试代理"
        Me.TestButton.UseVisualStyleBackColor = True
        '
        'SeizeStopButton
        '
        Me.SeizeStopButton.Enabled = False
        Me.SeizeStopButton.Location = New System.Drawing.Point(539, 113)
        Me.SeizeStopButton.Name = "SeizeStopButton"
        Me.SeizeStopButton.Size = New System.Drawing.Size(75, 23)
        Me.SeizeStopButton.TabIndex = 32
        Me.SeizeStopButton.Text = "停止获取"
        Me.SeizeStopButton.UseVisualStyleBackColor = True
        '
        'SeizeButton
        '
        Me.SeizeButton.Location = New System.Drawing.Point(539, 72)
        Me.SeizeButton.Name = "SeizeButton"
        Me.SeizeButton.Size = New System.Drawing.Size(75, 23)
        Me.SeizeButton.TabIndex = 31
        Me.SeizeButton.Text = "获取代理"
        Me.SeizeButton.UseVisualStyleBackColor = True
        '
        'SettingsButton
        '
        Me.SettingsButton.Location = New System.Drawing.Point(539, 32)
        Me.SettingsButton.Name = "SettingsButton"
        Me.SettingsButton.Size = New System.Drawing.Size(75, 23)
        Me.SettingsButton.TabIndex = 30
        Me.SettingsButton.Text = "设置"
        Me.SettingsButton.UseVisualStyleBackColor = True
        '
        'TestStopButton
        '
        Me.TestStopButton.Enabled = False
        Me.TestStopButton.Location = New System.Drawing.Point(540, 194)
        Me.TestStopButton.Name = "TestStopButton"
        Me.TestStopButton.Size = New System.Drawing.Size(75, 23)
        Me.TestStopButton.TabIndex = 34
        Me.TestStopButton.Text = "停止测试"
        Me.TestStopButton.UseVisualStyleBackColor = True
        '
        'GetUpdate
        '
        Me.GetUpdate.Location = New System.Drawing.Point(540, 278)
        Me.GetUpdate.Name = "GetUpdate"
        Me.GetUpdate.Size = New System.Drawing.Size(75, 23)
        Me.GetUpdate.TabIndex = 35
        Me.GetUpdate.Text = "获取更新"
        Me.GetUpdate.UseVisualStyleBackColor = True
        '
        'AuthorButton
        '
        Me.AuthorButton.Location = New System.Drawing.Point(540, 235)
        Me.AuthorButton.Name = "AuthorButton"
        Me.AuthorButton.Size = New System.Drawing.Size(75, 23)
        Me.AuthorButton.TabIndex = 36
        Me.AuthorButton.Text = "联系作者"
        Me.AuthorButton.UseVisualStyleBackColor = True
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "*.txt"
        Me.SaveFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'TestProgressBar
        '
        Me.TestProgressBar.Location = New System.Drawing.Point(12, 313)
        Me.TestProgressBar.Name = "TestProgressBar"
        Me.TestProgressBar.Size = New System.Drawing.Size(603, 28)
        Me.TestProgressBar.TabIndex = 37
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyChsMenu, Me.ExChsMenu, Me.ClearChsMenu})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(125, 70)
        '
        'CopyChsMenu
        '
        Me.CopyChsMenu.Name = "CopyChsMenu"
        Me.CopyChsMenu.Size = New System.Drawing.Size(124, 22)
        Me.CopyChsMenu.Text = "复制选中"
        '
        'ExChsMenu
        '
        Me.ExChsMenu.Name = "ExChsMenu"
        Me.ExChsMenu.Size = New System.Drawing.Size(124, 22)
        Me.ExChsMenu.Text = "导出选中"
        '
        'ClearChsMenu
        '
        Me.ClearChsMenu.Name = "ClearChsMenu"
        Me.ClearChsMenu.Size = New System.Drawing.Size(124, 22)
        Me.ClearChsMenu.Text = "删除选中"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(627, 353)
        Me.Controls.Add(Me.TestProgressBar)
        Me.Controls.Add(Me.AuthorButton)
        Me.Controls.Add(Me.GetUpdate)
        Me.Controls.Add(Me.TestStopButton)
        Me.Controls.Add(Me.TestButton)
        Me.Controls.Add(Me.SeizeStopButton)
        Me.Controls.Add(Me.SeizeButton)
        Me.Controls.Add(Me.SettingsButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "灵蛇·代理检测 - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents SucListView As System.Windows.Forms.ListView
    Friend WithEvents ClearAllButton As System.Windows.Forms.Button
    Friend WithEvents ExAllButton As System.Windows.Forms.Button
    Friend WithEvents CopyAllButton As System.Windows.Forms.Button
    Friend WithEvents PrTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TestButton As System.Windows.Forms.Button
    Friend WithEvents SeizeStopButton As System.Windows.Forms.Button
    Friend WithEvents SeizeButton As System.Windows.Forms.Button
    Friend WithEvents SettingsButton As System.Windows.Forms.Button
    Friend WithEvents TestStopButton As System.Windows.Forms.Button
    Friend WithEvents GetUpdate As System.Windows.Forms.Button
    Friend WithEvents PasteButton As System.Windows.Forms.Button
    Friend WithEvents CopyUntestButton As System.Windows.Forms.Button
    Friend WithEvents AuthorButton As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents TestProgressBar As System.Windows.Forms.ProgressBar
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyChsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExChsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearChsMenu As System.Windows.Forms.ToolStripMenuItem

End Class
