﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports GorgonProxy.Utility
Imports SkinSharp

Public Class Form1

    'Seize
    Private PrSource(-1) As String
    Private REText As String
    Private SeizeNdStop As Boolean
    'Test
    Private Timeout As Integer
    Private TrNum As Integer
    Private TestNdStop As Boolean
    Private EndCount As Integer
    Private TestUrl As String
    Private KW As String
    Private ToTest(-1) As String
    Private LockObj As New Object()
    Private Success As Integer
    'Controls
    Private Skin As SkinH_Net

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        File.WriteAllText(Directory.GetCurrentDirectory() + "\source.txt", Form2.SrcTextBox.Text, Encoding.Default)

        Dim sw As New StreamWriter(Directory.GetCurrentDirectory() + "\pr.dat", False, Encoding.Default)
        sw.AutoFlush = True
        For Each item As ListViewItem In SucListView.Items
            sw.WriteLine(item.SubItems(0).Text)
        Next
        sw.Close()

        End
    End Sub

    Private Sub CopyAllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyAllButton.Click
        If SucListView.Items.Count = 0 Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "无内容可复制！")
            Exit Sub
        End If
        Dim text As New StringBuilder()
        For Each item As ListViewItem In SucListView.Items
            text.AppendLine(item.SubItems(0).Text)
        Next
        Clipboard.SetText(text.ToString())
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "复制成功！")
    End Sub

    Private Sub ExAllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExAllButton.Click
        If SucListView.Items.Count = 0 Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "无内容可导出！")
            Exit Sub
        End If
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sw As New StreamWriter(SaveFileDialog1.FileName, False, Encoding.Default)
            sw.AutoFlush = True
            For Each item As ListViewItem In SucListView.Items
                sw.WriteLine(item.SubItems(0).Text)
            Next
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导出成功！")
        End If
    End Sub

    Private Sub ClearAllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearAllButton.Click
        If MessageBox.Show("确定要清空么？", "", MessageBoxButtons.OKCancel) = DialogResult.OK Then
            SucListView.Items.Clear()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已清空。")
        End If
    End Sub

    Private Sub CopyUntestButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyUntestButton.Click
        If PrTextBox.Text <> "" Then
            Clipboard.SetText(PrTextBox.Text)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "复制成功！")
        End If
    End Sub

    Private Sub PasteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteButton.Click
        PrTextBox.AppendText(Clipboard.GetText())
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "粘贴成功！")
    End Sub

    Private Sub SettingsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsButton.Click
        Form2.ShowDialog()
    End Sub

    Private Sub AuthorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AuthorButton.Click
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub GetUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetUpdate.Click
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub Seize()

        Dim wc As New WizardHTTP
        Dim re As New Regex(REText)
        For i As Integer = 0 To PrSource.Length - 1
            Try
                If SeizeNdStop Then Exit For
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString(PrSource(i))
                Dim rms As MatchCollection = re.Matches(retstr)
                For Each x As Match In rms
                    PrTextBox.AppendText(x.Value + vbCrLf)
                Next
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + "第 " + (i + 1).ToString() + " 页获取完成...")
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + "第 " + (i + 1).ToString() + " 页获取失败...")
            End Try
        Next
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "全部已完成。")
        SeizeButton.Enabled = True
        SeizeStopButton.Enabled = False

    End Sub

    Private Sub SeizeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SeizeButton.Click
        Try
            SeizeButton.Enabled = False
            PrSource = Form2.SrcTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
            If PrSource.Length = 0 Then Throw New Exception("无网页可获取...")
            REText = Form2.RETextBox.Text
            If REText = "" Then Throw New Exception("正则表达式不能为空！")
            SeizeNdStop = False
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "开始获取...")
            Dim tr As New Thread(AddressOf Seize)
            tr.Start()
            SeizeStopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            SeizeButton.Enabled = True
        End Try
    End Sub

    Private Sub SeizeStopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SeizeStopButton.Click
        SeizeNdStop = True
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If File.Exists(Directory.GetCurrentDirectory() + "\source.txt") Then
            Form2.SrcTextBox.Text = File.ReadAllText(Directory.GetCurrentDirectory() + "\source.txt", Encoding.Default)
        End If

        If File.Exists(Directory.GetCurrentDirectory() + "\pr.dat") Then
            Dim list As String() = File.ReadAllLines(Directory.GetCurrentDirectory() + "\pr.dat")
            For Each pr As String In list
                SucListView.Items.Add(pr)
            Next
        End If
    End Sub

    Private Sub TestStopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestStopButton.Click
        TestNdStop = True
    End Sub

    Private Sub Test(ByVal index As Integer)
        Dim wc As New WizardHTTP
        wc.TimeOut = Timeout
        wc.ReadWriteTimeOut = Timeout
        For i As Integer = index To ToTest.Length - 1 Step TrNum
            Try
                If TestNdStop Then Exit For
                TestProgressBar.Value += 1
                wc.SetDefaultHeader()
                wc.Proxy = New WebProxy(ToTest(i))
                Dim timecount As Integer = Environment.TickCount
                Dim retstr As String = wc.DownloadString(TestUrl)
                timecount = Environment.TickCount - timecount
                If retstr.IndexOf(KW) <> -1 Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + ToTest(i) + " 检测成功！超时：" + timecount.ToString())
                    Interlocked.Increment(Success)
                    SyncLock LockObj
                        Dim item As New ListViewItem(New String() {ToTest(i), timecount.ToString()})
                        SucListView.Items.Add(item)
                    End SyncLock
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + ToTest(i) + " 检测失败！")
                End If
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ToTest(i) + " 检测失败！")
            End Try
        Next
        Interlocked.Decrement(EndCount)
    End Sub

    Private Sub TestButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestButton.Click
        Try
            TestButton.Enabled = False
            ToTest = PrTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
            If ToTest.Length = 0 Then Throw New Exception("无内容可检测！")
            TestUrl = Form2.TestURLTextBox.Text
            If Not TestUrl.StartsWith("http://") Then
                Throw New Exception("请检查你的URL格式！")
            End If
            KW = Form2.KWTextBox.Text
            Timeout = Form2.TimeoutNumeric.Value
            TrNum = Form2.TrNumeric.Value
            EndCount = TrNum
            Success = 0
            TestNdStop = False
            TestProgressBar.Value = 0
            TestProgressBar.Maximum = ToTest.Length
            
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "开始检测...")

            Dim tr As New Thread(AddressOf TestInit)
            tr.Start()
            TestStopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            TestButton.Enabled = True
        End Try
    End Sub

    Private Sub TestInit()
        For i As Integer = 0 To TrNum - 1
            Dim tr As New Thread(AddressOf Test)
            tr.Start(i)
        Next

        While EndCount <> 0 : Thread.Sleep(200) : End While

        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "测试完毕！共有代理{0}个，成功{1}个。", ToTest.Length, Success)
        TestButton.Enabled = True
        TestStopButton.Enabled = False
    End Sub

    Private Sub CopyChsMenu_Click(sender As System.Object, e As System.EventArgs) Handles CopyChsMenu.Click
        Dim lists = SucListView.SelectedIndices
        If lists.Count = 0 Then Return

        Dim sb As New StringBuilder()
        For Each index As Integer In lists
            sb.Append(SucListView.Items(index).Text + vbCrLf)
        Next
        Clipboard.SetText(sb.ToString())
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "复制成功！")
    End Sub

    Private Sub ExChsMenu_Click(sender As System.Object, e As System.EventArgs) Handles ExChsMenu.Click
        Dim lists = SucListView.SelectedIndices
        If lists.Count = 0 Then Return

        If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim sw As New StreamWriter(SaveFileDialog1.FileName, False, Encoding.Default)
            sw.AutoFlush = True
            For Each index As Integer In lists
                sw.WriteLine(SucListView.Items(index).Text)
            Next
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导出成功！")
        End If
    End Sub

    Private Sub ClearChsMenu_Click(sender As System.Object, e As System.EventArgs) Handles ClearChsMenu.Click
        If MessageBox.Show("确定要清空么？", "", MessageBoxButtons.OKCancel) = DialogResult.OK Then
            Dim lists = SucListView.SelectedIndices
            If lists.Count = 0 Then Return

            For i As Integer = lists.Count - 1 To 0 Step -1
                SucListView.Items.RemoveAt(lists(i))
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已清除！")
        End If
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        Skin = New SkinH_Net
        Skin.AttachRes(My.Resources.MacOSX, My.Resources.MacOSX.Length, "", 0, 0, 0)
        Skin.SetAero(1)
    End Sub
End Class
