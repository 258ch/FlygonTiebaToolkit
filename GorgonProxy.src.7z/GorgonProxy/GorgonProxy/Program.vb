﻿Imports System.Net

Public Class Program

    Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

    Public Shared Sub main()
        Try
            ServicePointManager.MaxServicePoints = 512
            ServicePointManager.Expect100Continue = False
            Control.CheckForIllegalCrossThreadCalls = False

            AllocConsole()
            Console.Title = "信息输出 for 灵蛇"
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("欢迎使用·灵蛇" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine("Powered by VB.NET, applicating RegEx." + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("Copyright <C> 2012-2013 飞龙 - 苍海·国际")
            Console.WriteLine("All rights reserved." + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine("感谢苍海·国际、风凝圣域、冰焰技术联盟和正在使用的你～" + vbCrLf)

            'Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(Form1)
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(ex.Message)
            Console.ReadKey()
        End Try
    End Sub
End Class
