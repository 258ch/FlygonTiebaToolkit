﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TestURLTextBox = New System.Windows.Forms.TextBox()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TimeoutNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.RETextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SrcTextBox = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.KWTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.KWTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TestURLTextBox)
        Me.GroupBox1.Controls.Add(Me.TrNumeric)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TimeoutNumeric)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.RETextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.SrcTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(343, 257)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 202)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 12)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "测试URL"
        '
        'TestURLTextBox
        '
        Me.TestURLTextBox.Location = New System.Drawing.Point(69, 199)
        Me.TestURLTextBox.Name = "TestURLTextBox"
        Me.TestURLTextBox.Size = New System.Drawing.Size(265, 21)
        Me.TestURLTextBox.TabIndex = 41
        Me.TestURLTextBox.Text = "http://tieba.baidu.com/dc/common/tbs"
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(234, 172)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(100, 21)
        Me.TrNumeric.TabIndex = 40
        Me.TrNumeric.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(175, 174)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 12)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "线程数"
        '
        'TimeoutNumeric
        '
        Me.TimeoutNumeric.Location = New System.Drawing.Point(69, 172)
        Me.TimeoutNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.TimeoutNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TimeoutNumeric.Name = "TimeoutNumeric"
        Me.TimeoutNumeric.Size = New System.Drawing.Size(100, 21)
        Me.TimeoutNumeric.TabIndex = 38
        Me.TimeoutNumeric.Value = New Decimal(New Integer() {4000, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 174)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 12)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "超时(ms)"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 148)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(29, 12)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "正则"
        '
        'RETextBox
        '
        Me.RETextBox.Location = New System.Drawing.Point(69, 145)
        Me.RETextBox.Name = "RETextBox"
        Me.RETextBox.Size = New System.Drawing.Size(265, 21)
        Me.RETextBox.TabIndex = 35
        Me.RETextBox.Text = "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}.\d{2,4}"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 12)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "代理源"
        '
        'SrcTextBox
        '
        Me.SrcTextBox.Location = New System.Drawing.Point(69, 20)
        Me.SrcTextBox.Multiline = True
        Me.SrcTextBox.Name = "SrcTextBox"
        Me.SrcTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SrcTextBox.Size = New System.Drawing.Size(265, 119)
        Me.SrcTextBox.TabIndex = 33
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 229)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 12)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "关键字"
        '
        'KWTextBox
        '
        Me.KWTextBox.Location = New System.Drawing.Point(69, 226)
        Me.KWTextBox.Name = "KWTextBox"
        Me.KWTextBox.Size = New System.Drawing.Size(265, 21)
        Me.KWTextBox.TabIndex = 47
        Me.KWTextBox.Text = "tbs"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(367, 281)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Settings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents SrcTextBox As System.Windows.Forms.TextBox
    Public WithEvents RETextBox As System.Windows.Forms.TextBox
    Public WithEvents TimeoutNumeric As System.Windows.Forms.NumericUpDown
    Public WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Public WithEvents TestURLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents KWTextBox As System.Windows.Forms.TextBox
End Class
