﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Drawing
Imports 极光EX.MyFunctions

Public Class Form1

    Private Ori_ID As String
    Private Ori_PW As String
    Private PrList(-1) As String
    Private PrUbd As Integer = -1
    Private BS As String
    Private LogTr As Thread
    Private IDList(-1) As String
    Private IDUbd As Integer = -1
    Private Delay As Integer
    Private Timeout As Integer
    Private UseList As Boolean
    Private AntiVcode As Boolean
    Private SucSW As StreamWriter
    Private CdsIndex As Integer

    Public Declare Function LoadCdsFromBuffer Lib "DuoWei.dll" (ByVal FileBuffer As Byte(), ByVal FileLen As Integer) As Integer

    Public Declare Function GetVcodeFromBuffer Lib "DuoWei.dll" (ByVal CdsIndex As Integer, ByVal ImgBuffer As Byte(), ByVal ImgBufLen As Integer, ByVal Vcode As Byte()) As Boolean

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'CdsIndex = LoadCdsFromBuffer(My.Resources.baidu, My.Resources.baidu.Length)
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 Then
            BS = BSTextBox.Text
            BSTextBox.Text = ""
            BSPictureBox.Image = Nothing
        End If
    End Sub

    Private Sub CopyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyButton.Click
        If SucTextBox.Text <> "" Then
            Clipboard.SetText(SucTextBox.Text)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "复制成功！")
        End If
    End Sub

    Private Sub ControlButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ControlButton.Click
        If ControlButton.Text = "注册开始" Then
            Try
                ControlButton.Enabled = False

                If PWTextBox.Text = "" Then
                    Throw New Exception("密码不能为空！")
                End If

                UseList = Not IDRadioButton.Checked
                If Not UseList Then
                    If IDTextBox.Text = "" Then Throw New Exception("用户名不得为空！")
                    Ori_ID = IDTextBox.Text
                Else
                    If IDUbd = -1 Then Throw New Exception("无导入ID！")
                End If

                Ori_PW = PWTextBox.Text
                Delay = DelayNumeric.Value
                Timeout = Form2.TimeoutNumeric.Value
                AntiVcode = AntiCheckBox.Checked
                SucSW = New StreamWriter(Directory.GetCurrentDirectory() + "\成功区.txt", True, Encoding.Default)
                SucSW.AutoFlush = True
                BSTextBox.Enabled = True
                PrList = Split(Form2.PrTextBox.Text, vbCrLf)
                PrUbd = PrList.Length - 1
                If PrList(PrUbd) = "" Then
                    PrUbd -= 1
                End If

                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "注册开始...")
                LogTr = New Thread(AddressOf Log)
                LogTr.Start()

                ControlButton.Text = "注册停止"
                ControlButton.Enabled = True

            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
                ControlButton.Enabled = True
            End Try

        Else '注册停止
            LogTr.Abort()
            TrEnd()
        End If
    End Sub

    Private Sub Log()

        Dim wc As New WizardHTTP
        wc.TimeOut = Timeout
        wc.ReadWriteTimeOut = Timeout
        Dim jam As New Jammer
        Dim i_id As Integer = 0
        Dim i_pr As Integer = 0
        While True
            Try
                Dim id As String = ""
                If UseList Then
                    If i_id > IDUbd Then Exit While
                    id = IDList(i_id)
                    i_id += 1
                Else
                    id = jam.Jammer(Ori_ID)
                End If
                Dim pw As String = jam.Jammer(Ori_PW)
                Dim cip As String = GetCip()
                Dim poststr As String = "appid=1&clientid=000000000000000&clientip=" + cip + "&crypttype=1&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&tpl=netdisk&username=" + id
                Dim sign As String = MD5Encrypt(poststr + "&sign_key=0c2d71b9d3aee3947c59a7480df05e85", Encoding.Default).ToLower()
                poststr = "username=" + URLEncoGBK(id) + "&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&crypttype=1&clientid=000000000000000&clientip=" + cip + "&tpl=netdisk&appid=1&sig=" + sign
                If PrUbd <> -1 Then wc.Proxy = New WebProxy(PrList(i_pr))
                wc.SetDefaultHeaderAdr()
                wc.Headers.Set(HttpRequestHeader.UserAgent, "Dalvik/1.4.0 (Linux; U; Android 2.3.3; sdk Build/GRI34)")
                Dim retstr As String = wc.UploadString("http://passport.baidu.com/sapi/reg", poststr)
                '需要验证码的判断
                Dim left As Integer, right As Integer
                If retstr.IndexOf("needvcode"":""1") <> -1 Then
                    left = retstr.IndexOf("vcodestr") + 11
                    right = retstr.IndexOf("""", left)
                    Dim vcode As String = retstr.Substring(left, right - left)
                    wc.SetDefaultHeader()
                    wc.Proxy = Nothing
                    Dim picdata As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                    Dim tmpbs As String = ""
                    If AntiVcode Then
                        Dim tmp(64 - 1) As Byte
                        GetVcodeFromBuffer(CdsIndex, picdata, picdata.Length, tmp)
                        tmpbs = Encoding.Default.GetString(tmp).Substring(0, 4)
                    Else
                        Dim pic As Image = Image.FromStream(New MemoryStream(picdata))
                        BSPictureBox.Image = pic
                        BS = ""
                        While BS = "" : Thread.Sleep(200) : End While
                        tmpbs = BS
                    End If
                    'cip = GetCip()
                    poststr = "appid=1&clientid=000000000000000&clientip=" + cip + "&crypttype=1&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&tpl=netdisk&username=" + id + "&vcodestr=" + vcode + "&verifycode=" + tmpbs
                    sign = MD5Encrypt(poststr + "&sign_key=0c2d71b9d3aee3947c59a7480df05e85", Encoding.Default).ToLower()
                    poststr = "username=" + URLEncoGBK(id) + "&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&crypttype=1&clientid=000000000000000&clientip=" + cip + "&verifycode=" + tmpbs + "&vcodestr=" + vcode + "&tpl=netdisk&appid=1" + "&sig=" + sign
                    If PrUbd <> -1 Then wc.Proxy = New WebProxy(PrList(i_pr))
                    wc.SetDefaultHeaderAdr()
                    wc.Headers.Set(HttpRequestHeader.UserAgent, "Dalvik/1.4.0 (Linux; U; Android 2.3.3; sdk Build/GRI34)")
                    retstr = wc.UploadString("http://passport.baidu.com/sapi/reg", poststr)
                End If

                left = retstr.IndexOf("errno") + 8
                right = retstr.IndexOf("""", left)
                Dim errno As String = retstr.Substring(left, right - left)
                If errno = "0" Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + id + " 注册成功！")
                    SucTextBox.AppendText(id + ":" + pw + vbCrLf)
                    '写文件
                    SucSW.WriteLine(id + ":" + pw + vbCrLf)
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + id + " 注册失败！错误信息：" + errno)
                    If errno = "43" Then '换代理
                        If i_pr = PrUbd Then : i_pr = 0 : Else : i_pr += 1 : End If
                    End If
                End If
                Thread.Sleep(Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
                If i_pr = PrUbd Then : i_pr = 0 : Else : i_pr += 1 : End If '换代理
            End Try
        End While
        TrEnd()
    End Sub

    Private Sub TrEnd() '注册结束后的操作
        BSPictureBox.Image = Nothing
        BSTextBox.Text = ""
        BSTextBox.Enabled = False
        SucSW.Close()
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "注册完毕...")
        ControlButton.Text = "注册开始"
    End Sub

    Private Sub ProxyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProxyButton.Click
        Form2.ShowDialog()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Sub OutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OutButton.Click
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sw As New StreamWriter(SaveFileDialog1.FileName, True, Encoding.Default)
            sw.Write(SucTextBox.Text)
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导出完毕！")
        End If
    End Sub

    Private Sub FileRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileRadioButton.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sr As New StreamReader(OpenFileDialog1.FileName, Encoding.Default)
            IDList = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            IDUbd = IDList.Length - 1
            If IDList(IDUbd) = "" Then
                IDUbd -= 1
            End If
            FileTextBox.Text = OpenFileDialog1.FileName
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已导入{0}个用户名。", IDUbd + 1)
        Else
            FileRadioButton.Checked = False
            IDRadioButton.Checked = True
        End If
    End Sub

    Private Function GetCip() As String
        Dim ran As New Random
        Dim num1 As String = ran.Next(0, 255).ToString()
        Dim num2 As String = ran.Next(0, 255).ToString()
        Dim num3 As String = ran.Next(0, 255).ToString()
        Dim num4 As String = ran.Next(0, 255).ToString()
        Return num1 + "." + num2 + "." + num3 + "." + num4
    End Function
End Class
