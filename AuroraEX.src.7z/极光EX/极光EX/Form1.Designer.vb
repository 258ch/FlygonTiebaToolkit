﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ControlButton = New System.Windows.Forms.Button()
        Me.ProxyButton = New System.Windows.Forms.Button()
        Me.AntiCheckBox = New System.Windows.Forms.CheckBox()
        Me.BSTextBox = New System.Windows.Forms.TextBox()
        Me.BSPictureBox = New System.Windows.Forms.PictureBox()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FileTextBox = New System.Windows.Forms.TextBox()
        Me.FileRadioButton = New System.Windows.Forms.RadioButton()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.IDRadioButton = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CopyButton = New System.Windows.Forms.Button()
        Me.OutButton = New System.Windows.Forms.Button()
        Me.SucTextBox = New System.Windows.Forms.TextBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.GroupBox1.SuspendLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ControlButton)
        Me.GroupBox1.Controls.Add(Me.ProxyButton)
        Me.GroupBox1.Controls.Add(Me.AntiCheckBox)
        Me.GroupBox1.Controls.Add(Me.BSTextBox)
        Me.GroupBox1.Controls.Add(Me.BSPictureBox)
        Me.GroupBox1.Controls.Add(Me.DelayNumeric)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.PWTextBox)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.FileTextBox)
        Me.GroupBox1.Controls.Add(Me.FileRadioButton)
        Me.GroupBox1.Controls.Add(Me.IDTextBox)
        Me.GroupBox1.Controls.Add(Me.IDRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(301, 245)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'ControlButton
        '
        Me.ControlButton.Location = New System.Drawing.Point(38, 208)
        Me.ControlButton.Name = "ControlButton"
        Me.ControlButton.Size = New System.Drawing.Size(226, 31)
        Me.ControlButton.TabIndex = 12
        Me.ControlButton.Text = "注册开始"
        Me.ControlButton.UseVisualStyleBackColor = True
        '
        'ProxyButton
        '
        Me.ProxyButton.Location = New System.Drawing.Point(164, 131)
        Me.ProxyButton.Name = "ProxyButton"
        Me.ProxyButton.Size = New System.Drawing.Size(100, 44)
        Me.ProxyButton.TabIndex = 11
        Me.ProxyButton.Text = "代理设置"
        Me.ProxyButton.UseVisualStyleBackColor = True
        '
        'AntiCheckBox
        '
        Me.AntiCheckBox.AutoSize = True
        Me.AntiCheckBox.Checked = True
        Me.AntiCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AntiCheckBox.Location = New System.Drawing.Point(164, 183)
        Me.AntiCheckBox.Name = "AntiCheckBox"
        Me.AntiCheckBox.Size = New System.Drawing.Size(84, 16)
        Me.AntiCheckBox.TabIndex = 10
        Me.AntiCheckBox.Text = "验证码识别"
        Me.AntiCheckBox.UseVisualStyleBackColor = True
        '
        'BSTextBox
        '
        Me.BSTextBox.Enabled = False
        Me.BSTextBox.Location = New System.Drawing.Point(38, 181)
        Me.BSTextBox.Name = "BSTextBox"
        Me.BSTextBox.Size = New System.Drawing.Size(116, 21)
        Me.BSTextBox.TabIndex = 9
        '
        'BSPictureBox
        '
        Me.BSPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox.Location = New System.Drawing.Point(38, 131)
        Me.BSPictureBox.Name = "BSPictureBox"
        Me.BSPictureBox.Size = New System.Drawing.Size(116, 44)
        Me.BSPictureBox.TabIndex = 8
        Me.BSPictureBox.TabStop = False
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(164, 100)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(100, 21)
        Me.DelayNumeric.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(36, 102)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "间隔(ms)"
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(164, 73)
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.Size = New System.Drawing.Size(100, 21)
        Me.PWTextBox.TabIndex = 5
        Me.PWTextBox.Text = "%c%c%c%i%i%i"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(36, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "密码"
        '
        'FileTextBox
        '
        Me.FileTextBox.Location = New System.Drawing.Point(164, 46)
        Me.FileTextBox.Name = "FileTextBox"
        Me.FileTextBox.ReadOnly = True
        Me.FileTextBox.Size = New System.Drawing.Size(100, 21)
        Me.FileTextBox.TabIndex = 3
        '
        'FileRadioButton
        '
        Me.FileRadioButton.AutoSize = True
        Me.FileRadioButton.Location = New System.Drawing.Point(38, 47)
        Me.FileRadioButton.Name = "FileRadioButton"
        Me.FileRadioButton.Size = New System.Drawing.Size(71, 16)
        Me.FileRadioButton.TabIndex = 2
        Me.FileRadioButton.Text = "导入文件"
        Me.FileRadioButton.UseVisualStyleBackColor = True
        '
        'IDTextBox
        '
        Me.IDTextBox.Location = New System.Drawing.Point(164, 19)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(100, 21)
        Me.IDTextBox.TabIndex = 1
        Me.IDTextBox.Text = "龙%s%s"
        '
        'IDRadioButton
        '
        Me.IDRadioButton.AutoSize = True
        Me.IDRadioButton.Checked = True
        Me.IDRadioButton.Location = New System.Drawing.Point(38, 21)
        Me.IDRadioButton.Name = "IDRadioButton"
        Me.IDRadioButton.Size = New System.Drawing.Size(59, 16)
        Me.IDRadioButton.TabIndex = 0
        Me.IDRadioButton.TabStop = True
        Me.IDRadioButton.Text = "用户名"
        Me.IDRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CopyButton)
        Me.GroupBox2.Controls.Add(Me.OutButton)
        Me.GroupBox2.Controls.Add(Me.SucTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(319, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(230, 245)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "成功区"
        '
        'CopyButton
        '
        Me.CopyButton.Location = New System.Drawing.Point(6, 216)
        Me.CopyButton.Name = "CopyButton"
        Me.CopyButton.Size = New System.Drawing.Size(104, 23)
        Me.CopyButton.TabIndex = 2
        Me.CopyButton.Text = "复制"
        Me.CopyButton.UseVisualStyleBackColor = True
        '
        'OutButton
        '
        Me.OutButton.Location = New System.Drawing.Point(120, 216)
        Me.OutButton.Name = "OutButton"
        Me.OutButton.Size = New System.Drawing.Size(104, 23)
        Me.OutButton.TabIndex = 1
        Me.OutButton.Text = "导出"
        Me.OutButton.UseVisualStyleBackColor = True
        '
        'SucTextBox
        '
        Me.SucTextBox.BackColor = System.Drawing.Color.White
        Me.SucTextBox.Location = New System.Drawing.Point(6, 20)
        Me.SucTextBox.Multiline = True
        Me.SucTextBox.Name = "SucTextBox"
        Me.SucTextBox.ReadOnly = True
        Me.SucTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SucTextBox.Size = New System.Drawing.Size(218, 190)
        Me.SucTextBox.TabIndex = 0
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "*.txt"
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "*.txt"
        Me.SaveFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 262)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents CopyButton As System.Windows.Forms.Button
    Friend WithEvents OutButton As System.Windows.Forms.Button
    Friend WithEvents SucTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProxyButton As System.Windows.Forms.Button
    Friend WithEvents AntiCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents BSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BSPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents FileTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FileRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents IDRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ControlButton As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog

End Class
