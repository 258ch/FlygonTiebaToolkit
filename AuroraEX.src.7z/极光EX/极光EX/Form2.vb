﻿Imports System.Net
Public Class Form2

    Private Sub Form2_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub

    Private Sub SeizeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SeizeButton.Click
        SeizeButton.Enabled = False
        Try
            Dim wc As New WizardHTTP
            wc.SetDefaultHeader()
            PrTextBox.Text = wc.DownloadString("http://www.ct0592.com/ctloadproxy/lists.txt")
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(MyFunctions.Time() + ex.Message)
        End Try
        SeizeButton.Enabled = True
    End Sub
End Class