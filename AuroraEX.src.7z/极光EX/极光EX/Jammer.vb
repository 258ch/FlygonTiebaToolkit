﻿Imports System.Text
Imports System.Threading

'v1.0 生成时间 2012.2.14 by 飞龙 - CHI

Public Class Jammer
    Inherits Random

    Private Const JPTable1 = "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをんがぎぐげごぢづでどざじずぜぞばびぶべぼぱぴぷぺぽぁぃぅぇぉゃゅょっーゐゑゎ"
    Private Const JPTable2 = "アイウエカキクケコサシスセソタチツテトナニヌネノハヒヘフホマミムメモヤユヨラリルレロワヲンガギグゲゴザジズゼゾダヂヅデドバビブベボパピプペポァィゥェォャュョッーヰヱヮヵヶ"
    Private Const BlockTable = "囗囚四囙囘囜回囝囡团囟因団囱囤囮囫囥困囵围园囯囬囪囧囨囲図囦囩固国囹囷图囶囻囸囼囿圀圂圃圄圆圅圁圈圊圉國圇圌圐圍圏圎園圓圕圑圔圙團圖圗圚圜圛圝圞"
    Private Const FormTable = "┌┬┐├┼┤└┴┘┌─┐││└─┘─━┄┅┈┉│┃┆┇┊┋┏┳┓┣╋┫┗┻┛┏━┓┃┃┗━┛┎┰┒┠╂┨┖┸┚┍┯┑┝┿┥┕┷┙╔╦╗╠╬╣╚╩╝╔═╗║║╚═╝╓╥╖╟╫╢╙╨╜╒╤╕╞╪╡╘╧╛┏┱┐┡╃┤└┴┘┌┲┓├╄┩└┴┘┌┬┐┟╁┧┗┻┛┏┳┓┞╀┦└┴┘┌┬┐┢╅┤┗┹┘┌┬┐├╆┪└┺┛┌┮┓├┾┫└┶┛┏┭┐┣┽┤┗┵┘┌┮┓┟╆┫┗┻┛┏┭┐┣╅┧┗┻┛┏┳┓┡╇┩└┴┘┌┬┐┢╈┪┗┻┛┏┳┓┞╄┫└┶┛┏┳┓┣╃┦┗┵┘┏┱┐┣╉┤┗┹┘┌┲┓├╊┫└┺┛╭╮╰╯╭─╮│╳│╰─╯╲╱╱╲"
    Private Const BlankTable = ""
    Private Const SurnameTable = "赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卞齐康伍余元卜顾孟平黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董"
    Private Const SignAscTable = "~!@#$%^&*()_+`-={}|""<>?[]\;'./,"
    Private Const SignWideTable = "。、！？：；﹑…‘’〝〞∕‖—﹛﹜〈〉﹝﹞「」〖〗《》〔〕『』【】﹐﹕﹔！？﹖﹏＇ˊ﹫︳＿︰﹌﹋ˋ―︴￣﹢﹦﹤﹟﹩﹠﹪﹡﹨﹍﹎ˇ﹊﹉︵︷︿︹︽_﹁﹃︻︶︸﹀︺︾﹂﹄︼﹙﹚﹛﹜＋－×÷﹢﹣±／＜＞﹤﹥·∶∴∵∷⊙∫∮∝∞∧∨≠≤≥≈≡≒∥＝≦≧≌∽≮≯∑∏∪∩∈⊿⌒√∟㏒㏑￠∠⊥％‰℅°℃℉′″〒¤○μ㎎㎏㎜㎝㎞㎡㏄㏎㏑㏒＄￡￥㏕♂♀△▽○◇□☆▲▼●◆■★◎¤〓▓▁▂▃▄▅▆▇█▉▊▋▌▍▎▏①②③④⑤⑥⑦⑧⑨⑩㈠㈡㈢㈣㈤㈥㈦㈧㈨㈩⑴⑵⑶⑷⑸⑹⑺⑻⑼⑽⑾⑿⒀⒁⒂⒃⒄⒅⒆⒇⒈⒉⒊⒋⒌⒍⒎⒏⒐⒑⒒⒓⒔⒕⒖⒗⒘⒙⒚⒛"

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal seed As Integer)
        MyBase.New(seed)
    End Sub

    Private Function GetLowerChar() As Char '%c
        Return ChrW(MyBase.Next(97, 122))
    End Function

    Private Function GetUpperChar() As Char '%C
        Return ChrW(MyBase.Next(65, 90))
    End Function

    Private Function GetNum() As Char '%i
        Return ChrW(MyBase.Next(48, 57))
    End Function

    Private Function GetChinese() As Char  '%s
        Return ChrW(MyBase.Next(19968, 40869))
        'GBK(ANSI):第一个字节的范围是0xb0-0xF7（即176-247），第二个字节的范围是0xA1-0xFE（即161-254）
        'UTF16:0x4e00~0x9fa5
    End Function

    Private Function GetJP1() As Char '%j 平假
        Return JPTable1.Chars(MyBase.Next(0, JPTable1.Length - 1))
    End Function

    Private Function GetJP2() As Char '%J 片假
        Return JPTable2.Chars(MyBase.Next(0, JPTable2.Length - 1))
    End Function

    Private Function GetBlock() As Char '%r
        Return BlockTable.Chars(MyBase.Next(0, BlockTable.Length - 1))
    End Function

    Private Function GetFormSign() As Char '%f
        Return FormTable.Chars(MyBase.Next(0, FormTable.Length - 1))
    End Function

    Private Function GetBlank() As Char  '%b
        Return BlankTable.Chars(MyBase.Next(0, BlankTable.Length - 1))
    End Function

    Private Function GetSurname() As Char '%n
        Return SurnameTable.Chars(MyBase.Next(0, SurnameTable.Length - 1))
    End Function

    Private Function GetSignAsc() As Char '%w
        Return SignAscTable.Chars(MyBase.Next(0, SignAscTable.Length - 1))
    End Function

    Private Function GetSignWide() As Char '%W
        Return SignWideTable.Chars(MyBase.Next(0, SignWideTable.Length - 1))
    End Function

    Public Function Jammer(ByVal text As String) As String
        Dim sb As New StringBuilder()
        For i As Integer = 0 To text.Length - 1
            Dim tmp1 As Char = text.Chars(i)
            If tmp1 = "%" Then
                If i = text.Length - 1 Then
                    sb.Append(tmp1)
                    Continue For
                End If
                Dim tmp2 As Char = text.Chars(i + 1)
                If tmp2 = "C" Then
                    sb.Append(GetUpperChar())
                    i += 1
                ElseIf tmp2 = "c" Then
                    sb.Append(GetLowerChar())
                    i += 1
                ElseIf tmp2 = "i" Then
                    sb.Append(GetNum())
                    i += 1
                ElseIf tmp2 = "s" Then
                    sb.Append(GetChinese())
                    i += 1
                ElseIf tmp2 = "b" Then
                    sb.Append(GetBlank())
                    i += 1
                ElseIf tmp2 = "r" Then
                    sb.Append(GetBlock())
                    i += 1
                ElseIf tmp2 = "f" Then
                    sb.Append(GetFormSign())
                    i += 1
                ElseIf tmp2 = "w" Then
                    sb.Append(GetSignAsc())
                    i += 1
                ElseIf tmp2 = "W" Then
                    sb.Append(GetSignWide())
                    i += 1
                ElseIf tmp2 = "j" Then
                    sb.Append(GetJP1())
                    i += 1
                ElseIf tmp2 = "J" Then
                    sb.Append(GetJP2())
                    i += 1
                ElseIf tmp2 = "n" Then
                    sb.Append(GetSurname())
                    i += 1
                Else
                    sb.Append(tmp1)
                End If
            Else
                sb.Append(tmp1)
            End If
        Next
        Return sb.ToString()
    End Function
End Class
