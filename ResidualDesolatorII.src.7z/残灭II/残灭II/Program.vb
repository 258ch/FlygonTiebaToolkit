﻿Imports System.Net

Public Class Program

    Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

    Public Shared Sub main()
        Try
            ServicePointManager.Expect100Continue = False
            ServicePointManager.MaxServicePoints = 512
            Windows.Forms.Control.CheckForIllegalCrossThreadCalls = False

            AllocConsole()
            Console.Title = "信息输出 for 残灭II"
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("欢迎使用 残灭II·末日审判 轻量级贴吧防御助手" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine("天罚之音，归来吧天神的末日审判！" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("本工具禁止作为商业用途，作者保留一切解释权利！")
            Console.WriteLine("Copyright <C> 2012-2013 飞龙 - 苍海·国际 & 冰焰技术联盟" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine("感谢苍海国际、风凝圣域、冰焰技术联盟和正在使用的你～" + vbCrLf)

            Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(Form1)
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(ex.Message)
            Console.ReadKey()
        End Try
    End Sub
End Class
