﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Text.RegularExpressions
Imports 残灭II.Utility
Imports 残灭II.TBOps
Imports 残灭II.Profile
Imports Sunisoft.IrisSkin

Public Class Form1

    'login
    Private UN As String
    Private PW As String
    Private Cookie As String
    Private BS As String
    'monitor
    Private KW As String
    Private FID As String
    Private NdPrison As Boolean
    Private ScanDelay As Integer
    Private OpDelay As Integer
    Private KeyWord(-1) As String
    Private TaskTr As Thread
    'skin
    Private Skin As SkinEngine

    'Private Way As Integer
    'Private StartPage As Integer
    'Private EndPage As Integer
    'Private NdStop As Boolean

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadUsr()
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        WayComboBox.SelectedIndex = 0
        'ModeComboBox.SelectedIndex = 0
        Skin = New SkinEngine(Me, New MemoryStream(My.Resources.Emerald))
    End Sub

    Private Sub LoadUsr()
        Dim buff(255) As Byte
        GetPrivateProfileString("settings", "cookie", "", buff, buff.Length, ".\settings.ini")
        Cookie = Encoding.Default.GetString(buff).Replace(ChrW(0), "")
        If Cookie <> "" Then
            ReDim buff(255)
            GetPrivateProfileString("settings", "username", "", buff, buff.Length, ".\settings.ini")
            UN = Encoding.Default.GetString(buff).Replace(ChrW(0), "")
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            LoginButton.Enabled = False
            ExitButton.Enabled = True
            IDTextBox.Text = UN
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "用户信息读取完毕...")
        End If
    End Sub

    Private Sub Login()
        Try
            Dim wc As New WizardHTTP
            Dim poststr As String = "_client_id=" + GetStampMobile(True) + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + ToBase64(PW) + "&un=" + URLEncoding(UN, Encoding.UTF8)
            wc.SetDefaultHeader(True)
            Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            Dim left As Integer = retstr.IndexOf("error_code"":5")

            If left <> -1 Then '验证码
                left = retstr.IndexOf("vcode_md5") + 12
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim vcode As String = retstr.Substring(left, right - left)
                wc.SetDefaultHeader()
                Dim pic As Image = Image.FromStream(New MemoryStream(wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)))
                BS = ""
                BSPictureBox.Image = pic
                BSTextBox.Enabled = True
                While BS = "" : Thread.Sleep(200) : End While
                BSTextBox.Enabled = False
                poststr = "_client_id=" + GetStampMobile(True) + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + ToBase64(PW) + "&un=" + URLEncoding(UN, Encoding.UTF8) + "&vcode=" + BS + "&vcode_md5=" + vcode
                wc.SetDefaultHeader(True)
                retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            End If

            Dim re As New Regex("BDUSS"":"".{192}")
            Dim rm As Match = re.Match(retstr)
            If Not rm.Success Then
                left = retstr.IndexOf("error_msg") + 12
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim errmsg As String = retstr.Substring(left, right - left)
                Throw New Exception(UN + " 登录失败！" + UnicodeDeco(errmsg))
            End If
            Cookie = "BDUSS=" + rm.Value.Substring(8, 192)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + UN + " 登陆成功！")
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            ExitButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Cookie = ""
        IDTextBox.Enabled = True
        PWTextBox.Enabled = True
        LoginButton.Enabled = True
        ExitButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已退出。")
    End Sub

    Private Sub LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginButton.Click
        Try
            LoginButton.Enabled = False
            UN = IDTextBox.Text
            PW = PWTextBox.Text
            If UN = "" Or PW = "" Then
                Throw New Exception("请填写用户名和密码！")
            End If
            'Way = WayComboBox.SelectedIndex
            Dim tr As New Thread(AddressOf Login)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 Then
            BS = BSTextBox.Text
            BSPictureBox.Image = Nothing
            BSTextBox.Text = ""
        End If
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If Cookie <> "" Then
            WritePrivateProfileString("settings", "cookie", Cookie, ".\settings.ini")
            WritePrivateProfileString("settings", "username", UN, ".\settings.ini")
        End If
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False

            If Cookie = "" Then Throw New Exception("请先登录！")
            If TBTextBox.Text = "" Then Throw New Exception("请填写贴吧！")
            KW = URLEncoding(TBTextBox.Text, Encoding.Default)
            KeyWord = KWTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
            If KeyWord.Length = 0 Then Throw New Exception("请填写关键词！")
            ScanDelay = ScanDelayNumeric.Value
            OpDelay = OpDelayNumeric.Value
            NdPrison = PrisonCheckBox.Checked

            TaskTr = New Thread(AddressOf Monitor)
            TaskTr.Start()
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Function CheckKW(ByVal text As String) As Boolean
        For Each str As String In KeyWord
            If text.IndexOf(str) <> -1 Then Return True
        Next
        Return False
    End Function

    Private Sub Monitor()
        Dim re As New Regex("href=""/p/\d+?"" title="".+?""")
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, Cookie)

        Try : FID = GetFid(wc, KW)
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "Fid获取失败，任务被迫终止！")
            TaskEnd()
            Return
        End Try

        While True
            Try
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + KW)
                Dim rms As MatchCollection = re.Matches(retstr)
                For Each rm As Match In rms
                    Try
                        Dim left As Integer = 9
                        Dim right As Integer = rm.Value.IndexOf("""", left)
                        Dim tid As String = rm.Value.Substring(left, right - left)
                        right += 9
                        Dim title As String = rm.Value.Substring(right, rm.Value.Length - 1 - right)
                        If CheckKW(title) Then
                            Console.ForegroundColor = ConsoleColor.Yellow
                            Console.WriteLine(Time() + "发现目标...")
                            'prison
                            Dim tbs As String = ""
                            Dim errno As String = ""
                            If NdPrison Then
                                Dim left2 As Integer = retstr.IndexOf("title=""主题作者", left)
                                left2 = retstr.IndexOf("_blank"">", left2) + 8
                                Dim right2 As Integer = retstr.IndexOf("</a>", left2)
                                Dim toban As String = retstr.Substring(left2, right2 - left2)

                                tbs = GetTbs(wc)
                                Dim poststr2 As String = "cm=filter_forum_user&user_name=" + URLEncoding(toban, Encoding.UTF8) + "&ban_days=1&word=" + KW + "&fid=" + FID + "&tbs=" + tbs + "&ie=utf-8"
                                wc.SetDefaultHeader()
                                Dim retstr2 As String = wc.UploadString("http://tieba.baidu.com/bawu/cm", poststr2)
                                errno = GetMid(retstr2, "errno"":", ",")
                                If errno = "0" Then
                                    Console.ForegroundColor = ConsoleColor.Green
                                    Console.WriteLine(Time() + toban + " 封禁成功！")
                                Else
                                    Console.ForegroundColor = ConsoleColor.Red
                                    Console.WriteLine(Time() + toban + " 封禁失败！错误信息：" + errno)
                                End If
                            End If
                            'Delete
                            tbs = GetTbs(wc)
                            Dim poststr As String = "ie=gbk&tbs=" + tbs + "&kw=" + KW + "&fid=" + FID + "&tid=" + tid
                            wc.SetDefaultHeader()
                            retstr = wc.UploadString("http://tieba.baidu.com/f/commit/thread/delete", poststr)
                            errno = GetMid(retstr, """:", ",")
                            If errno = "0" Then
                                Console.ForegroundColor = ConsoleColor.Green
                                Console.WriteLine(Time() + tid + " 删除成功！")
                            Else
                                Console.ForegroundColor = ConsoleColor.Red
                                Console.WriteLine(Time() + tid + " 删除失败！错误信息：" + errno)
                            End If
                            Thread.Sleep(OpDelay)
                        End If
                    Catch ex As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + ex.Message)
                    End Try
                Next
                Thread.Sleep(ScanDelay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        End While
    End Sub

    'Private Sub Destruct()

    '    Dim wc As New WizardHTTP
    '    wc.Headers.Set(HttpRequestHeader.Cookie, Cookie)
    '    For i As Integer = StartPage To EndPage
    '        Try
    '            If NdStop Then Exit For
    '            Dim tid As New List(Of String)

    '            wc.SetDefaultHeader()
    '            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + KW + "&pn=" + (50 * (i - 1)).ToString())
    '            Dim left As Integer = retstr.IndexOf("frs_content clearfix"),
    '                right As Integer = 0,
    '                cutdown As Integer = retstr.IndexOf("pager clearfix")
    '            If left = -1 Or cutdown = -1 Then Throw New Exception("第" + i.ToString() + "页获取失败！")
    '            retstr = retstr.Substring(left, cutdown - left)
    '            left = 0
    '            While True
    '                left = retstr.IndexOf("<a href=""/p/", left) + 12
    '                If left = 11 Then Exit While
    '                right = retstr.IndexOf("""", left)
    '                Dim tmp As String = retstr.Substring(left, right - left)
    '                tid.Add(tmp)
    '                left = right
    '            End While

    '            Console.ForegroundColor = ConsoleColor.Yellow
    '            Console.WriteLine(Time() + "第" + i.ToString() + "页获取完成！")

    '            For Each x As String In tid
    '                Try
    '                    If NdStop Then Exit For
    '                    Dim tbs As String = GetTbs(wc)
    '                    Dim poststr As String = "ie=gbk&tbs=" + tbs + "&kw=" + KW + "&fid=" + FID + "&tid=" + x
    '                    wc.SetDefaultHeader()
    '                    retstr = wc.UploadString("http://tieba.baidu.com/f/commit/thread/delete", poststr)
    '                    Dim errno As String = GetMid(retstr, """:", ",")
    '                    If errno = "0" Then
    '                        Console.ForegroundColor = ConsoleColor.Green
    '                        Console.WriteLine(Time() + x + " 删除成功！")
    '                    Else
    '                        Console.ForegroundColor = ConsoleColor.Red
    '                        Console.WriteLine(Time() + x + " 删除失败！错误信息：" + errno)
    '                    End If
    '                    Thread.Sleep(Delay)
    '                Catch ex As Exception
    '                    Console.ForegroundColor = ConsoleColor.Red
    '                    Console.WriteLine(Time() + ex.Message)
    '                End Try
    '            Next
    '        Catch ex As Exception
    '            Console.ForegroundColor = ConsoleColor.Red
    '            Console.WriteLine(Time() + ex.Message)
    '        End Try
    '    Next

    '    Console.ForegroundColor = ConsoleColor.Yellow
    '    Console.WriteLine(Time() + "已结束。")
    '    StartButton.Enabled = True
    '    StopButton.Enabled = False
    'End Sub

    'Private Sub ModeComboBox_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModeComboBox.SelectionChangeCommitted
    '    If ModeComboBox.SelectedIndex = 0 Then '监控
    '        StartPageNumeric.Enabled = False
    '        EndPageNumeric.Enabled = False
    '        KWTextBox.Enabled = True
    '        PrisonCheckBox.Enabled = True
    '    Else '拆吧
    '        StartPageNumeric.Enabled = True
    '        EndPageNumeric.Enabled = True
    '        KWTextBox.Enabled = False
    '        PrisonCheckBox.Enabled = False
    '    End If
    'End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        TaskTr.Abort()
        TaskEnd()
    End Sub

    Private Sub TaskEnd()
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已结束。")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub
End Class
