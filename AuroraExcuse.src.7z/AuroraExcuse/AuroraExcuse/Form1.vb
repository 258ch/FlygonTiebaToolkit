﻿Imports System.Text
Imports System.Threading
Imports AuroraExcuse.Utility

Public Class Form1

    Private UN As String

    Private Sub SeeButton_Click(sender As System.Object, e As System.EventArgs) Handles SeeButton.Click
        Try
            SeeButton.Enabled = False
            UN = UNTextBox.Text
            If UN = "" Then Throw New Exception("请填写目标ID")
            Dim tr As New Thread(AddressOf DoWork)
            tr.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            SeeButton.Enabled = True
        End Try
    End Sub

    Private Sub DoWork()

        ResTextBox.Clear()

        Dim retstr As String = ""
        Dim left As Integer = 0
        Dim right As Integer = 0
        Dim wc As New WizardHTTP
        Try
            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + _
                                                      URLEncoding(UN, Encoding.Default))
            left = retstr.IndexOf("creator"":{""id") + 15
            right = retstr.IndexOf(",", left)
            Dim uid As String = retstr.Substring(left, right - left)

            wc.SetDefaultHeader(True)
            Dim poststr As String = "pn=1&rn=200&uid=" + uid
            Dim sign As String = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
            poststr += "&sign=" + sign
            retstr = wc.UploadString("http://c.tieba.baidu.com/c/u/user/profile", poststr)

            If retstr.IndexOf("post_list"":[]") <> -1 Then
                Throw New Exception("无法查看隐藏动态ID的IP！")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            SeeButton.Enabled = True
            Return
        End Try

        left = 0
        right = 0
        While True
            Try
                left = retstr.IndexOf("create_time"":""", right)
                If left = -1 Then Exit While
                left += 14
                right = retstr.IndexOf("""", left)
                If right = -1 Then Exit While
                Dim ctime As String = retstr.Substring(left, right - left)
                ctime = UnixTimeToLocal(ctime)

                left = retstr.IndexOf("ip"":", right)
                If left = -1 Then Exit While
                left += 4
                right = retstr.IndexOf(",", left)
                If right = -1 Then Exit While
                Dim ip As String = retstr.Substring(left, right - left)
                If ip(0) = "-" Then Continue While
                ip = ComputeIP(ip)
                Dim loc As String = GetLocation(wc, ip)

                ResTextBox.AppendText(ctime + vbCrLf + ip + " " + loc + vbCrLf + vbCrLf)
            Catch ex As Exception : End Try
        End While

        SeeButton.Enabled = True
    End Sub

    Private Function ComputeIP(ByVal ori As String) As String
        Dim num As UInteger = Convert.ToUInt32(ori)
        Dim a As UInteger = num Mod 256
        num /= 256
        Dim b As UInteger = num Mod 256
        num /= 256
        Dim c As UInteger = num Mod 256
        Dim d As UInteger = num / 256
        Return a.ToString() + "." + b.ToString() + "." + c.ToString() + "." + d.ToString()
    End Function

    Private Function GetLocation(ByVal wc As WizardHTTP, ByVal ip As String)
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://opendata.baidu.com/api.php?query=" + ip + "&resource_id=6006")
        Dim left As Integer = retstr.IndexOf("location"":""") + 11
        Dim right As Integer = retstr.IndexOf("""", left)
        Return retstr.Substring(left, right - left)
    End Function

    Private Function UnixTimeToLocal(ByVal time As String)
        Dim span As New TimeSpan(Convert.ToInt64(time + "0000000"))
        Dim t As New Date(1970, 1, 1)
        t += span
        Return t.ToString()
    End Function

    Private Sub ToolStripStatusLabel1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel1.Click
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub ToolStripStatusLabel2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel2.Click
        Process.Start("http://www.258ch.com")
    End Sub
End Class
