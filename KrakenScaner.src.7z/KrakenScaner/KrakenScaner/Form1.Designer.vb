﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.WayComboBox = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PrisonCheckBox = New System.Windows.Forms.CheckBox()
        Me.Lv3CheckBox = New System.Windows.Forms.CheckBox()
        Me.WeakPWTextBox = New System.Windows.Forms.TextBox()
        Me.WeakPWCheckBox = New System.Windows.Forms.CheckBox()
        Me.PinYinCheckBox = New System.Windows.Forms.CheckBox()
        Me.BirthCheckBox = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.LinkLabel4 = New System.Windows.Forms.LinkLabel()
        Me.SucTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TBTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.StartNumeric = New System.Windows.Forms.NumericUpDown()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.ModeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.WayComboBox)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.PrisonCheckBox)
        Me.GroupBox1.Controls.Add(Me.Lv3CheckBox)
        Me.GroupBox1.Controls.Add(Me.WeakPWTextBox)
        Me.GroupBox1.Controls.Add(Me.WeakPWCheckBox)
        Me.GroupBox1.Controls.Add(Me.PinYinCheckBox)
        Me.GroupBox1.Controls.Add(Me.BirthCheckBox)
        Me.GroupBox1.Location = New System.Drawing.Point(187, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(170, 314)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'WayComboBox
        '
        Me.WayComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.WayComboBox.Enabled = False
        Me.WayComboBox.FormattingEnabled = True
        Me.WayComboBox.Items.AddRange(New Object() {"tingapi"})
        Me.WayComboBox.Location = New System.Drawing.Point(53, 288)
        Me.WayComboBox.Name = "WayComboBox"
        Me.WayComboBox.Size = New System.Drawing.Size(100, 20)
        Me.WayComboBox.TabIndex = 15
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(7, 291)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(29, 12)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "方式"
        '
        'PrisonCheckBox
        '
        Me.PrisonCheckBox.AutoSize = True
        Me.PrisonCheckBox.Checked = True
        Me.PrisonCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.PrisonCheckBox.Location = New System.Drawing.Point(86, 264)
        Me.PrisonCheckBox.Name = "PrisonCheckBox"
        Me.PrisonCheckBox.Size = New System.Drawing.Size(72, 16)
        Me.PrisonCheckBox.TabIndex = 13
        Me.PrisonCheckBox.Text = "检查封禁"
        Me.PrisonCheckBox.UseVisualStyleBackColor = True
        '
        'Lv3CheckBox
        '
        Me.Lv3CheckBox.AutoSize = True
        Me.Lv3CheckBox.Location = New System.Drawing.Point(9, 264)
        Me.Lv3CheckBox.Name = "Lv3CheckBox"
        Me.Lv3CheckBox.Size = New System.Drawing.Size(66, 16)
        Me.Lv3CheckBox.TabIndex = 12
        Me.Lv3CheckBox.Text = "3级以上"
        Me.Lv3CheckBox.UseVisualStyleBackColor = True
        '
        'WeakPWTextBox
        '
        Me.WeakPWTextBox.Location = New System.Drawing.Point(6, 70)
        Me.WeakPWTextBox.Multiline = True
        Me.WeakPWTextBox.Name = "WeakPWTextBox"
        Me.WeakPWTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.WeakPWTextBox.Size = New System.Drawing.Size(158, 188)
        Me.WeakPWTextBox.TabIndex = 11
        Me.WeakPWTextBox.Text = "a123456" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "123456a"
        '
        'WeakPWCheckBox
        '
        Me.WeakPWCheckBox.AutoSize = True
        Me.WeakPWCheckBox.Checked = True
        Me.WeakPWCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.WeakPWCheckBox.Location = New System.Drawing.Point(9, 48)
        Me.WeakPWCheckBox.Name = "WeakPWCheckBox"
        Me.WeakPWCheckBox.Size = New System.Drawing.Size(144, 16)
        Me.WeakPWCheckBox.TabIndex = 2
        Me.WeakPWCheckBox.Text = "弱密码（一行一个）："
        Me.WeakPWCheckBox.UseVisualStyleBackColor = True
        '
        'PinYinCheckBox
        '
        Me.PinYinCheckBox.AutoSize = True
        Me.PinYinCheckBox.Checked = True
        Me.PinYinCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.PinYinCheckBox.Location = New System.Drawing.Point(86, 22)
        Me.PinYinCheckBox.Name = "PinYinCheckBox"
        Me.PinYinCheckBox.Size = New System.Drawing.Size(48, 16)
        Me.PinYinCheckBox.TabIndex = 1
        Me.PinYinCheckBox.Text = "拼音"
        Me.PinYinCheckBox.UseVisualStyleBackColor = True
        '
        'BirthCheckBox
        '
        Me.BirthCheckBox.AutoSize = True
        Me.BirthCheckBox.Checked = True
        Me.BirthCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.BirthCheckBox.Location = New System.Drawing.Point(9, 22)
        Me.BirthCheckBox.Name = "BirthCheckBox"
        Me.BirthCheckBox.Size = New System.Drawing.Size(48, 16)
        Me.BirthCheckBox.TabIndex = 0
        Me.BirthCheckBox.Text = "生日"
        Me.BirthCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.LinkLabel4)
        Me.GroupBox2.Controls.Add(Me.SucTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(363, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(172, 253)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "成功区"
        '
        'LinkLabel4
        '
        Me.LinkLabel4.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel4.AutoSize = True
        Me.LinkLabel4.Location = New System.Drawing.Point(137, 1)
        Me.LinkLabel4.Name = "LinkLabel4"
        Me.LinkLabel4.Size = New System.Drawing.Size(29, 12)
        Me.LinkLabel4.TabIndex = 9
        Me.LinkLabel4.TabStop = True
        Me.LinkLabel4.Text = "复制"
        '
        'SucTextBox
        '
        Me.SucTextBox.Location = New System.Drawing.Point(6, 20)
        Me.SucTextBox.MaxLength = 0
        Me.SucTextBox.Multiline = True
        Me.SucTextBox.Name = "SucTextBox"
        Me.SucTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SucTextBox.Size = New System.Drawing.Size(160, 227)
        Me.SucTextBox.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "贴吧"
        '
        'TBTextBox
        '
        Me.TBTextBox.Location = New System.Drawing.Point(63, 46)
        Me.TBTextBox.Name = "TBTextBox"
        Me.TBTextBox.Size = New System.Drawing.Size(100, 21)
        Me.TBTextBox.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "起始页数"
        '
        'StartNumeric
        '
        Me.StartNumeric.Location = New System.Drawing.Point(63, 74)
        Me.StartNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.StartNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.StartNumeric.Name = "StartNumeric"
        Me.StartNumeric.Size = New System.Drawing.Size(100, 21)
        Me.StartNumeric.TabIndex = 4
        Me.StartNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(63, 101)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(100, 21)
        Me.TrNumeric.TabIndex = 5
        Me.TrNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "线程数"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.IDTextBox)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.DelayNumeric)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.ModeComboBox)
        Me.GroupBox3.Controls.Add(Me.TBTextBox)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.TrNumeric)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.StartNumeric)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(169, 314)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "方式"
        '
        'IDTextBox
        '
        Me.IDTextBox.Enabled = False
        Me.IDTextBox.Location = New System.Drawing.Point(8, 176)
        Me.IDTextBox.Multiline = True
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.IDTextBox.Size = New System.Drawing.Size(155, 132)
        Me.IDTextBox.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 156)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(125, 12)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "目标ID（一行一个）："
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 132)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "间隔(ms)"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(63, 130)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(100, 21)
        Me.DelayNumeric.TabIndex = 7
        '
        'ModeComboBox
        '
        Me.ModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ModeComboBox.FormattingEnabled = True
        Me.ModeComboBox.Items.AddRange(New Object() {"自动获取", "手动输入"})
        Me.ModeComboBox.Location = New System.Drawing.Point(63, 20)
        Me.ModeComboBox.Name = "ModeComboBox"
        Me.ModeComboBox.Size = New System.Drawing.Size(100, 20)
        Me.ModeComboBox.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "模式"
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(450, 295)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(85, 31)
        Me.StopButton.TabIndex = 4
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(363, 295)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(85, 31)
        Me.StartButton.TabIndex = 5
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(367, 276)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 6
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "风凝圣域"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(425, 276)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 7
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "联系作者"
        '
        'LinkLabel3
        '
        Me.LinkLabel3.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.Location = New System.Drawing.Point(482, 276)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel3.TabIndex = 8
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "获取更新"
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.NotifyIcon1.BalloonTipText = "欢迎使用·海妖"
        Me.NotifyIcon1.BalloonTipTitle = "信息提示："
        Me.NotifyIcon1.Text = "欢迎使用·海妖"
        Me.NotifyIcon1.Visible = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(547, 338)
        Me.Controls.Add(Me.LinkLabel3)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "海妖·风凝军团扫号机 KrakenScaner - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents StartNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TBTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ModeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents WeakPWCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents PinYinCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents BirthCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents WeakPWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PrisonCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Lv3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents WayComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents SucTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents LinkLabel4 As System.Windows.Forms.LinkLabel

End Class
