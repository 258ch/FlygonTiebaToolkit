﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LoginButton = New System.Windows.Forms.Button()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BSTextBox = New System.Windows.Forms.TextBox()
        Me.BSPictureBox = New System.Windows.Forms.PictureBox()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.HideButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.AppButton = New System.Windows.Forms.Button()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ExitButton)
        Me.GroupBox1.Controls.Add(Me.LinkLabel2)
        Me.GroupBox1.Controls.Add(Me.LinkLabel1)
        Me.GroupBox1.Controls.Add(Me.LoginButton)
        Me.GroupBox1.Controls.Add(Me.PWTextBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.IDTextBox)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(164, 127)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "登录"
        '
        'ExitButton
        '
        Me.ExitButton.Enabled = False
        Me.ExitButton.Location = New System.Drawing.Point(85, 84)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(71, 23)
        Me.ExitButton.TabIndex = 8
        Me.ExitButton.Text = "退出"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(46, 0)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 7
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "联系作者"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(105, 0)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 2
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "获取更新"
        '
        'LoginButton
        '
        Me.LoginButton.Location = New System.Drawing.Point(11, 84)
        Me.LoginButton.Name = "LoginButton"
        Me.LoginButton.Size = New System.Drawing.Size(71, 23)
        Me.LoginButton.TabIndex = 6
        Me.LoginButton.Text = "登录"
        Me.LoginButton.UseVisualStyleBackColor = True
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(56, 56)
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.PWTextBox.Size = New System.Drawing.Size(100, 21)
        Me.PWTextBox.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "密码"
        '
        'IDTextBox
        '
        Me.IDTextBox.Location = New System.Drawing.Point(56, 29)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(100, 21)
        Me.IDTextBox.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "用户名"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BSTextBox)
        Me.GroupBox2.Controls.Add(Me.BSPictureBox)
        Me.GroupBox2.Location = New System.Drawing.Point(182, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(168, 127)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "登录验证码"
        '
        'BSTextBox
        '
        Me.BSTextBox.Enabled = False
        Me.BSTextBox.Location = New System.Drawing.Point(25, 84)
        Me.BSTextBox.Name = "BSTextBox"
        Me.BSTextBox.Size = New System.Drawing.Size(118, 21)
        Me.BSTextBox.TabIndex = 1
        '
        'BSPictureBox
        '
        Me.BSPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox.Location = New System.Drawing.Point(25, 29)
        Me.BSPictureBox.Name = "BSPictureBox"
        Me.BSPictureBox.Size = New System.Drawing.Size(118, 50)
        Me.BSPictureBox.TabIndex = 0
        Me.BSPictureBox.TabStop = False
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.NotifyIcon1.BalloonTipText = "欢迎使用·天使之翼"
        Me.NotifyIcon1.BalloonTipTitle = "信息提示："
        Me.NotifyIcon1.Text = "天使之翼"
        Me.NotifyIcon1.Visible = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.HideButton)
        Me.GroupBox3.Controls.Add(Me.StopButton)
        Me.GroupBox3.Controls.Add(Me.StartButton)
        Me.GroupBox3.Controls.Add(Me.AppButton)
        Me.GroupBox3.Controls.Add(Me.DelayNumeric)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 145)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(338, 95)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "设置"
        '
        'HideButton
        '
        Me.HideButton.Location = New System.Drawing.Point(232, 51)
        Me.HideButton.Name = "HideButton"
        Me.HideButton.Size = New System.Drawing.Size(100, 23)
        Me.HideButton.TabIndex = 14
        Me.HideButton.Text = "隐藏窗口"
        Me.HideButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(112, 51)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(100, 23)
        Me.StopButton.TabIndex = 13
        Me.StopButton.Text = "停止监控"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(6, 51)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(100, 23)
        Me.StartButton.TabIndex = 12
        Me.StartButton.Text = "开始监控"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'AppButton
        '
        Me.AppButton.Location = New System.Drawing.Point(232, 24)
        Me.AppButton.Name = "AppButton"
        Me.AppButton.Size = New System.Drawing.Size(100, 23)
        Me.AppButton.TabIndex = 11
        Me.AppButton.Text = "应用"
        Me.AppButton.UseVisualStyleBackColor = True
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(112, 24)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(100, 21)
        Me.DelayNumeric.TabIndex = 10
        Me.DelayNumeric.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 12)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "间隔(s)"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(362, 252)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "天使之翼·T豆助手 - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents LoginButton As System.Windows.Forms.Button
    Friend WithEvents PWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents BSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BSPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents AppButton As System.Windows.Forms.Button
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents HideButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button

End Class
