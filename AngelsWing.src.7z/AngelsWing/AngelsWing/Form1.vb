﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports AngelsWing.Utility
Imports AngelsWing.Profile
Imports AngelsWing.TBOps
Imports Sunisoft.IrisSkin

Public Class Form1

    Private UN As String
    Private PW As String
    Private Cookie As String
    Private BS As String
    Private WorkTr As Thread
    Private TaskRunning As Boolean = False
    Public Delay As Integer

    Private Skin As SkinEngine

    Private Sub LoadUsr()
        Dim buff(255) As Byte
        GetPrivateProfileString("settings", "cookie", "", buff, buff.Length, ".\settings.ini")
        Cookie = Encoding.Default.GetString(buff).Replace(ChrW(0), "")
        If Cookie <> "" Then
            ReDim buff(255)
            GetPrivateProfileString("settings", "username", "", buff, buff.Length, ".\settings.ini")
            UN = Encoding.Default.GetString(buff).Replace(ChrW(0), "")
            IDTextBox.Text = UN

            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "用户信息读取完毕...")
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            LoginButton.Enabled = False
            ExitButton.Enabled = True
        End If
    End Sub


    Private Sub LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginButton.Click
        Try
            LoginButton.Enabled = False
            UN = IDTextBox.Text
            PW = PWTextBox.Text
            If UN = "" Or PW = "" Then
                Throw New Exception("请填写用户名和密码！")
            End If
            Dim tr As New Thread(AddressOf Login)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub Login()
        Try
            Dim wc As New WizardHTTP
            Dim retstr As String
            Dim left, right As Integer
            
            Dim poststr As String = "_client_id=" + GetStampMobile(True) + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(PW)) + "&un=" + URLEncoding(UN, Encoding.UTF8)
            wc.SetDefaultHeader(True)
            retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            left = retstr.IndexOf("error_code"":5")

            If left <> -1 Then '验证码
                left = retstr.IndexOf("vcode_md5") + 12
                right = retstr.IndexOf("""", left)
                Dim vcode As String = retstr.Substring(left, right - left)
                wc.SetDefaultHeader()
                Dim pic As Image = Image.FromStream(New MemoryStream(wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)))
                BS = ""
                BSPictureBox.Image = pic
                BSTextBox.Enabled = True
                While BS = "" : Thread.Sleep(200) : End While
                BSTextBox.Enabled = False
                poststr = "_client_id=" + GetStampMobile(True) + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(PW)) + "&un=" + URLEncoding(UN, Encoding.UTF8) + "&vcode=" + BS + "&vcode_md5=" + vcode
                wc.SetDefaultHeader(True)
                retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            End If

            Dim re As New Regex("BDUSS"":"".{192}")
            Dim rm As Match = re.Match(retstr)
            If Not rm.Success Then
                left = retstr.IndexOf("error_msg") + 12
                right = retstr.IndexOf("""", left)
                Dim errmsg As String = retstr.Substring(left, right - left)
                Throw New Exception(UN + " 登录失败！" + UnicodeDeco(errmsg))
            End If
            Cookie = "BDUSS=" + rm.Value.Substring(8.192)

            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + UN + " 登陆成功！")
            ExitButton.Enabled = True
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 Then
            BS = BSTextBox.Text
            BSPictureBox.Image = Nothing
            BSTextBox.Text = ""
        End If
    End Sub

    Private Sub DoWork()
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, Cookie)
        While True
            Try
                GetTBean(wc)
                Thread.Sleep(Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        End While
    End Sub

    Private Sub GetTBean(ByVal wc As WizardHTTP)
        Dim tbs As String = GetTbs(wc)
        wc.SetDefaultHeader()
        Dim retstr As String = wc.UploadString("http://tieba.baidu.com/tbscore/timebeat", _
                                               "tbs=" + tbs + "&fr=pb")
        Dim left As Integer = retstr.IndexOf("no"":") + 4
        Dim right As Integer = retstr.IndexOf(",", left)
        Dim errno As String = retstr.Substring(left, right - left)
        If errno <> "0" Then
            left = retstr.IndexOf("error") + 8
            right = retstr.IndexOf("""", left)
            Dim errmsg As String = retstr.Substring(left, right - left)
            Throw New Exception("信息获取失败！" + UnicodeDeco(errmsg))
        End If

        left = retstr.IndexOf("show_gift")
        If left = -1 Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "没有检测到彩蛋！")
        Else
            left = retstr.IndexOf("gift_type") + 11
            right = retstr.IndexOf(",", left)
            Dim type As String = retstr.Substring(left, right - left)
            If type = "1" Then : type = "time"
            Else : type = "rand" : End If
            left = retstr.IndexOf("gift_score") + 12
            right = retstr.IndexOf("}", left)
            Dim score As String = retstr.Substring(left, right - left)
            left = retstr.IndexOf("gift_key") + 11
            right = retstr.IndexOf("""", left)
            Dim key As String = retstr.Substring(left, right - left)
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "检测到彩蛋，T豆数：" + score + "。")

            tbs = GetTbs(wc)
            wc.SetDefaultHeader()
            Dim poststr As String = "type=" + type + "&tbs=" + tbs + "&gift_key=" + key
            retstr = wc.UploadString("http://tieba.baidu.com/tbscore/opengift", poststr)

            left = retstr.IndexOf("no"":") + 4
            right = retstr.IndexOf(",", left)
            errno = retstr.Substring(left, right - left)
            If errno = "0" Then
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + "彩蛋获取成功！")
            Else
                left = retstr.IndexOf("error") + 8
                right = retstr.IndexOf("""", left)
                Dim errmsg As String = retstr.Substring(left, right - left)
                Throw New Exception("彩蛋获取失败！" + UnicodeDeco(errmsg))
            End If
        End If

        wc.SetDefaultHeader()
        retstr = wc.DownloadString("http://tieba.baidu.com/tbmall/getTdou")
        left = retstr.IndexOf("coin_count"">") + 12
        right = retstr.IndexOf("</", left)
        Dim cnt As String = retstr.Substring(left, right - left)
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "当前T豆数：" + cnt + "。")
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        NotifyIcon1.Icon = Me.Icon
        Delay = DelayNumeric.Value * 1000
        Skin = New SkinEngine(Me, New MemoryStream(My.Resources.Emerald))
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If Cookie <> "" Then
            WritePrivateProfileString("settings", "cookie", Cookie, ".\settings.ini")
            WritePrivateProfileString("settings", "username", UN, ".\settings.ini")
        End If

        End
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub ExitButton_Click(sender As System.Object, e As System.EventArgs) Handles ExitButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请先停止当前任务！")
            Return
        End If

        Cookie = ""
        IDTextBox.Enabled = True
        PWTextBox.Enabled = True
        LoginButton.Enabled = True
        ExitButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已退出。")
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LoadUsr()
    End Sub

    Private Sub MinButton_Click(sender As System.Object, e As System.EventArgs) Handles HideButton.Click
        Me.Visible = False
        NotifyIcon1.ShowBalloonTip(1000, "我在这里...", "双击我可以还原窗口。", NotifyIcon1.BalloonTipIcon)
    End Sub

    Private Sub NotifyIcon1_MouseDoubleClick(sender As System.Object, e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick
        Me.Visible = True
    End Sub

    Private Sub AppButton_Click(sender As System.Object, e As System.EventArgs) Handles AppButton.Click
        Delay = DelayNumeric.Value * 1000
    End Sub

    Private Sub StartButton_Click(sender As System.Object, e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If Cookie = "" Then Throw New Exception("请先登录！")
            WorkTr = New Thread(AddressOf DoWork)
            WorkTr.Start()
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "开始监控...")
            TaskRunning = True
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub WorkEnd()
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已停止...")
        TaskRunning = False
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub StopButton_Click(sender As System.Object, e As System.EventArgs) Handles StopButton.Click
        WorkTr.Abort()
        WorkEnd()
    End Sub
End Class
