﻿Imports System.Net

Public Class Program

    Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

    Public Shared Sub main()
        Try
            ServicePointManager.MaxServicePoints = 512
            ServicePointManager.Expect100Continue = False
            Control.CheckForIllegalCrossThreadCalls = False

            AllocConsole()
            Console.Title = "信息输出 for Angel's Wing"
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("欢迎使用 天使の翼·T豆助手" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("本工具禁止作为商业用途，作者保留一切解释权利")
            Console.WriteLine("Copyright <C> 2013 - 20XX 飞龙 - 苍海·国际" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine("感谢苍海·国际、风凝圣域，冰焰技术联盟和正在使用的你～" + vbCrLf)

            Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(Form1)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
