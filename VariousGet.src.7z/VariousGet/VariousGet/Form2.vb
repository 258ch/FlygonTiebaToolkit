﻿Public Class Form2

    Private Sub Form2_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub

    Private Sub CopyButton_Click(sender As System.Object, e As System.EventArgs) Handles CopyButton.Click
        If SucTextBox.Text <> "" Then
            Clipboard.SetText(SucTextBox.Text)
            MessageBox.Show("复制成功！")
        End If
    End Sub

    Private Sub GenButton_Click(sender As System.Object, e As System.EventArgs) Handles GenButton.Click
        GenButton.Enabled = False

        Dim max As Integer = IDNumeric.Value

        Dim lists As String() = Form1.OutTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
        If lists.Length = 0 Then
            MessageBox.Show("成功区无内容！")
            GenButton.Enabled = True
            Return
        End If

        Dim icount As Integer = 0
        Dim tmpstr As String = ""
        For Each str As String In lists
            tmpstr += "@" + str + " "
            icount += 1
            If icount = max Then
                SucTextBox.AppendText(tmpstr + vbCrLf)
                tmpstr = ""
                icount = 0
            End If
        Next
        If tmpstr <> "" Then SucTextBox.AppendText(tmpstr + vbCrLf)

        GenButton.Enabled = True
    End Sub
End Class