﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PosiNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lv3CheckBox = New System.Windows.Forms.CheckBox()
        Me.ListComboBox = New System.Windows.Forms.ComboBox()
        Me.StartNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SubTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ModeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.InfoLabel = New System.Windows.Forms.Label()
        Me.InfoTextBox = New System.Windows.Forms.TextBox()
        Me.OutTextBox = New System.Windows.Forms.TextBox()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.CopyButton = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.AtButton = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PosiNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PosiNumeric)
        Me.GroupBox1.Controls.Add(Me.LinkLabel2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.LinkLabel1)
        Me.GroupBox1.Controls.Add(Me.Lv3CheckBox)
        Me.GroupBox1.Controls.Add(Me.ListComboBox)
        Me.GroupBox1.Controls.Add(Me.StartNumeric)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.SubTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.ModeComboBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.InfoLabel)
        Me.GroupBox1.Controls.Add(Me.InfoTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(351, 128)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'PosiNumeric
        '
        Me.PosiNumeric.Enabled = False
        Me.PosiNumeric.Location = New System.Drawing.Point(234, 77)
        Me.PosiNumeric.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.PosiNumeric.Minimum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.PosiNumeric.Name = "PosiNumeric"
        Me.PosiNumeric.Size = New System.Drawing.Size(100, 21)
        Me.PosiNumeric.TabIndex = 14
        Me.PosiNumeric.Value = New Decimal(New Integer() {10000000, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(175, 81)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 12)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "起始位置"
        '
        'Lv3CheckBox
        '
        Me.Lv3CheckBox.AutoSize = True
        Me.Lv3CheckBox.Location = New System.Drawing.Point(234, 104)
        Me.Lv3CheckBox.Name = "Lv3CheckBox"
        Me.Lv3CheckBox.Size = New System.Drawing.Size(72, 16)
        Me.Lv3CheckBox.TabIndex = 12
        Me.Lv3CheckBox.Text = "三级以上"
        Me.Lv3CheckBox.UseVisualStyleBackColor = True
        '
        'ListComboBox
        '
        Me.ListComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ListComboBox.Enabled = False
        Me.ListComboBox.FormattingEnabled = True
        Me.ListComboBox.Items.AddRange(New Object() {"顺序", "8位随机", "9位随机"})
        Me.ListComboBox.Location = New System.Drawing.Point(69, 78)
        Me.ListComboBox.Name = "ListComboBox"
        Me.ListComboBox.Size = New System.Drawing.Size(100, 20)
        Me.ListComboBox.TabIndex = 11
        '
        'StartNumeric
        '
        Me.StartNumeric.Location = New System.Drawing.Point(69, 50)
        Me.StartNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.StartNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.StartNumeric.Name = "StartNumeric"
        Me.StartNumeric.Size = New System.Drawing.Size(100, 21)
        Me.StartNumeric.TabIndex = 10
        Me.StartNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(18, 81)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 12)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "顺序"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(175, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "小分类"
        '
        'SubTextBox
        '
        Me.SubTextBox.Enabled = False
        Me.SubTextBox.Location = New System.Drawing.Point(233, 50)
        Me.SubTextBox.Name = "SubTextBox"
        Me.SubTextBox.Size = New System.Drawing.Size(100, 21)
        Me.SubTextBox.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "起始页"
        '
        'ModeComboBox
        '
        Me.ModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ModeComboBox.FormattingEnabled = True
        Me.ModeComboBox.Items.AddRange(New Object() {"会员", "关注", "粉丝", "吧务", "数列", "帖子"})
        Me.ModeComboBox.Location = New System.Drawing.Point(69, 24)
        Me.ModeComboBox.Name = "ModeComboBox"
        Me.ModeComboBox.Size = New System.Drawing.Size(100, 20)
        Me.ModeComboBox.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "模式"
        '
        'InfoLabel
        '
        Me.InfoLabel.AutoSize = True
        Me.InfoLabel.Location = New System.Drawing.Point(175, 27)
        Me.InfoLabel.Name = "InfoLabel"
        Me.InfoLabel.Size = New System.Drawing.Size(29, 12)
        Me.InfoLabel.TabIndex = 0
        Me.InfoLabel.Text = "贴吧"
        '
        'InfoTextBox
        '
        Me.InfoTextBox.Location = New System.Drawing.Point(233, 24)
        Me.InfoTextBox.Name = "InfoTextBox"
        Me.InfoTextBox.Size = New System.Drawing.Size(100, 21)
        Me.InfoTextBox.TabIndex = 1
        '
        'OutTextBox
        '
        Me.OutTextBox.Location = New System.Drawing.Point(12, 146)
        Me.OutTextBox.Multiline = True
        Me.OutTextBox.Name = "OutTextBox"
        Me.OutTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.OutTextBox.Size = New System.Drawing.Size(351, 147)
        Me.OutTextBox.TabIndex = 2
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(288, 299)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(75, 23)
        Me.StopButton.TabIndex = 3
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(196, 299)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(75, 23)
        Me.StartButton.TabIndex = 4
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'CopyButton
        '
        Me.CopyButton.Location = New System.Drawing.Point(104, 299)
        Me.CopyButton.Name = "CopyButton"
        Me.CopyButton.Size = New System.Drawing.Size(75, 23)
        Me.CopyButton.TabIndex = 5
        Me.CopyButton.Text = "复制"
        Me.CopyButton.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(233, 0)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 6
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "联系作者"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(292, 0)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 7
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "获取更新"
        '
        'AtButton
        '
        Me.AtButton.Location = New System.Drawing.Point(12, 299)
        Me.AtButton.Name = "AtButton"
        Me.AtButton.Size = New System.Drawing.Size(75, 23)
        Me.AtButton.TabIndex = 8
        Me.AtButton.Text = "召唤辅助"
        Me.AtButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(375, 334)
        Me.Controls.Add(Me.AtButton)
        Me.Controls.Add(Me.CopyButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.OutTextBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "各种取～VariousGet～ - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PosiNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents OutTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents CopyButton As System.Windows.Forms.Button
    Friend WithEvents ModeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents InfoLabel As System.Windows.Forms.Label
    Friend WithEvents InfoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SubTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents StartNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ListComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Lv3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PosiNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents AtButton As System.Windows.Forms.Button

End Class
