﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports VariousGet.Utility
Imports Sunisoft.IrisSkin

Public Class Form1

    Private Skin As SkinEngine
    Private TB As String
    Private ID As String
    Private StartPage As Integer
    Private EndPage As Integer
    Private List As Integer
    Private NdLv3 As Boolean
    Private StartPosi As Integer
    Private Fdir As String
    Private Sdir As String
    Private Tr As Thread

    Private Const MEMBER As Integer = 0
    Private Const CONCERN As Integer = 1
    Private Const FANS As Integer = 2
    Private Const BAWU As Integer = 3
    Private Const ARRAY As Integer = 4
    Private Const TID As Integer = 5

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        ModeComboBox.SelectedIndex = 0
        ListComboBox.SelectedIndex = 0
        Skin = New SkinEngine(Me, New MemoryStream(My.Resources.DeepCyan))
    End Sub

    Private Sub CopyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyButton.Click
        If OutTextBox.Text <> "" Then
            Clipboard.SetText(OutTextBox.Text)
            MessageBox.Show("复制成功！")
        End If
    End Sub

    Private Sub ModeComboBox_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModeComboBox.SelectionChangeCommitted
        Select Case ModeComboBox.SelectedIndex

            Case MEMBER '会员
                InfoLabel.Text = "贴吧"
                InfoTextBox.Enabled = True
                StartNumeric.Enabled = True
                SubTextBox.Enabled = False
                ListComboBox.Enabled = False
                PosiNumeric.Enabled = False
                Lv3CheckBox.Enabled = True
                Exit Select
            Case CONCERN  '关注
                InfoLabel.Text = "ID"
                InfoTextBox.Enabled = True
                StartNumeric.Enabled = True
                SubTextBox.Enabled = False
                ListComboBox.Enabled = False
                PosiNumeric.Enabled = False
                Lv3CheckBox.Enabled = False
                Exit Select
            Case FANS  '粉丝
                InfoLabel.Text = "ID"
                InfoTextBox.Enabled = True
                StartNumeric.Enabled = True
                SubTextBox.Enabled = False
                ListComboBox.Enabled = False
                PosiNumeric.Enabled = False
                Lv3CheckBox.Enabled = False
                Exit Select
            Case BAWU  '吧务
                InfoLabel.Text = "大分类"
                InfoTextBox.Enabled = True
                StartNumeric.Enabled = True
                SubTextBox.Enabled = True
                ListComboBox.Enabled = False
                PosiNumeric.Enabled = False
                Lv3CheckBox.Enabled = False
                Exit Select
            Case ARRAY  '数列
                InfoTextBox.Enabled = False
                StartNumeric.Enabled = False
                SubTextBox.Enabled = False
                ListComboBox.Enabled = True
                PosiNumeric.Enabled = True
                Lv3CheckBox.Enabled = False
                Exit Select
            Case TID  '帖子
                InfoLabel.Text = "贴吧"
                InfoTextBox.Enabled = True
                StartNumeric.Enabled = True
                SubTextBox.Enabled = False
                ListComboBox.Enabled = False
                PosiNumeric.Enabled = False
                Lv3CheckBox.Enabled = False
                Exit Select
            Case Else
                MessageBox.Show("未知错误！")
                Exit Select
        End Select

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False

            Dim func As ThreadStart
            Select Case ModeComboBox.SelectedIndex
                Case MEMBER  '会员
                    TB = InfoTextBox.Text
                    If TB = "" Then Throw New Exception("请填写贴吧！")
                    StartPage = StartNumeric.Value
                    NdLv3 = Lv3CheckBox.Checked
                    func = AddressOf GetMember
                    Exit Select
                Case CONCERN  '关注
                    ID = InfoTextBox.Text
                    If ID = "" Then Throw New Exception("请填写ID！")
                    StartPage = StartNumeric.Value
                    func = AddressOf GetConcern
                    Exit Select
                Case FANS  '粉丝
                    ID = InfoTextBox.Text
                    If ID = "" Then Throw New Exception("请填写ID！")
                    StartPage = StartNumeric.Value
                    func = AddressOf GetFans
                    Exit Select
                Case BAWU  '吧务
                    Fdir = InfoTextBox.Text
                    Sdir = SubTextBox.Text
                    If Fdir = "" Or Sdir = "" Then Throw New Exception("请填写分类！")
                    StartPage = StartNumeric.Value
                    func = AddressOf GetBawu
                    Exit Select
                Case ARRAY  '数列
                    StartPosi = PosiNumeric.Value
                    List = ListComboBox.SelectedIndex
                    func = AddressOf GetID
                    Exit Select
                Case TID  '帖子
                    TB = InfoTextBox.Text
                    If TB = "" Then Throw New Exception("请填写贴吧！")
                    StartPage = StartNumeric.Value
                    func = AddressOf GetTid
                    Exit Select
                Case Else
                    Throw New Exception("未知错误！")
            End Select

            Tr = New Thread(func)
            Tr.Start()

            StopButton.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub GetMember() '取会员

        Dim wc As New WizardHTTP
        '取总页数
        Dim kw As String = URLEncoding(TB, Encoding.Default)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + kw)
            Dim left As Integer = retstr.IndexOf(""">下一页")
            If left = -1 Then : EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                Dim right As Integer = retstr.IndexOf("""", left)
                EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If StartPage > EndPage Then StartPage = 1
        Catch ex As Exception
            MessageBox.Show("会员信息初始化失败！")
            GoTo Label_Exit
        End Try

        For i As Integer = StartPage To EndPage
            Try
                StartNumeric.Value = i

                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + kw + "&pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("id=""member_list"""),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("id=""j_pagebar""")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)
                left = 0

                While True
                    left = retstr.IndexOf("bg_lv", left)
                    If left = -1 Then Exit While
                    Dim lv As String = retstr.Substring(left + 5, 1)
                    left = retstr.IndexOf("_blank", left) + 8
                    If left = 7 Then Exit While
                    right = retstr.IndexOf("<", left)
                    If right = -1 Then Exit While
                    Dim un As String = retstr.Substring(left, right - left)
                    If Not NdLv3 Or lv = "2" Then
                        OutTextBox.AppendText(un + vbCrLf)
                    End If
                    left = right
                End While
            Catch ex As Exception : End Try
        Next

Label_Exit: StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub GetFans() '取粉丝(fans)
        Dim wc As New WizardHTTP
        '读页数
        Dim itieba As String = ""
        Try
            ID = URLEncoding(ID, Encoding.Default)
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + ID)
            Dim left As Integer = retstr.IndexOf("id") + 4
            Dim right As Integer = retstr.IndexOf(",", left)
            itieba = retstr.Substring(left, right - left)

            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/fans")
            left = retstr.IndexOf(""">下一页")
            If left = -1 Then : EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                right = retstr.IndexOf("""", left)
                EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If StartPage > EndPage Then StartPage = 1
        Catch ex As Exception
            MessageBox.Show("ID信息初始化失败！")
            GoTo Label_Exit
        End Try

        '取ID
        For i As Integer = StartPage To EndPage
            Try
                StartNumeric.Value = i

                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/fans?pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("main_wrapper"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("pagerPanel")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)
                left = 0

                While True
                    left = retstr.IndexOf("_blank"">", left) + 8
                    If left = 7 Then Exit While
                    right = retstr.IndexOf("<", left)
                    Dim tmp As String = retstr.Substring(left, right - left)
                    OutTextBox.AppendText(tmp + vbCrLf)
                    left = right
                End While
            Catch ex As Exception : End Try
        Next

Label_Exit: StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub GetConcern() '取关注(concern)

        Dim wc As New WizardHTTP
        '读页数
        Dim itieba As String = ""
        Try
            ID = URLEncoding(ID, Encoding.Default)

            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + ID)
            Dim left As Integer = retstr.IndexOf("id") + 4
            Dim right As Integer = retstr.IndexOf(",", left)
            itieba = retstr.Substring(left, right - left)

            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/concern")
            left = retstr.IndexOf(""">下一页")
            If left = -1 Then : EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                right = retstr.IndexOf("""", left)
                EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If StartPage > EndPage Then StartPage = 1
        Catch ex As Exception
            MessageBox.Show("ID信息初始化失败！")
            GoTo Label_Exit
        End Try

        '取ID
        For i As Integer = StartPage To EndPage
            Try
                StartNumeric.Value = i

                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/concern?pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("main_wrapper"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("pagerPanel")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)
                left = 0

                While True
                    left = retstr.IndexOf("_blank"">", left) + 8
                    If left = 7 Then Exit While
                    right = retstr.IndexOf("<", left)
                    Dim tmp As String = retstr.Substring(left, right - left)
                    OutTextBox.AppendText(tmp + vbCrLf)
                    left = right
                End While
            Catch ex As Exception : End Try
        Next

Label_Exit: StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub GetBawu() '取吧务 贴吧列表

        Dim wc As New WizardHTTP
        Fdir = URLEncoding(Fdir, Encoding.Default)
        Sdir = URLEncoding(Sdir, Encoding.Default)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/fdir?fd=" + Fdir + "&sd=" + Sdir)
            Dim left As Integer = retstr.IndexOf(""">下一页")
            If left = -1 Then : EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                Dim right As Integer = retstr.IndexOf("""", left)
                EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If StartPage > EndPage Then StartPage = 1
        Catch ex As Exception
            MessageBox.Show("目录信息初始化失败！")
            GoTo Label_Exit
        End Try

        For i As Integer = StartPage To EndPage
            Try
                StartNumeric.Value = i

                wc.SetDefaultHeader()
                wc.Encoding = Encoding.Default
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/fdir?fd=" + Fdir + "&sd=" + Sdir + "&pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("贴吧列表start"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("贴吧列表end")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)
                left = 0
                '取贴吧
                Dim TBList As New List(Of String)
                While True
                    left = retstr.IndexOf("_blank'>", left) + 8
                    If left = 7 Then Exit While
                    right = retstr.IndexOf("<", left)
                    If right = -1 Then Exit While
                    TBList.Add(retstr.Substring(left, right - left))
                End While
                '取吧务
                For Each x As String In TBList
                    Try
                        wc.Encoding = Encoding.UTF8
                        GetBawuID(wc, x)
                    Catch ex As Exception : End Try
                Next
            Catch ex As Exception : End Try
        Next

Label_Exit: StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub GetID() '数列取ID

        Dim wc As New WizardHTTP
        While True
            Try
                PosiNumeric.Value = StartPosi

                wc.SetDefaultHeader()
                ' 防止新版跳转
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/" + StartPosi.ToString() + "/one")
                Dim left As Integer = retstr.IndexOf("<title>") + 7
                If left = 6 Then GoTo label
                Dim right As Integer = retstr.IndexOf("的动态_i贴吧", left)
                If right = -1 Then GoTo label
                Dim un As String = retstr.Substring(left, right - left)
                OutTextBox.AppendText(un + vbCrLf)

label:          If List = 0 Then '顺序
                    StartPosi += 1
                ElseIf List = 1 Then '8位随机
                    Dim ran As New Random()
                    StartPosi = ran.Next(1000, 9999) * 10000 + ran.Next(1000, 9999)
                Else '9位随机
                    Dim ran As New Random()
                    StartPosi = ran.Next(1000, 9999) * 100000 + ran.Next(10000, 99999)
                End If
            Catch ex As Exception : End Try
        End While

    End Sub

    Private Sub GetTid() '取帖子号

        Dim wc As New WizardHTTP
        '取总页数
        Dim kw As String = URLEncoding(TB, Encoding.Default)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + kw)
            Dim left As Integer = retstr.IndexOf(""">下一页")
            If left = -1 Then : EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                Dim right As Integer = retstr.IndexOf("""", left)
                EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If StartPage > EndPage Then StartPage = 1
        Catch ex As Exception
            MessageBox.Show("贴吧信息初始化失败！")
            GoTo Label_Exit
        End Try

        For i As Integer = StartPage To EndPage
            Try
                StartNumeric.Value = i

                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + kw + "&pn=" + (50 * (i - 1)).ToString())
                Dim left As Integer = retstr.IndexOf("class=""threadlist_li_right"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("id=""frs_list_pager")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)
                left = 0
                While True
                    left = retstr.IndexOf("/p/", left) + 3
                    If left = 2 Then Exit While
                    right = retstr.IndexOf("""", left)
                    If right = -1 Then Exit While
                    '防止特殊帖子带后缀
                    Dim tmp As String = retstr.Substring(left, right - left).Substring(0, 10)
                    OutTextBox.AppendText(tmp + vbCrLf)
                    left = right
                End While
            Catch ex As Exception : End Try
        Next

Label_Exit: StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        Tr.Abort()
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub GetBawuID(ByRef wc As WizardHTTP, ByVal tb As String) '取每个贴吧的吧务

        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://wapp.baidu.com/f/m?tn=bdBIW&word=" + tb)
        Dim left As Integer = retstr.IndexOf("吧主"),
            right As Integer = 0,
            cutdown As Integer = retstr.IndexOf("主题")
        If left = -1 Or cutdown = -1 Then Return
        retstr = retstr.Substring(left, cutdown - left)
        left = 0

        While True
            left = retstr.IndexOf(""">", left) + 2
            If left = 1 Then Exit While
            right = retstr.IndexOf("</a>", left)
            If right = -1 Then Exit While
            Dim tmp As String = retstr.Substring(left, right - left)
            OutTextBox.AppendText(tmp + vbCrLf)
            left = right
        End While

    End Sub

    Private Sub AtButton_Click(sender As System.Object, e As System.EventArgs) Handles AtButton.Click
        Form2.ShowDialog()
    End Sub
End Class
