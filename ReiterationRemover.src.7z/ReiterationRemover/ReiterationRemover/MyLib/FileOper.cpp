#include "FileOper.h"
#include "Utility.h"
#include <fstream>
using namespace std;

string FReadAllData(const string &fname)
{
  ifstream ifs(fname, ios::in | ios::binary);
  if(!ifs) throw logic_error("file open error");
  ifs.seekg(0, ios::end);
  int fsize = ifs.tellg();
  ifs.seekg(0, ios::beg);
  string str(fsize, ' ');
  ifs.read((char *)str.c_str(), fsize);
  ifs.close();
  return str;
}

string FReadAllText(const string &fname, int charset)
{
  if(charset == 0 || charset == CP_GBK)
    return FReadAllData(fname);
  else
    return CharsetConvert(FReadAllData(fname), charset, CP_GBK);
}

vector<string> FReadAllLines(const string &fname, bool rmempty, int charset)
{
  string filestr = FReadAllText(fname, charset);
  return Split(filestr, "\r\n", rmempty);
}
