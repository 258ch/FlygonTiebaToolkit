#include <string>
#include <vector>
using std::string;
using std::vector;

string FReadAllData(const string &fname);
string FReadAllText(const string &fname, int charset = 0);
vector<string> FReadAllLines(const string &fname, bool rmempty = false, int charset = 0);
