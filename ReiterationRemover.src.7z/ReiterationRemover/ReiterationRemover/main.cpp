#include <Windows.h>

#include "MainForm.h"


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	XInitXCGUI();
	MainForm w;
	w.show();
	XRunXCGUI();

	return 0;
}