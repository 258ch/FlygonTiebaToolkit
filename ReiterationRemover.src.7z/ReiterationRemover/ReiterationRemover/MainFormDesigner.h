#define MF_W 410
#define MF_H 165
#define MF_T L"����ȥ�ظ���ReiterationRemover - ����"

#define INLBL_X 8
#define INLBL_Y 18
#define INLBL_W 56
#define INLBL_H 24
#define INLBL_T L"�����ļ�"

#define INTXT_X 68
#define INTXT_Y 16
#define INTXT_W 240
#define INTXT_H 24

#define INBTN_X 316
#define INBTN_Y 16
#define INBTN_W 56
#define INBTN_H 24
#define INBTN_T L"ѡ��"

#define OUTLBL_X 8
#define OUTLBL_Y 50
#define OUTLBL_W 50
#define OUTLBL_H 24
#define OUTLBL_T L"����ļ�"

#define OUTTXT_X 68
#define OUTTXT_Y 48
#define OUTTXT_W 240
#define OUTTXT_H 24

#define OUTBTN_X 316
#define OUTBTN_Y 48
#define OUTBTN_W 56
#define OUTBTN_H 24
#define OUTBTN_T L"ѡ��"

#define CNTBTN_X 196
#define CNTBTN_Y 80
#define CNTBTN_W 80
#define CNTBTN_H 24
#define CNTBTN_T L"����"

#define REBTN_X 292
#define REBTN_Y 80
#define REBTN_W 80
#define REBTN_H 24
#define REBTN_T L"ȥ�ظ�"

#define AUTHLNK_X 10
#define AUTHLNK_Y 84
#define AUTHLNK_W 50
#define AUTHLNK_H 16
#define AUTHLNK_T L"��ϵ����"

#define UPDLNK_X 70
#define UPDLNK_Y 84
#define UPDLNK_W 50
#define UPDLNK_H 16
#define UPDLNK_T L"��ȡ����"