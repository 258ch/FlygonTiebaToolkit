#pragma once
#ifndef MAINFORM_H
#define MAINFORM_H

#include "../lib/xcgui.h"
#if _DEBUG
#pragma comment(lib, "../lib/XCGUId.lib")
#else
#pragma comment(lib, "../lib/XCGUI.lib")
#endif

#include <vector>
#include <string>
using namespace std;

class MainForm : public CXEventMsg
{
public:
	MainForm();
	void show();


private:
	//Controls
	HWINDOW w;
	HELE InLabel;
	HELE InText;
	HELE InButton;
	HELE OutLabel;
	HELE OutButton;
	HELE OutText;
	HELE CountButton;
	HELE ReButton;
	HELE AuthLink;
	HELE UpdLink;

	//args
	vector<string> IDList;
	string ofile;

	vector<string> ReadMJ(const string &file);

	//Callbacks
	BOOL InButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL OutButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL CountButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL ReButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL AuthLink_OnClick(HELE hEle, HELE hEleEvent);
	BOOL UpdLink_OnClick(HELE hEle, HELE hEleEvent);

	//avoid copying
	MainForm(MainForm &w);
	MainForm& operator=(MainForm &w);

};
#endif