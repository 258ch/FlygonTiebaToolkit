#include "MainForm.h"
#include "MainFormDesigner.h"

#include "MyLib\FileDlg.h"
#include "MyLib\Utility.h"
#include "MyLib\FileOper.h"

#include <exception>
#include <fstream>
using namespace std;

#include <ShellAPI.h>

MainForm::MainForm()
{
	w = XWnd_CreateWindow(0, 0, MF_W, MF_H, MF_T, 0,
		XC_SY_DEFAULT & ~XC_SY_MAXIMIZE);
	XWnd_SetIconSize(w, 16, 16);
	XWnd_SetIcon(w, LoadIcon(0, IDI_APPLICATION), false);
	XWnd_EnableDragBorder(w, false);
	XWnd_SetTransparentFlag(w, XC_WIND_TRANSPARENT_SHADOW);
	XWnd_SetTransparentAlpha(w, 200); 

	InLabel = XStatic_Create(INLBL_X, INLBL_Y, INLBL_W, INLBL_H, INLBL_T, w);

	InText = XEdit_Create(INTXT_X, INTXT_Y, INTXT_W, INTXT_H, w);
	XEdit_SetReadOnly(InText, true);

	InButton = XBtn_Create(INBTN_X, INBTN_Y, INBTN_W, INBTN_H, INBTN_T, w);
	XCGUI_RegEleEvent(InButton, XE_BNCLICK, &MainForm::InButton_OnClick);

	OutLabel = XStatic_Create(OUTLBL_X, OUTLBL_Y, OUTLBL_W, OUTLBL_H, OUTLBL_T, w);

	OutText = XEdit_Create(OUTTXT_X, OUTTXT_Y, OUTTXT_W, OUTTXT_H, w);
	XEdit_SetReadOnly(OutText, true);

	OutButton = XBtn_Create(OUTBTN_X, OUTBTN_Y, OUTBTN_W, OUTBTN_H, OUTBTN_T, w);
	XCGUI_RegEleEvent(OutButton, XE_BNCLICK, &MainForm::OutButton_OnClick);

	CountButton = XBtn_Create(CNTBTN_X, CNTBTN_Y, CNTBTN_W, CNTBTN_H, CNTBTN_T, w);
	XCGUI_RegEleEvent(CountButton, XE_BNCLICK, &MainForm::CountButton_OnClick);

	ReButton = XBtn_Create(REBTN_X, REBTN_Y, REBTN_W, REBTN_H, REBTN_T, w);
	XCGUI_RegEleEvent(ReButton, XE_BNCLICK, &MainForm::ReButton_OnClick);

	AuthLink = XTextLink_Create(AUTHLNK_X, AUTHLNK_Y, AUTHLNK_W, AUTHLNK_H, AUTHLNK_T, w);
	XCGUI_RegEleEvent(AuthLink, XE_BNCLICK, &MainForm::AuthLink_OnClick);

	UpdLink = XTextLink_Create(UPDLNK_X, UPDLNK_Y, UPDLNK_W, UPDLNK_H, UPDLNK_T, w);
	XCGUI_RegEleEvent(UpdLink, XE_BNCLICK, &MainForm::UpdLink_OnClick);
}

void MainForm::show()
{
	XWnd_ShowWindow(w, SW_SHOW);
}

vector<string> MainForm::ReadMJ(const string &file)
{
	vector<string> result;
	wstring wfname = m2w(file);
	XEdit_SetText(InText, (wchar_t *)wfname.c_str());
	
	result = FReadAllLines(file, true);
	string msg = "��ȡ��ϣ���������" + itos(result.size()) + "����";
	MessageBoxA(0, msg.c_str(), "", 0);

	return result;
}

BOOL MainForm::InButton_OnClick(HELE hEle, HELE hEleEvent)
{
	try
	{
		FileDlg dlg;
		dlg.SetDefExt("txt");
		dlg.SetFilter("�����ļ�(*.*)\0*.*\0\0");
		if(dlg.show()) 
		{
			string file = dlg.GetFile();
			IDList = ReadMJ(file);
		}
	}
	catch(exception &ex)
	{ MessageBoxA(0, ex.what(), 0, 0); }

	return 0;
}

BOOL MainForm::OutButton_OnClick(HELE hEle, HELE hEleEvent)
{
	FileDlg dlg;
	dlg.SetFilter("�����ļ�(*.*)\0*.*\0\0");
	dlg.SetDefExt("txt");
	dlg.SetMode(FileDlg::Mode::SaveDlg);

	if(dlg.show())
	{
		ofile = dlg.GetFile();
		wstring wfname = m2w(ofile);
		XEdit_SetText(OutText, (wchar_t *)wfname.c_str());
	}

	return 0;
}

BOOL MainForm::AuthLink_OnClick(HELE hEle, HELE hEleEvent)
{
	ShellExecuteA(0, 0, "http://www.flygon.net", 0, 0, SW_SHOW);
	return 0;
}

BOOL MainForm::UpdLink_OnClick(HELE hEle, HELE hEleEvent)
{
	ShellExecuteA(0, 0, "http://www.258ch.com/forum-48-1.html", 0, 0, SW_SHOW);
	return 0;
}

BOOL MainForm::CountButton_OnClick(HELE hEle, HELE hEleEvent)
{
	string msg = "��������" + itos(IDList.size()) + "����";
	MessageBoxA(0, msg.c_str(), "", 0);
	return 0;
}

BOOL MainForm::ReButton_OnClick(HELE hEle, HELE hEleEvent)
{
	try
	{
		if(ofile == "") throw exception("��ѡ��Ҫ������ļ���");
		if(IDList.size() == 0) throw exception("��ѡ��Ҫȥ�ظ����ļ���");

		ofstream ofs(ofile, ios::out | ios::app);
		if(!ofs) throw exception("Ŀ���ļ���ʧ�ܣ�");

		vector<string> removed;

		for(auto it = IDList.begin(); it < IDList.end(); ++it)
		{
			bool exist = false;
			for(auto it2 = removed.begin(); it2 < removed.end(); ++it2)
			{
				if(*it == *it2)
				{
					exist = true;
					break;
				}
			}

			if(!exist)
			{
				removed.push_back(*it);
				ofs << *it << endl;
			}
		}

		ofs.close();
		MessageBoxA(0, "������ϣ�", 0, 0);

	}
	catch(exception &ex)
	{ MessageBoxA(0, ex.what(), 0, 0); }

	return 0;
}