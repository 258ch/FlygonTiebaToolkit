﻿Public Class AntiVcode

    Public Declare Function LoadLibFromBuffer Lib "Sunday.dll" (ByVal Buffer As Byte(), ByVal BuffLen As Integer, Optional ByVal pw As String = "123") As Integer
    Public Declare Function GetCodeFromBuffer Lib "Sunday.dll" (ByVal CdsIndex As Integer, ByVal ImgBuffer As Byte(), ByVal ImgBufLen As Integer, ByVal Vcode As Byte()) As Boolean
End Class
