﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.PrTextBox = New System.Windows.Forms.TextBox()
        Me.SeizeButton = New System.Windows.Forms.Button()
        Me.TestButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TimeoutNumeric = New System.Windows.Forms.NumericUpDown()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PrTextBox
        '
        Me.PrTextBox.Location = New System.Drawing.Point(12, 12)
        Me.PrTextBox.Multiline = True
        Me.PrTextBox.Name = "PrTextBox"
        Me.PrTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.PrTextBox.Size = New System.Drawing.Size(214, 267)
        Me.PrTextBox.TabIndex = 0
        '
        'SeizeButton
        '
        Me.SeizeButton.Enabled = False
        Me.SeizeButton.Location = New System.Drawing.Point(12, 312)
        Me.SeizeButton.Name = "SeizeButton"
        Me.SeizeButton.Size = New System.Drawing.Size(95, 23)
        Me.SeizeButton.TabIndex = 1
        Me.SeizeButton.Text = "一键获取"
        Me.SeizeButton.UseVisualStyleBackColor = True
        '
        'TestButton
        '
        Me.TestButton.Enabled = False
        Me.TestButton.Location = New System.Drawing.Point(131, 312)
        Me.TestButton.Name = "TestButton"
        Me.TestButton.Size = New System.Drawing.Size(95, 23)
        Me.TestButton.TabIndex = 2
        Me.TestButton.Text = "检测"
        Me.TestButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 288)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 12)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "超时(ms)"
        '
        'TimeoutNumeric
        '
        Me.TimeoutNumeric.Location = New System.Drawing.Point(106, 286)
        Me.TimeoutNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.TimeoutNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TimeoutNumeric.Name = "TimeoutNumeric"
        Me.TimeoutNumeric.Size = New System.Drawing.Size(120, 21)
        Me.TimeoutNumeric.TabIndex = 4
        Me.TimeoutNumeric.Value = New Decimal(New Integer() {16000, 0, 0, 0})
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(238, 346)
        Me.Controls.Add(Me.TimeoutNumeric)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TestButton)
        Me.Controls.Add(Me.SeizeButton)
        Me.Controls.Add(Me.PrTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "代理设置"
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PrTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SeizeButton As System.Windows.Forms.Button
    Friend WithEvents TestButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TimeoutNumeric As System.Windows.Forms.NumericUpDown
End Class
