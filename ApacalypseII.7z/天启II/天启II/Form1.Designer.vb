﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.EnterCheckBox = New System.Windows.Forms.CheckBox()
        Me.FileRadioButton = New System.Windows.Forms.RadioButton()
        Me.FileTextBox = New System.Windows.Forms.TextBox()
        Me.PrButton = New System.Windows.Forms.Button()
        Me.MailTextBox = New System.Windows.Forms.TextBox()
        Me.IDRadioButton = New System.Windows.Forms.RadioButton()
        Me.TopCheckBox = New System.Windows.Forms.CheckBox()
        Me.AntiCheckBox = New System.Windows.Forms.CheckBox()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Reged = New System.Windows.Forms.ListView()
        Me.ID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PW = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.OutButton = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.BSPictureBox5 = New System.Windows.Forms.PictureBox()
        Me.BSPictureBox4 = New System.Windows.Forms.PictureBox()
        Me.BSPictureBox3 = New System.Windows.Forms.PictureBox()
        Me.BSPictureBox2 = New System.Windows.Forms.PictureBox()
        Me.BSPictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BSTextBox = New System.Windows.Forms.TextBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.BSPictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSPictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.EnterCheckBox)
        Me.GroupBox1.Controls.Add(Me.FileRadioButton)
        Me.GroupBox1.Controls.Add(Me.FileTextBox)
        Me.GroupBox1.Controls.Add(Me.PrButton)
        Me.GroupBox1.Controls.Add(Me.MailTextBox)
        Me.GroupBox1.Controls.Add(Me.IDRadioButton)
        Me.GroupBox1.Controls.Add(Me.TopCheckBox)
        Me.GroupBox1.Controls.Add(Me.AntiCheckBox)
        Me.GroupBox1.Controls.Add(Me.StopButton)
        Me.GroupBox1.Controls.Add(Me.StartButton)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.DelayNumeric)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.TrNumeric)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.PWTextBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.IDTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(231, 290)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'EnterCheckBox
        '
        Me.EnterCheckBox.AutoSize = True
        Me.EnterCheckBox.Location = New System.Drawing.Point(23, 208)
        Me.EnterCheckBox.Name = "EnterCheckBox"
        Me.EnterCheckBox.Size = New System.Drawing.Size(72, 16)
        Me.EnterCheckBox.TabIndex = 26
        Me.EnterCheckBox.Text = "回车提交"
        Me.EnterCheckBox.UseVisualStyleBackColor = True
        '
        'FileRadioButton
        '
        Me.FileRadioButton.AutoSize = True
        Me.FileRadioButton.Location = New System.Drawing.Point(23, 52)
        Me.FileRadioButton.Name = "FileRadioButton"
        Me.FileRadioButton.Size = New System.Drawing.Size(71, 16)
        Me.FileRadioButton.TabIndex = 24
        Me.FileRadioButton.Text = "导入文件"
        Me.FileRadioButton.UseVisualStyleBackColor = True
        '
        'FileTextBox
        '
        Me.FileTextBox.Location = New System.Drawing.Point(104, 51)
        Me.FileTextBox.Name = "FileTextBox"
        Me.FileTextBox.ReadOnly = True
        Me.FileTextBox.Size = New System.Drawing.Size(100, 21)
        Me.FileTextBox.TabIndex = 25
        '
        'PrButton
        '
        Me.PrButton.Enabled = False
        Me.PrButton.Location = New System.Drawing.Point(23, 232)
        Me.PrButton.Name = "PrButton"
        Me.PrButton.Size = New System.Drawing.Size(181, 23)
        Me.PrButton.TabIndex = 22
        Me.PrButton.Text = "代理"
        Me.PrButton.UseVisualStyleBackColor = True
        '
        'MailTextBox
        '
        Me.MailTextBox.Enabled = False
        Me.MailTextBox.Location = New System.Drawing.Point(104, 105)
        Me.MailTextBox.Name = "MailTextBox"
        Me.MailTextBox.Size = New System.Drawing.Size(100, 21)
        Me.MailTextBox.TabIndex = 21
        Me.MailTextBox.Text = "%c%c%c%c%i%i%i%i"
        '
        'IDRadioButton
        '
        Me.IDRadioButton.AutoSize = True
        Me.IDRadioButton.Checked = True
        Me.IDRadioButton.Location = New System.Drawing.Point(23, 25)
        Me.IDRadioButton.Name = "IDRadioButton"
        Me.IDRadioButton.Size = New System.Drawing.Size(59, 16)
        Me.IDRadioButton.TabIndex = 23
        Me.IDRadioButton.TabStop = True
        Me.IDRadioButton.Text = "用户名"
        Me.IDRadioButton.UseVisualStyleBackColor = True
        '
        'TopCheckBox
        '
        Me.TopCheckBox.AutoSize = True
        Me.TopCheckBox.Location = New System.Drawing.Point(132, 186)
        Me.TopCheckBox.Name = "TopCheckBox"
        Me.TopCheckBox.Size = New System.Drawing.Size(72, 16)
        Me.TopCheckBox.TabIndex = 20
        Me.TopCheckBox.Text = "窗体置顶"
        Me.TopCheckBox.UseVisualStyleBackColor = True
        '
        'AntiCheckBox
        '
        Me.AntiCheckBox.AutoSize = True
        Me.AntiCheckBox.Location = New System.Drawing.Point(23, 186)
        Me.AntiCheckBox.Name = "AntiCheckBox"
        Me.AntiCheckBox.Size = New System.Drawing.Size(84, 16)
        Me.AntiCheckBox.TabIndex = 14
        Me.AntiCheckBox.Text = "验证码识别"
        Me.AntiCheckBox.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(120, 261)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(84, 23)
        Me.StopButton.TabIndex = 13
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(23, 261)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(84, 23)
        Me.StartButton.TabIndex = 12
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(21, 161)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "间隔(ms)"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(104, 159)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(100, 21)
        Me.DelayNumeric.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(21, 134)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "线程数"
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(104, 132)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(100, 21)
        Me.TrNumeric.TabIndex = 6
        Me.TrNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 108)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "邮箱"
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(104, 78)
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.Size = New System.Drawing.Size(100, 21)
        Me.PWTextBox.TabIndex = 3
        Me.PWTextBox.Text = "%c%c%c%i%i%i"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "密码"
        '
        'IDTextBox
        '
        Me.IDTextBox.Location = New System.Drawing.Point(104, 24)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(100, 21)
        Me.IDTextBox.TabIndex = 1
        Me.IDTextBox.Text = "龙%s%s"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Reged)
        Me.GroupBox2.Controls.Add(Me.ClearButton)
        Me.GroupBox2.Controls.Add(Me.OutButton)
        Me.GroupBox2.Location = New System.Drawing.Point(397, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(220, 290)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "已注册"
        '
        'Reged
        '
        Me.Reged.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ID, Me.PW})
        Me.Reged.FullRowSelect = True
        Me.Reged.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.Reged.Location = New System.Drawing.Point(6, 20)
        Me.Reged.MultiSelect = False
        Me.Reged.Name = "Reged"
        Me.Reged.ShowGroups = False
        Me.Reged.Size = New System.Drawing.Size(207, 235)
        Me.Reged.TabIndex = 3
        Me.Reged.UseCompatibleStateImageBehavior = False
        Me.Reged.View = System.Windows.Forms.View.Details
        '
        'ID
        '
        Me.ID.Text = "ID"
        Me.ID.Width = 100
        '
        'PW
        '
        Me.PW.Text = "PW"
        Me.PW.Width = 100
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(110, 261)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(103, 23)
        Me.ClearButton.TabIndex = 2
        Me.ClearButton.Text = "清空"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'OutButton
        '
        Me.OutButton.Location = New System.Drawing.Point(6, 261)
        Me.OutButton.Name = "OutButton"
        Me.OutButton.Size = New System.Drawing.Size(103, 23)
        Me.OutButton.TabIndex = 1
        Me.OutButton.Text = "导出"
        Me.OutButton.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 305)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(629, 22)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel1.IsLink = True
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel1.Text = "联系作者"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel4.IsLink = True
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(59, 17)
        Me.ToolStripStatusLabel4.Text = "苍海·国际"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel2.IsLink = True
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel2.Text = "风凝圣域"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel3.IsLink = True
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(80, 17)
        Me.ToolStripStatusLabel3.Text = "冰焰技术联盟"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "*.txt"
        Me.SaveFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.BSPictureBox5)
        Me.GroupBox3.Controls.Add(Me.BSPictureBox4)
        Me.GroupBox3.Controls.Add(Me.BSPictureBox3)
        Me.GroupBox3.Controls.Add(Me.BSPictureBox2)
        Me.GroupBox3.Controls.Add(Me.BSPictureBox1)
        Me.GroupBox3.Controls.Add(Me.BSTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(249, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(142, 290)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "验证码队列"
        '
        'BSPictureBox5
        '
        Me.BSPictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox5.Location = New System.Drawing.Point(20, 244)
        Me.BSPictureBox5.Name = "BSPictureBox5"
        Me.BSPictureBox5.Size = New System.Drawing.Size(100, 40)
        Me.BSPictureBox5.TabIndex = 20
        Me.BSPictureBox5.TabStop = False
        '
        'BSPictureBox4
        '
        Me.BSPictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox4.Location = New System.Drawing.Point(20, 198)
        Me.BSPictureBox4.Name = "BSPictureBox4"
        Me.BSPictureBox4.Size = New System.Drawing.Size(100, 40)
        Me.BSPictureBox4.TabIndex = 19
        Me.BSPictureBox4.TabStop = False
        '
        'BSPictureBox3
        '
        Me.BSPictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox3.Location = New System.Drawing.Point(20, 152)
        Me.BSPictureBox3.Name = "BSPictureBox3"
        Me.BSPictureBox3.Size = New System.Drawing.Size(100, 40)
        Me.BSPictureBox3.TabIndex = 18
        Me.BSPictureBox3.TabStop = False
        '
        'BSPictureBox2
        '
        Me.BSPictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox2.Location = New System.Drawing.Point(20, 106)
        Me.BSPictureBox2.Name = "BSPictureBox2"
        Me.BSPictureBox2.Size = New System.Drawing.Size(100, 40)
        Me.BSPictureBox2.TabIndex = 17
        Me.BSPictureBox2.TabStop = False
        '
        'BSPictureBox1
        '
        Me.BSPictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox1.Location = New System.Drawing.Point(20, 60)
        Me.BSPictureBox1.Name = "BSPictureBox1"
        Me.BSPictureBox1.Size = New System.Drawing.Size(100, 40)
        Me.BSPictureBox1.TabIndex = 16
        Me.BSPictureBox1.TabStop = False
        '
        'BSTextBox
        '
        Me.BSTextBox.Enabled = False
        Me.BSTextBox.Location = New System.Drawing.Point(20, 24)
        Me.BSTextBox.Name = "BSTextBox"
        Me.BSTextBox.Size = New System.Drawing.Size(100, 21)
        Me.BSTextBox.TabIndex = 15
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "*.txt"
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(629, 327)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "天启II·无限注册机 ApocalypseII_InfiniteRegister - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.BSPictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSPictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents OutButton As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents AntiCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TopCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents BSPictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents BSPictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents BSPictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents BSPictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents BSPictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents BSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Reged As System.Windows.Forms.ListView
    Friend WithEvents ID As System.Windows.Forms.ColumnHeader
    Friend WithEvents PW As System.Windows.Forms.ColumnHeader
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents MailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PrButton As System.Windows.Forms.Button
    Friend WithEvents FileTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FileRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents IDRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents EnterCheckBox As System.Windows.Forms.CheckBox

End Class
