﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Text.RegularExpressions
Imports 天启II.MyFunctions

Public Class Form1

    Private OriID As String
    Private OriPW As String
    'Private OriMail As String
    Private DelayTime As Integer
    Private NdAnti As Boolean
    Private BSQ As BSQueue
    Private SW As StreamWriter
    Private CdsIndex As Integer
    Private EndCount As Integer

    'Private PrList(-1) As String
    'Private PrUbd As Integer = -1
    'Private TimeOut As Integer
    Private LockObj As New Object
    Private EnterSub As Boolean = False

    Private IDList(-1) As String
    Private IDUbd As Integer = -1
    Private UseList As Boolean

    Private Sub ToolStripStatusLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel1.Click
        Process.Start("http://sighttp.qq.com/msgrd?v=1&uin=562826179")
    End Sub

    Private Sub ToolStripStatusLabel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel2.Click
        Process.Start("http://www.yy.com/go.html#653238")
    End Sub

    Private Sub ToolStripStatusLabel3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel3.Click
        Process.Start("http://www.4ifta.com/forum.php")
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        If MsgBox("真的要清空么？", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            Reged.Items.Clear()
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "已清除。")
        End If
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If PWTextBox.Text = "" Then Throw New Exception("密码不得为空！")
            OriPW = PWTextBox.Text

            UseList = Not IDRadioButton.Checked
            If Not UseList Then
                If IDTextBox.Text = "" Then Throw New Exception("用户名不得为空！")
                OriID = IDTextBox.Text
            Else
                If IDUbd = -1 Then Throw New Exception("无导入ID！")
                OriID = "成功区" '用于存储文件名
            End If

            'OriMail = MailTextBox.Text
            Dim TrNum As Integer = TrNumeric.Value
            EndCount = TrNum
            NdAnti = AntiCheckBox.Checked
            DelayTime = DelayNumeric.Value
            'TimeOut = Form2.TimeoutNumeric.Value
            'PrList = Split(Form2.PrTextBox.Text, vbCrLf)
            'PrUbd = PrList.Length - 1
            'If PrList(PrUbd) = "" Then PrUbd -= 1
            Dim filename As String = OriID + " " + DateString + ".txt"
            SW = New StreamWriter(Directory.GetCurrentDirectory() + "\" + filename, True, Encoding.Default)
            SW.AutoFlush = True

            BSQ = New BSQueue(TrNum)
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "任务开始...")
            For i As Integer = 0 To TrNum - 1
                BSQ.Tr(i) = New Thread(AddressOf SapiReg)
                BSQ.Tr(i).Start(i)
            Next
            If Not NdAnti Then BSTextBox.Enabled = True
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub SapiReg(ByVal index As Integer)
        'Dim i_pr As Integer = 0
        'If PrUbd <> -1 Then i_pr = TheNext(i_pr, trindex, PrUbd + 1)
        Dim jam As New Jammer(Environment.TickCount + index)
        Dim wc As New WizardHTTP
        Dim i_id As Integer = index
        'wc.TimeOut = TimeOut
        'wc.ReadWriteTimeOut = TimeOut
        While True
            Try
                Dim id As String = ""
                If UseList Then
                    If i_id > IDUbd Then Exit While
                    id = IDList(i_id)
                    i_id += BSQ.TrNum
                Else : id = jam.Jammer(OriID) : End If
                Dim pw As String = jam.Jammer(OriPW)
                'Dim mail As String = jam.Jammer(OriMail)
                wc.SetDefaultHeader()
                Dim cip As String = GetCip()
                Dim poststr As String = "appid=1&clientid=000000000000000&clientip=" + cip + "&crypttype=1&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&tpl=netdisk&username=" + id
                Dim sign As String = MD5Encrypt(poststr + "&sign_key=0c2d71b9d3aee3947c59a7480df05e85", Encoding.Default).ToLower()
                poststr = "username=" + URLEncoGBK(id) + "&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&crypttype=1&clientid=000000000000000&clientip=" + cip + "&tpl=netdisk&appid=1&sig=" + sign
                'If PrUbd <> -1 Then wc.Proxy = New WebProxy(PrList(i_pr))
                wc.SetDefaultHeaderAdr()
                wc.Headers.Set(HttpRequestHeader.UserAgent, "Dalvik/1.4.0 (Linux; U; Android 2.3.3; sdk Build/GRI34)")
                Dim retstr As String = wc.UploadString("http://passport.baidu.com/sapi/reg", poststr)
                '需要验证码的判断
                Dim left As Integer, right As Integer
                If retstr.IndexOf("needvcode"":""1") <> -1 Then
                    left = retstr.IndexOf("vcodestr") + 11
                    right = retstr.IndexOf("""", left)
                    Dim vcode As String = retstr.Substring(left, right - left)
                    wc.SetDefaultHeader()
                    wc.Proxy = Nothing
                    Dim picdata As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                    Dim tmpbs As String = ""
                    If NdAnti Then
                        tmpbs = GetCodeFromAnti(picdata)
                    Else
                        tmpbs = GetCodeFromQueue(picdata, index)
                    End If
                    'cip = GetCip()
                    poststr = "appid=1&clientid=000000000000000&clientip=" + cip + "&crypttype=1&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&tpl=netdisk&username=" + id + "&vcodestr=" + vcode + "&verifycode=" + tmpbs
                    sign = MD5Encrypt(poststr + "&sign_key=0c2d71b9d3aee3947c59a7480df05e85", Encoding.Default).ToLower()
                    poststr = "username=" + URLEncoGBK(id) + "&password=" + Convert.ToBase64String(Encoding.Default.GetBytes(pw)) + "&sex=1&crypttype=1&clientid=000000000000000&clientip=" + cip + "&verifycode=" + tmpbs + "&vcodestr=" + vcode + "&tpl=netdisk&appid=1" + "&sig=" + sign
                    'If PrUbd <> -1 Then wc.Proxy = New WebProxy(PrList(i_pr))
                    wc.SetDefaultHeaderAdr()
                    wc.Headers.Set(HttpRequestHeader.UserAgent, "Dalvik/1.4.0 (Linux; U; Android 2.3.3; sdk Build/GRI34)")
                    retstr = wc.UploadString("http://passport.baidu.com/sapi/reg", poststr)
                End If

                left = retstr.IndexOf("errno") + 8
                right = retstr.IndexOf("""", left)
                Dim errno As String = retstr.Substring(left, right - left)
                If errno = "0" Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + id + " 注册成功！")
                    Dim ilist As New ListViewItem(New String() {id, pw})
                    Reged.Items.Add(ilist)
                    SW.WriteLine(id + ":" + pw)
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + id + " 注册失败！" + SapiGetErrmsg(Convert.ToInt32(errno)))
                    'If errorno = "99" And PrUbd <> -1 Then i_pr = TheNext(i_pr, TrNum, PrUbd + 1) '换代理
                End If
                Thread.Sleep(DelayTime)
            Catch e As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + e.Message)
                'If PrUbd <> -1 Then i_pr = TheNext(i_pr, TrNum, PrUbd + 1) '换代理
            End Try
        End While
        EndCount -= 1
        If EndCount = 0 Then
            Dim tr As New Thread(AddressOf ThreadEnd)
            tr.Start()
        End If
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        Dim tr As New Thread(AddressOf ThreadEnd)
        tr.Start()
    End Sub

    Private Sub TopCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TopCheckBox.CheckedChanged
        Me.TopMost = Not Me.TopMost
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 And BSQ.Count > 0 And Not EnterSub Then
            Dim index As Integer = BSQ.InitialIndex
            BSQ.BS(index) = BSTextBox.Text
            BSTextBox.Clear()
            BSQ.Refresh()
            ShowBS()
        End If
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        'SaveData()
        End
    End Sub

    Private Sub ThreadEnd()
        StopButton.Enabled = False
        If Not NdAnti Then
            BSTextBox.Enabled = False
            ClearBS()
        End If
        BSQ.Abort()
        SW.Close()
        StartButton.Enabled = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已停止。")
    End Sub

    Private Sub ClearImg()
        BSPictureBox1.Image = Nothing
        BSPictureBox2.Image = Nothing
        BSPictureBox3.Image = Nothing
        BSPictureBox4.Image = Nothing
        BSPictureBox5.Image = Nothing
    End Sub

    Private Sub ClearBS()
        ClearImg()
        BSTextBox.Clear()
    End Sub

    Private Sub ShowBS()
        ClearImg()
        Dim i As Integer = BSQ.Count
        If i > 0 Then BSPictureBox1.Image = BSQ.Pic(0)
        If i > 1 Then BSPictureBox2.Image = BSQ.Pic(1)
        If i > 2 Then BSPictureBox3.Image = BSQ.Pic(2)
        If i > 3 Then BSPictureBox4.Image = BSQ.Pic(3)
        If i > 4 Then BSPictureBox5.Image = BSQ.Pic(4)
    End Sub

    Private Sub ToolStripStatusLabel4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel4.Click
        Process.Start("http://www.258ch.com/forum.php")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'LoadData()
        CdsIndex = AntiVcode.LoadLibFromBuffer(My.Resources.baidu, My.Resources.baidu.Length)
    End Sub

    Private Sub SaveData()

        Dim sw0 As New StreamWriter(Directory.GetCurrentDirectory() + "\reg.dat", False)
        For i As Integer = 0 To Reged.Items.Count - 1
            Dim id As String = Reged.Items(i).Text
            Dim pw As String = Reged.Items(i).SubItems(1).Text
            'Dim mail As String = Reged.Items(i).SubItems(2).Text
            'Dim mailpw As String = Reged.Items(i).SubItems(3).Text
            'Dim fresh As String = Reged.Items(i).SubItems(4).Text
            sw0.WriteLine(id + ":" + pw)
            sw0.Flush()
        Next
        sw0.Close()
    End Sub

    Private Sub LoadData()

        Dim fs As New FileStream(Directory.GetCurrentDirectory() + "\reg.dat", FileMode.OpenOrCreate, FileAccess.Read)
        Dim sr As New StreamReader(fs)
        Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
        For i As Integer = 0 To tmp.Length - 1
            Dim tmp2 As String() = Split(tmp(i), ":")
            If UBound(tmp2) < 1 Then
                Continue For
            End If
            Dim index As Integer = Reged.Items.Add(tmp2(0)).Index
            Reged.Items(index).SubItems.Add(tmp2(1))
        Next
        sr.Close()
        fs.Close()
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(MyFunctions.Time() + "数据读取完毕...")
    End Sub

    Private Sub SaveReged()
        If SaveFileDialog1.ShowDialog = DialogResult.OK Then
            Dim sw0 As New StreamWriter(SaveFileDialog1.FileName, True)
            For i As Integer = 0 To Reged.Items.Count
                Dim isfresh As String = Reged.Items(i).SubItems(5).Text
                If isfresh = "是" Then
                    sw0.WriteLine(Reged.Items(i).Text + ":" + Reged.Items(i).SubItems(1).Text + ":" + Reged.Items(i).SubItems(2).Text + ":" + Reged.Items(i).SubItems(3).Text)
                    sw0.Flush()
                End If
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(MyFunctions.Time() + "已导出！")
        End If
    End Sub

    Private Sub SaveMJ()
        If SaveFileDialog1.ShowDialog = DialogResult.OK Then
            Dim sw0 As New StreamWriter(SaveFileDialog1.FileName, True)
            For i As Integer = 0 To Reged.Items.Count
                sw0.WriteLine(Reged.Items(i).Text + ":" + Reged.Items(i).SubItems(1).Text)
                sw0.Flush()
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(MyFunctions.Time() + "已导出！")
        End If
    End Sub

    Private Sub LoadUnreg()
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sr As New StreamReader(OpenFileDialog1.FileName)
            Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
            Dim sw0 As New StreamWriter(Directory.GetCurrentDirectory() + "\reg.dat", True)
            For i As Integer = 0 To tmp.Length
                Dim tmp2 As String() = Split(tmp(i), ":")
                If UBound(tmp2) < 3 Then
                    Continue For
                End If
                Dim index As Integer = Reged.Items.Add(tmp2(0)).Index
                Reged.Items(index).SubItems.Add(tmp2(1))
                Reged.Items(index).SubItems.Add(tmp2(2))
                Reged.Items(index).SubItems.Add(tmp2(3))
                Reged.Items(index).SubItems.Add("否")
                sw0.WriteLine(tmp2(0) + ":" + tmp2(1) + ":" + tmp2(2) + ":" + tmp2(3) + ":" + "否")
                sw0.Flush()
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(MyFunctions.Time() + "导入完毕...")
        End If
    End Sub

    Private Sub OutputButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OutButton.Click
        SaveMJ()
    End Sub

    Private Sub PrButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrButton.Click
        Form2.Show()
    End Sub

    Private Function GetCodeFromQueue(ByVal pic As Byte(), ByVal index As Integer)
        Dim picture As Image = Image.FromStream(New MemoryStream(pic))
        Dim tmpbs As New BSQItem With {.pic = picture, .index = index}
        SyncLock LockObj
            BSQ.Add(tmpbs)
            ShowBS()
        End SyncLock
        BSQ.BS(index) = ""
        While BSQ.BS(index) = "" : Thread.Sleep(200) : End While
        Return BSQ.BS(index)
    End Function

    Private Function GetCodeFromAnti(ByVal pic As Byte())
        Dim tmpbs(64 - 1) As Byte
        AntiVcode.GetCodeFromBuffer(CdsIndex, pic, pic.Length, tmpbs)
        Return Encoding.Default.GetString(tmpbs).Substring(0, 4)
    End Function

    Private Function GetCip() As String
        Dim ran As New Random
        Dim num1 As String = ran.Next(0, 255).ToString()
        Dim num2 As String = ran.Next(0, 255).ToString()
        Dim num3 As String = ran.Next(0, 255).ToString()
        Dim num4 As String = ran.Next(0, 255).ToString()
        Return num1 + "." + num2 + "." + num3 + "." + num4
    End Function

    Private Function SapiGetErrmsg(ByVal i As Integer) As String
        Select Case i
            Case 43
                Return "已频繁"
            Case 42
                Return "验证码错误"
            Case 44
                Return "自动登录错误"
            Case -5
                Return "cert id 无效"
            Case 13
                Return "数据格式错误"
            Case -1
                Return "接口错误"
            Case -4
                Return "ip未授权"
            Case 20
                Return "需要密码"
            Case 10
                Return "需要用户名"
            Case 40
                Return "需要验证码"
            Case 21
                Return "密码过长"
            Case 24
                Return "密码过于简单"
            Case 23
                Return "密码类型错误"
            Case -2
                Return "签名参数错误"
            Case -6
                Return "cert id 未知"
            Case 16
                Return "未知错误"
            Case -3
                Return "tpl 或 appid 未知"
            Case 14
                Return "用户名已存在"
            Case 11
                Return "用户名过长"
            Case 12
                Return "用户名种类错误"
            Case 15
                Return "用户名不可用"
            Case 41
                Return "验证码格式错误"
            Case Else
                Return "错误信息：" + i.ToString()
        End Select
        ' public static final int AUTO_LOGIN_ERROR = 44;
        ' public static final int CERT_ID_UNAVAILABLE = -5;
        ' public static final int DATA_FORMAT_ERROR = 13;
        ' public static final int HIT_STRATEGY = 43;
        ' public static final int INTERFACE_ERROR = -1;
        ' public static final int IP_UNAUTHORIZED = -4;
        ' public static final int NEED_PASSWORD = 20;
        ' public static final int NEED_USERNAME = 10;
        ' public static final int NEED_VERIFYCODE = 40;
        ' public static final int PASSWORD_OVER_LENGTH = 21;
        ' public static final int PASSWORD_TOO_SIMPLE = 24;
        ' public static final int PASSWORD_TYPE_ERROR = 23;
        ' public static final int SIGN_ERROR = -2;
        ' public static final int SUCCESS = 0;
        ' public static final int UNKNOW_CERT_ID = -6;
        ' public static final int UNKNOW_ERROR = 16;
        ' public static final int UNKNOW_TPL_APPID = -3;
        ' public static final int USERNAME_EXIST = 14;
        ' public static final int USERNAME_OVER_LENGTH = 11;
        ' public static final int USERNAME_TYPE_ERROR = 12;
        ' public static final int USERNAME_UNAVAILABLE = 15;
        ' public static final int VERIFYCODE_ERROR = 42;
        ' public static final int VERIFYCODE_FORMAT_ERROR = 41
    End Function

    Private Sub AntiCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AntiCheckBox.CheckedChanged
        If AntiCheckBox.Checked Then
            If Not LoginForm.GTLv4 Then
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + "您的等级未达到4级，不能使用识别！")
                AntiCheckBox.Checked = False
            End If
        End If
    End Sub

    Private Sub FileRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileRadioButton.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sr As New StreamReader(OpenFileDialog1.FileName, Encoding.Default)
            IDList = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            IDUbd = IDList.Length - 1
            If IDList(IDUbd) = "" Then
                IDUbd -= 1
            End If
            FileTextBox.Text = OpenFileDialog1.FileName
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已导入{0}个用户名。", IDUbd + 1)
        Else
            FileRadioButton.Checked = False
            IDRadioButton.Checked = True
        End If
    End Sub

    Private Sub BSTextBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles BSTextBox.KeyPress
        If BSQ.Count > 0 And e.KeyChar = Chr(13) Then
            Dim index As Integer = BSQ.InitialIndex
            If BSTextBox.Text = "" Then : BSQ.BS(index) = "q"
            Else : BSQ.BS(index) = BSTextBox.Text : End If
            BSTextBox.Clear()
            BSQ.Refresh()
            ShowBS()
        End If
    End Sub

    Private Sub CheckBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnterCheckBox.Click
        EnterSub = EnterCheckBox.Checked
    End Sub
End Class