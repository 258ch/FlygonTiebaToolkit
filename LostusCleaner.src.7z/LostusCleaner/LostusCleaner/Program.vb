﻿Imports System.Net

Public Class Program

    Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

    Public Shared Sub main()
        Try
            ServicePointManager.MaxServicePoints = 512
            ServicePointManager.Expect100Continue = False
            Control.CheckForIllegalCrossThreadCalls = False

            AllocConsole()
            Console.Title = "信息输出 for Lostus Cleaner"
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("欢迎使用·忘忧花" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine("彼岸花开彼岸 奈何桥叹奈何" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("本工具禁止作为商业用途，作者保留一切解释权利！")
            Console.WriteLine("Copyright <C> 2013 飞龙 - 苍海·国际" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine("感谢苍海国际、风凝圣域、冰焰技术联盟和正在使用的你～" + vbCrLf)

            'Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(Form1)
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(ex.Message)
            Console.ReadKey()
        End Try
    End Sub
End Class
