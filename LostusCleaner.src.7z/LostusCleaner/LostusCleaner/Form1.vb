﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports LostusCleaner.Utility
Imports LostusCleaner.Profile
Imports SkinSharp

Public Class Form1

    'login
    Private UN As String
    Private PW As String
    Private Cookie As String
    'Private Way As Integer
    Private BS As String
    'clean
    Private StartPage As Integer
    Private EndPage As Integer
    Private NdStop As Boolean
    Private KW As String
    Private AllowReflw As Boolean
    'skin
    Private Skin As SkinH_Net

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadUsr()
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        WayComboBox.SelectedIndex = 0
        Skin = New SkinH_Net
        Skin.AttachRes(My.Resources.MacOSX, My.Resources.MacOSX.Length, "", 0, 0, 0)
        Skin.SetAero(1)
    End Sub

    Private Sub LoadUsr()
        Dim buff(255) As Byte
        GetPrivateProfileString("settings", "cookie", "", buff, buff.Length, ".\settings.ini")
        Cookie = Encoding.Default.GetString(buff).Replace(ChrW(0), "")
        If Cookie <> "" Then
            ReDim buff(255)
            GetPrivateProfileString("settings", "username", "", buff, buff.Length, ".\settings.ini")
            UN = Encoding.Default.GetString(buff).Replace(ChrW(0), "")
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            LoginButton.Enabled = False
            ExitButton.Enabled = True
            IDTextBox.Text = UN
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "用户信息读取完毕...")
        End If
    End Sub

    Private Sub Login()
        Try
            Dim wc As New WizardHTTP
            Dim poststr As String = "_client_id=" + GetStampMobile(True) + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + ToBase64(PW) + "&un=" + URLEncoding(UN, Encoding.UTF8)
            wc.SetDefaultHeader(True)
            Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            Dim left As Integer = retstr.IndexOf("error_code"":5")
            If left <> -1 Then '验证码
                left = retstr.IndexOf("vcode_md5") + 12
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim vcode As String = retstr.Substring(left, right - left)
                wc.SetDefaultHeader()
                Dim pic As Image = Image.FromStream(New MemoryStream(wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)))
                BS = ""
                BSPictureBox.Image = pic
                BSTextBox.Enabled = True
                While BS = "" : Thread.Sleep(200) : End While
                BSTextBox.Enabled = False
                poststr = "_client_id=" + GetStampMobile(True) + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + ToBase64(PW) + "&un=" + URLEncoding(UN, Encoding.UTF8) + "&vcode=" + BS + "&vcode_md5=" + vcode
                wc.SetDefaultHeader(True)
                retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            End If
            Dim re As New Regex("BDUSS"":"".{192}")
            Dim rm As Match = re.Match(retstr)
            If Not rm.Success Then Throw New Exception("登录失败！")
            Cookie = "BDUSS=" + rm.Value.Substring(8, 192)
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            ExitButton.Enabled = True
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "登陆成功！")
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try

    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Cookie = ""
        IDTextBox.Enabled = True
        PWTextBox.Enabled = True
        LoginButton.Enabled = True
        ExitButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已退出。")
    End Sub

    Private Sub LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginButton.Click
        Try
            LoginButton.Enabled = False
            UN = IDTextBox.Text
            PW = PWTextBox.Text
            If UN = "" Or PW = "" Then
                Throw New Exception("请填写用户名和密码！")
            End If
            'Way = WayComboBox.SelectedIndex
            Dim tr As New Thread(AddressOf Login)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 Then
            BS = BSTextBox.Text
            BSPictureBox.Image = Nothing
            BSTextBox.Text = ""
        End If
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If Cookie <> "" Then
            WritePrivateProfileString("settings", "cookie", Cookie, ".\settings.ini")
            WritePrivateProfileString("settings", "username", UN, ".\settings.ini")
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If Cookie = "" Then Throw New Exception("请先登录！")
            StartPage = StartPageNumeric.Value
            EndPage = EndPageNumeric.Value
            KW = KWTextBox.Text
            AllowReflw = AllowCheckBox.Checked
            NdStop = False
            Dim tr As New Thread(AddressOf Clean)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub Clean()

        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, Cookie)
        '获取目标信息
        Dim itieba As String = "",
            tbs As String = ""
        '要用到16位的i贴吧tbs（不是26位的那个），而且对于同一i贴吧值不变
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoding(UN, Encoding.Default))
            itieba = GetMid(retstr, "id"":", ",")
            tbs = GetMid(retstr, "tbs"":""", """")
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "用户信息读取失败！")
            StartButton.Enabled = True
            Exit Sub
        End Try

        Dim innerID As New List(Of String)
        Dim uns As New List(Of String)
        Dim re_id As New Regex("inid=""\d+""")
        Dim re_un As New Regex("href=""#"" n="".{1,14}"" ")

        For i As Integer = StartPage To EndPage
            Try
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/fans?pn=" + i.ToString())
                Dim rms_id As MatchCollection = re_id.Matches(retstr)
                Dim rms_un As MatchCollection = re_un.Matches(retstr)
                For j As Integer = 0 To rms_id.Count - 1
                    Dim tmp As String = rms_id(j).Value.Substring(6, rms_id(j).Value.Length - 7)
                    innerID.Add(tmp)
                    tmp = rms_un(j).Value.Substring(12, rms_un(j).Value.Length - 14)
                    uns.Add(tmp)
                Next
            Catch ex As Exception : End Try
        Next
        Dim idubd As Integer = innerID.Count - 1
        ProgressBar1.Value = 0
        ProgressBar1.Maximum = idubd + 1

        If MessageBox.Show("ID获取完毕，确定要清理吗？", "", MessageBoxButtons.OKCancel) = DialogResult.Cancel Then
            StartButton.Enabled = True
            Exit Sub
        End If
        StopButton.Enabled = True

        For i As Integer = 0 To idubd
            Try
                If NdStop Then Exit For
                ProgressBar1.Value += 1
                If (uns(i).IndexOf(KW) <> -1) Then '关键词为空时结果恒为0
                    wc.SetDefaultHeader()
                    Dim poststr As String = "cmd=add_black_list&itieba_id=" + innerID(i) + "&tbs=" + tbs + "&ie=utf-8"
                    Dim retstr As String = wc.UploadString("http://tieba.baidu.com/i/commit", poststr)
                    '{"is_done":false,"error_no":3,"msg":[],"_info":"\u672a\u77e5\u9519\u8bef","ret":[]}
                    Dim left As Integer = retstr.IndexOf("error") + 10
                    Dim right As Integer = retstr.IndexOf(",", left)
                    Dim errno As String = retstr.Substring(left, right - left)
                    If errno = "0" Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + uns(i) + " 清除成功！")
                        If AllowReflw Then
                            poststr = "cmd=cancel_black_list&itieba_id=" + innerID(i) + "&tbs=" + tbs + "&ie=utf-8"
                            wc.SetDefaultHeader()
                            retstr = wc.UploadString("http://tieba.baidu.com/i/commit", poststr)
                        End If
                    Else
                        left = retstr.IndexOf("_info") + 8
                        right = retstr.IndexOf("""", left)
                        Dim errmsg As String = retstr.Substring(left, right - left)
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + uns(i) + " 清除失败！" + UnicodeDeco(errmsg))
                    End If
                End If
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "清理完毕！")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
    End Sub
End Class
