﻿Imports System.Threading
Imports System.Drawing

Public Class BSQueue

    Private _BS As String() '储存各线程所需要的验证码结果
    Private _Tr As Thread() '储存各线程的引用
    Private BSData As List(Of BSQItem) '验证码队列的实际数据
    Private _TrNum As Integer

    Public Shared vacant As Boolean = True

    Public Sub New(ByVal new_trnum As Integer)
        _TrNum = new_trnum
        ReDim _BS(new_trnum - 1)
        ReDim _Tr(new_trnum - 1)
        BSData = New List(Of BSQItem)(new_trnum)
        For i As Integer = 0 To new_trnum - 1
            _BS(i) = ""
        Next
    End Sub

    Public Property BS(ByVal index As Integer) As String
        Get
            Return _BS(index)
        End Get
        Set(ByVal value As String)
            _BS(index) = value
        End Set
    End Property

    Public Property Tr(ByVal index As Integer) As Thread '<~~~>
        Get
            Return _Tr(index)
        End Get
        Set(ByVal value As Thread)
            _Tr(index) = value
        End Set
    End Property

    Public ReadOnly Property TrNum As Integer
        Get
            Return _TrNum
        End Get
    End Property

    Public ReadOnly Property Pic(ByVal index As Integer) As Image
        Get
            Return BSData.Item(index).pic
        End Get
    End Property

    Public ReadOnly Property Count As Integer '已有验证码数
        Get
            Return BSData.Count
        End Get
    End Property

    Public ReadOnly Property InitialIndex As Integer
        Get
            If Count > 0 Then
                Return BSData(0).index
            Else
                Return -1
            End If
        End Get
    End Property

    Public Sub Add(ByRef bsqi As BSQItem)
        BSData.Add(bsqi)
    End Sub

    Public Function getshowcount(ByVal max As Integer) As Integer '<~~~>
        If BSData.Count > max Then
            Return max
        Else
            Return BSData.Count
        End If
    End Function

    Public Sub Refresh()
        If BSData.Count > 0 Then
            BSData.RemoveAt(0)
        End If
    End Sub

    Public Sub Abort()
        For i As Integer = 0 To _TrNum - 1
            _Tr(i).Abort()
        Next
    End Sub
End Class

Public Structure BSQItem
    Public index As Integer
    Public pic As Image
End Structure
