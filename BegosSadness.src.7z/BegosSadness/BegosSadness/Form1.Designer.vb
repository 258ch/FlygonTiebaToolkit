﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.id_VcodeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.id_LoginButton = New System.Windows.Forms.Button()
        Me.id_InButton = New System.Windows.Forms.Button()
        Me.id_TestButton = New System.Windows.Forms.Button()
        Me.id_WayComboBox = New System.Windows.Forms.ComboBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.id_DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.id_TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.id_UnLogTextBox = New System.Windows.Forms.TextBox()
        Me.id_LogedListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.id_ContextMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.id_DelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.id_DelAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.id_ExToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.id_ExAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.id_OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.id_SaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.RetryNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.id_DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.id_TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.id_ContextMenu.SuspendLayout()
        CType(Me.RetryNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'id_VcodeComboBox
        '
        Me.id_VcodeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.id_VcodeComboBox.FormattingEnabled = True
        Me.id_VcodeComboBox.Items.AddRange(New Object() {"手动输入", "跳过"})
        Me.id_VcodeComboBox.Location = New System.Drawing.Point(492, 257)
        Me.id_VcodeComboBox.Name = "id_VcodeComboBox"
        Me.id_VcodeComboBox.Size = New System.Drawing.Size(80, 20)
        Me.id_VcodeComboBox.TabIndex = 35
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(433, 260)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 12)
        Me.Label17.TabIndex = 34
        Me.Label17.Text = "验证码"
        '
        'id_LoginButton
        '
        Me.id_LoginButton.Location = New System.Drawing.Point(487, 283)
        Me.id_LoginButton.Name = "id_LoginButton"
        Me.id_LoginButton.Size = New System.Drawing.Size(85, 23)
        Me.id_LoginButton.TabIndex = 33
        Me.id_LoginButton.Text = "开始"
        Me.id_LoginButton.UseVisualStyleBackColor = True
        '
        'id_InButton
        '
        Me.id_InButton.Location = New System.Drawing.Point(392, 283)
        Me.id_InButton.Name = "id_InButton"
        Me.id_InButton.Size = New System.Drawing.Size(83, 23)
        Me.id_InButton.TabIndex = 32
        Me.id_InButton.Text = "导入"
        Me.id_InButton.UseVisualStyleBackColor = True
        '
        'id_TestButton
        '
        Me.id_TestButton.Enabled = False
        Me.id_TestButton.Location = New System.Drawing.Point(293, 283)
        Me.id_TestButton.Name = "id_TestButton"
        Me.id_TestButton.Size = New System.Drawing.Size(85, 23)
        Me.id_TestButton.TabIndex = 31
        Me.id_TestButton.Text = "测试"
        Me.id_TestButton.UseVisualStyleBackColor = True
        '
        'id_WayComboBox
        '
        Me.id_WayComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.id_WayComboBox.Enabled = False
        Me.id_WayComboBox.FormattingEnabled = True
        Me.id_WayComboBox.Items.AddRange(New Object() {"客户端"})
        Me.id_WayComboBox.Location = New System.Drawing.Point(343, 257)
        Me.id_WayComboBox.Name = "id_WayComboBox"
        Me.id_WayComboBox.Size = New System.Drawing.Size(80, 20)
        Me.id_WayComboBox.TabIndex = 30
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(292, 260)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 12)
        Me.Label24.TabIndex = 29
        Me.Label24.Text = "方式"
        '
        'id_DelayNumeric
        '
        Me.id_DelayNumeric.Location = New System.Drawing.Point(492, 203)
        Me.id_DelayNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.id_DelayNumeric.Name = "id_DelayNumeric"
        Me.id_DelayNumeric.Size = New System.Drawing.Size(80, 21)
        Me.id_DelayNumeric.TabIndex = 28
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(433, 205)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 12)
        Me.Label22.TabIndex = 27
        Me.Label22.Text = "间隔(ms)"
        '
        'id_TrNumeric
        '
        Me.id_TrNumeric.Location = New System.Drawing.Point(343, 203)
        Me.id_TrNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.id_TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.id_TrNumeric.Name = "id_TrNumeric"
        Me.id_TrNumeric.Size = New System.Drawing.Size(80, 21)
        Me.id_TrNumeric.TabIndex = 26
        Me.id_TrNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(291, 205)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(41, 12)
        Me.Label23.TabIndex = 25
        Me.Label23.Text = "线程数"
        '
        'id_UnLogTextBox
        '
        Me.id_UnLogTextBox.Location = New System.Drawing.Point(292, 24)
        Me.id_UnLogTextBox.Multiline = True
        Me.id_UnLogTextBox.Name = "id_UnLogTextBox"
        Me.id_UnLogTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.id_UnLogTextBox.Size = New System.Drawing.Size(280, 173)
        Me.id_UnLogTextBox.TabIndex = 24
        '
        'id_LogedListView
        '
        Me.id_LogedListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3})
        Me.id_LogedListView.ContextMenuStrip = Me.id_ContextMenu
        Me.id_LogedListView.FullRowSelect = True
        Me.id_LogedListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.id_LogedListView.Location = New System.Drawing.Point(14, 24)
        Me.id_LogedListView.Name = "id_LogedListView"
        Me.id_LogedListView.Size = New System.Drawing.Size(270, 282)
        Me.id_LogedListView.TabIndex = 23
        Me.id_LogedListView.UseCompatibleStateImageBehavior = False
        Me.id_LogedListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "ID"
        Me.ColumnHeader3.Width = 245
        '
        'id_ContextMenu
        '
        Me.id_ContextMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.id_DelToolStripMenuItem, Me.id_DelAllToolStripMenuItem, Me.id_ExToolStripMenuItem, Me.id_ExAllToolStripMenuItem})
        Me.id_ContextMenu.Name = "id_ContextMenu"
        Me.id_ContextMenu.Size = New System.Drawing.Size(125, 92)
        '
        'id_DelToolStripMenuItem
        '
        Me.id_DelToolStripMenuItem.Name = "id_DelToolStripMenuItem"
        Me.id_DelToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.id_DelToolStripMenuItem.Text = "移除选中"
        '
        'id_DelAllToolStripMenuItem
        '
        Me.id_DelAllToolStripMenuItem.Name = "id_DelAllToolStripMenuItem"
        Me.id_DelAllToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.id_DelAllToolStripMenuItem.Text = "移除全部"
        '
        'id_ExToolStripMenuItem
        '
        Me.id_ExToolStripMenuItem.Name = "id_ExToolStripMenuItem"
        Me.id_ExToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.id_ExToolStripMenuItem.Text = "导出选中"
        '
        'id_ExAllToolStripMenuItem
        '
        Me.id_ExAllToolStripMenuItem.Name = "id_ExAllToolStripMenuItem"
        Me.id_ExAllToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.id_ExAllToolStripMenuItem.Text = "导出全部"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(291, 9)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(227, 12)
        Me.Label21.TabIndex = 39
        Me.Label21.Text = "待登录（账号:密码 一行一个 支持拖放）"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(12, 9)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(113, 12)
        Me.Label20.TabIndex = 38
        Me.Label20.Text = "已登录（右键操作）"
        '
        'id_OpenFileDialog
        '
        Me.id_OpenFileDialog.DefaultExt = "*.clst"
        Me.id_OpenFileDialog.FileName = "OpenFileDialog1"
        Me.id_OpenFileDialog.Filter = "数据文件(*.icid)|*.icid"
        '
        'id_SaveFileDialog
        '
        Me.id_SaveFileDialog.DefaultExt = "*.clst"
        Me.id_SaveFileDialog.Filter = "数据文件(*.icid)|*.icid"
        '
        'RetryNumeric
        '
        Me.RetryNumeric.Location = New System.Drawing.Point(343, 230)
        Me.RetryNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.RetryNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.RetryNumeric.Name = "RetryNumeric"
        Me.RetryNumeric.Size = New System.Drawing.Size(80, 21)
        Me.RetryNumeric.TabIndex = 41
        Me.RetryNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(291, 232)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "重试"
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(583, 321)
        Me.Controls.Add(Me.RetryNumeric)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.id_VcodeComboBox)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.id_LoginButton)
        Me.Controls.Add(Me.id_InButton)
        Me.Controls.Add(Me.id_TestButton)
        Me.Controls.Add(Me.id_WayComboBox)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.id_DelayNumeric)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.id_TrNumeric)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.id_UnLogTextBox)
        Me.Controls.Add(Me.id_LogedListView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "北狗の泣·马甲管理工具 - 飞龙"
        CType(Me.id_DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.id_TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.id_ContextMenu.ResumeLayout(False)
        CType(Me.RetryNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents id_VcodeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents id_LoginButton As System.Windows.Forms.Button
    Friend WithEvents id_InButton As System.Windows.Forms.Button
    Friend WithEvents id_TestButton As System.Windows.Forms.Button
    Friend WithEvents id_WayComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents id_DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents id_TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents id_UnLogTextBox As System.Windows.Forms.TextBox
    Friend WithEvents id_LogedListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents id_OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents id_SaveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents id_ContextMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents id_DelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents id_ExToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents id_ExAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents id_DelAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RetryNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
