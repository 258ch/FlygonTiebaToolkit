﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports BegosSadness.MyFunctions

Public Class Form1

    Public Shared IDList As New List(Of ID)
    Public Shared BSQ As BSQueue
    Public Shared ListOccupying As Boolean = False

    Private id_ToLog(-1) As String
    Private id_ToLogUbd As Integer = -1
    Private id_Delay As Integer
    'Private id_Way As Integer
    Private id_VcodeOption As Integer
    Private id_LockObj As New Object()
    Private id_EndCount As Integer
    Private id_Retry As Integer

    Private CdsIndex As Integer

    Const WAP As Integer = 0
    Const CLIENT As Integer = 1

    Public Declare Function LoadLibFromBuffer Lib "Sunday.dll" (ByVal FileBuffer As Byte(), ByVal FileLen As Integer, Optional ByVal Password As String = "123") As Integer
    Public Declare Function GetCodeFromBuffer Lib "Sunday.dll" (ByVal CdsIndex As Integer, ByVal ImgBuffer As Byte(), ByVal ImgBufLen As Integer, ByVal Vcode As Byte()) As Boolean

    Private Sub id_InButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles id_InButton.Click
        If ListOccupying Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请等待其他任务结束！")
        End If
        If id_OpenFileDialog.ShowDialog() = DialogResult.OK Then
            ListOccupying = True
            Dim fname As String = id_OpenFileDialog.FileName
            Dim sr As New StreamReader(fname, Encoding.Default)
            Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            Dim len As Integer = tmp.Length - 1
            For i As Integer = 0 To len
                Dim left As Integer = tmp(i).IndexOf(",")
                If left = -1 Then Continue For
                Dim un As String = tmp(i).Substring(1, left - 1)
                If un = "" Then Continue For
                Dim right As Integer = tmp(i).IndexOf(")", left)
                If right = -1 Then Continue For
                Dim pw As String = tmp(i).Substring(left + 1, right - left - 1)
                Dim cookie As String = tmp(i).Substring(right + 2, tmp(i).Length - right - 3)
                Dim tmpid As New ID With {.UN = un, .PW = pw, .Cookie = cookie}
                IDList.Add(tmpid)
                id_LogedListView.Items.Add(un)
            Next
            ListOccupying = False
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导入成功！")
        End If
    End Sub

    Private Sub id_LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles id_LoginButton.Click
        If id_LoginButton.Text = "开始" Then ' 开始登录
            Try
                id_LoginButton.Enabled = False
                If ListOccupying Then Throw New Exception("请等待其他任务结束！")
                id_VcodeOption = id_VcodeComboBox.SelectedIndex
                id_ToLog = Split(id_UnLogTextBox.Text, vbCrLf)
                id_ToLogUbd = id_ToLog.Length - 1
                If id_ToLog(id_ToLogUbd) = "" Then id_ToLogUbd -= 1
                If id_ToLogUbd = -1 Then Throw New Exception("无待登录马甲！")

                Dim num As Integer = id_TrNumeric.Value
                id_Delay = id_DelayNumeric.Value
                'id_Way = id_WayComboBox.SelectedIndex
                id_Retry = RetryNumeric.Value
                id_EndCount = num
                ListOccupying = True

                Form1.BSQ = New BSQueue(num)

                If id_VcodeOption = 0 Then '手动输入
                    BSForm.Show()
                    Dim tr0 As New Thread(AddressOf BSForm.DoWork)
                    tr0.Start()
                End If

                For i As Integer = 0 To num - 1
                    BSQ.Tr(i) = New Thread(AddressOf id_Login)
                    BSQ.Tr(i).Start(i)
                Next
                id_LoginButton.Text = "停止"
                id_LoginButton.Enabled = True
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
                id_LoginButton.Enabled = True
            End Try

        Else ' 停止登录
            Form1.BSQ.Abort()
            Dim tr As New Thread(AddressOf id_TrEnd)
            tr.Start()
        End If
    End Sub

    Private Sub id_Login(ByVal index As Integer) '测试成功

        Dim wc As New WizardHTTP
        Dim re As New Regex("BDUSS"":"".{192}")
        For i As Integer = index To id_ToLogUbd Step BSQ.TrNum
            Try
                Dim tmp As String() = Split(id_ToLog(i), ":")
                If tmp.Length < 2 Then Continue For
                Dim cookie As String = ""
                Dim success As Boolean = False
                Dim lasterror As String = ""
                
                Dim poststr As String = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + ToBase64(tmp(1)) + "&un=" + URLEncoding(tmp(0), Encoding.UTF8)
                wc.SetDefaultHeaderAdr()
                Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                Dim left As Integer = retstr.IndexOf("error_code"":") + 12
                Dim right As Integer = retstr.IndexOf(",", left)
                Dim errno As String = retstr.Substring(left, right - left)
                Dim count As Integer = 0
                While errno = "5"  '需要验证码
                    If id_VcodeOption = 1 Then Throw New Exception(tmp(0) + " 需要验证码，已跳过！")
                    If count = id_Retry Then Exit While
                    left = retstr.IndexOf("vcode_md5", left) + 12
                    right = retstr.IndexOf("""", left)
                    Dim vcode As String = retstr.Substring(left, right - left)
                    wc.SetDefaultHeader()
                    Dim picdata As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                    Dim tmpbs As String = GetVcodeFromAnti(picdata)
                    poststr = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + ToBase64(tmp(1)) + "&un=" + URLEncoding(tmp(0), Encoding.UTF8) + "&vcode=" + tmpbs + "&vcode_md5=" + vcode
                    wc.SetDefaultHeaderAdr()
                    retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                    left = retstr.IndexOf("error_code"":") + 12
                    right = retstr.IndexOf(",", left)
                    errno = retstr.Substring(left, right - left)
                    count += 1
                End While
                If errno <> "0" Then
                    success = False
                    left = retstr.IndexOf("error_msg") + 12
                    right = retstr.IndexOf("""", left)
                    Dim errmsg As String = retstr.Substring(left, right - left)
                    lasterror = UnicodeDeco(errmsg)
                Else
                    success = True
                    Dim rm As Match = re.Match(retstr)
                    cookie = "BDUSS=" + rm.Value.Substring(8, 192)
                End If

                If Not success Then
                    Throw New Exception(tmp(0) + " 登录失败！" + lasterror)
                End If
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + tmp(0) + " 登录成功！")
                Dim tmpid As New ID With {.UN = tmp(0), .PW = tmp(1), .Cookie = cookie}
                SyncLock id_LockObj
                    IDList.Add(tmpid)
                    id_LogedListView.Items.Add(tmp(0))
                End SyncLock
                id_ToLog(i) = ""
                Thread.Sleep(id_Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next

        id_EndCount -= 1
        If id_EndCount = 0 Then id_TrEnd()
    End Sub

    Private Sub id_TrEnd()
        If id_VcodeOption = 0 Then BSForm.NdHide = True
        Dim tmp As String = ""
        For i As Integer = 0 To id_ToLogUbd
            If id_ToLog(i) <> "" Then tmp += id_ToLog(i) + vbCrLf
        Next
        id_UnLogTextBox.Text = tmp
        ListOccupying = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "登录结束。")
        id_LoginButton.Text = "开始"
    End Sub

    Private Sub id_DelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles id_DelToolStripMenuItem.Click
        If ListOccupying Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请等待其他任务结束！")
            Exit Sub
        End If
        If MessageBox.Show("真的要移除么？", "", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Dim tr As New Thread(AddressOf id_DeleteSth)
            tr.Start()
        End If
    End Sub

    Private Sub id_DeleteSth() '多线程
        ListOccupying = True
        Dim tmp = id_LogedListView.SelectedIndices
        For i As Integer = tmp.Count - 1 To 0 Step -1
            IDList.RemoveAt(tmp(i))
            id_LogedListView.Items.RemoveAt(tmp(i))
        Next
        ListOccupying = False
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已移除。")
    End Sub

    Private Sub id_ExToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles id_ExToolStripMenuItem.Click
        If id_SaveFileDialog.ShowDialog() = DialogResult.OK Then
            Dim ndpw As Boolean = MessageBox.Show("是否要导出密码？", "", MessageBoxButtons.YesNo) = DialogResult.Yes
            Dim tmp = id_LogedListView.SelectedIndices
            Dim sw As New StreamWriter(id_SaveFileDialog.FileName, True, Encoding.Default)
            For i As Integer = 0 To tmp.Count - 1
                sw.WriteLine(IDList(tmp(i)).UN + ":" + IIf(ndpw, IDList(tmp(i)).PW, "") + ":" + IDList(tmp(i)).Cookie)
            Next
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导出成功！")
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        SaveData()
        End
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        id_VcodeComboBox.SelectedIndex = 0
        id_WayComboBox.SelectedIndex = 0
    End Sub

    Private Sub SaveData()
        'ID
        Dim sw As New StreamWriter(Directory.GetCurrentDirectory() + "\id.dat", False, Encoding.Default)
        For Each x As ID In IDList
            sw.WriteLine(x.UN + ":" + x.PW + ":" + x.Cookie)
        Next
        sw.Close()
    End Sub

    Private Sub LoadData()
        'ID
        If File.Exists(Directory.GetCurrentDirectory() + "\id.dat") Then
            Dim sr As New StreamReader(Directory.GetCurrentDirectory() + "\id.dat", Encoding.Default)
            Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            Dim len As Integer = tmp.Length - 1
            If tmp(len) = "" Then len -= 1
            For i As Integer = 0 To len
                Dim tmp2 As String() = Split(tmp(i), ":")
                If tmp2.Length < 3 Then Continue For
                Dim tmpid As New ID With {.UN = tmp2(0), .PW = tmp2(1), .Cookie = tmp2(2)}
                IDList.Add(tmpid)
                id_LogedListView.Items.Add(tmp2(0))
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "马甲读取完毕！")
        End If
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LoadData()
        'CdsIndex = LoadLibFromBuffer(My.Resources.baidu, My.Resources.baidu.Length)
    End Sub

    Private Sub id_ExAllToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles id_ExAllToolStripMenuItem.Click
        If IDList.Count = 0 Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "无可导出马甲！")
            Exit Sub
        End If
        If id_SaveFileDialog.ShowDialog() = DialogResult.OK Then
            Dim ndpw As Boolean = MessageBox.Show("是否要导出密码？", "", MessageBoxButtons.YesNo) = DialogResult.Yes
            Dim sw As New StreamWriter(id_SaveFileDialog.FileName, True, Encoding.Default)
            For Each x As ID In IDList
                sw.WriteLine("(" + x.UN + "," + IIf(ndpw, x.PW, "") + ")[" + x.Cookie + "]")
            Next
            sw.Close()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导出成功！")
        End If
    End Sub

    Private Sub id_DelAllToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles id_DelAllToolStripMenuItem.Click
        If ListOccupying Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请等待其他任务结束！")
            Exit Sub
        End If
        If MessageBox.Show("真的要移除么？", "", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Dim tr As New Thread(AddressOf id_DeleteAll)
            tr.Start()
        End If
    End Sub

    Private Sub id_DeleteAll()
        ListOccupying = True
        IDList.Clear()
        id_LogedListView.Items.Clear()
        ListOccupying = False
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已移除。")
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then '若拖放进来的对象是文件  
            e.Effect = DragDropEffects.All '改变拖放操作的行为，使对象可以被复制或移动至列表视图框  
        End If
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragDrop
        For Each sFile As String In e.Data.GetData(DataFormats.FileDrop) '将拖放进来的文件添加至列表视图框  
            If sFile.EndsWith(".txt") Then
                id_UnLogTextBox.Text = File.ReadAllText(sFile, Encoding.Default)
            End If
        Next
    End Sub

    Private Function GetVcodeFromBSQ(ByVal picdata As Byte(), ByVal index As Integer) As String
        Dim pic As Image = Image.FromStream(New MemoryStream(picdata))
        Dim bsqi As New BSQItem With {.pic = pic, .index = index}
        BSQ.Add(bsqi)
        BSQ.BS(index) = ""
        BSForm.NdShowBS = True
        While BSQ.BS(index) = ""
            Thread.Sleep(200)
        End While
        Return BSQ.BS(index)
    End Function

    Private Function GetVcodeFromAnti(ByVal picdata As Byte()) As String
        Dim tmp2(64 - 1) As Byte
        GetCodeFromBuffer(CdsIndex, picdata, picdata.Length, tmp2)
        Return Encoding.Default.GetString(tmp2).Substring(0, 4)
    End Function

    Private Sub id_VcodeComboBox_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles id_VcodeComboBox.SelectionChangeCommitted
        If id_VcodeComboBox.SelectedIndex = 2 And Not LoginForm.IsSupport Then
            id_VcodeComboBox.SelectedIndex = 0
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "您不是赞助会员，无权限使用识别！")
        End If
    End Sub
End Class
