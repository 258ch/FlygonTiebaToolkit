﻿Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Security.Cryptography

'v0.4 生成时间 2012.7.15 by 飞龙 - CHI

Public Class MyFunctions

    Public Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal hProcess As Integer, ByVal dwMinimumWorkingSetSize As Integer, ByVal dwMaximumWorkingSetSize As Integer) As Integer

    Public Shared Function URLEncoding(ByRef text As String, ByRef enco as Encoding) As String
        If text = "" Then Return ""
        Dim idata() As Byte = enco.GetBytes(text)
        Dim length As Integer = idata.Length - 1
        Dim i As Integer
        Dim sb As New StringBuilder()
        For i = 0 To length
            If (idata(i) >= 48 And idata(i) <= 57) Or (idata(i) >= 65 And idata(i) <= 90) Or (idata(i) >= 97 And idata(i) <= 122) Then
                sb.Append(ChrW(idata(i)))
            Else
                sb.Append("%" + idata(i).ToString("X"))
            End If
        Next i
        Return sb.ToString()
    End Function

    Public Shared Function Time() As String
        Return "[" + TimeString + "] "
    End Function

    Public Shared Function GetStampAndroid() As String
        Dim ran As New Random
        Dim stamp1 As String = Convert.ToInt32(ran.Next(10000, 19999)).ToString()
        Dim stamp2 As String = Convert.ToInt32(ran.Next(1000, 9999)).ToString()
        Dim stamp3 As String = Convert.ToInt32(ran.Next(1000, 9999)).ToString()
        Dim stamp4 As String = Convert.ToInt32(ran.Next(100, 999)).ToString()
        Return "wappc_" + stamp1 + stamp2 + stamp3 + "_" + stamp4
    End Function

    Public Shared Function MD5Encrypt(ByVal text As String, ByVal enco As Encoding) As String
        Dim input As Byte() = enco.GetBytes(text)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim output As Byte() = md5.ComputeHash(input)
        Dim sb As New StringBuilder()
        For Each x As Byte In output
            sb.AppendFormat("{0:X2}", x)
        Next
        Return sb.ToString()
    End Function

    Public Shared Function GetMid(ByVal text As String, ByVal lefttext As String, ByVal righttext As String, Optional ByVal start As Integer = 1) As String
        Dim left As Integer = text.IndexOf(lefttext, start)
        If left = -1 Then
            Return ""
        End If
        left += lefttext.Length
        Dim right As Integer = text.IndexOf(righttext, left)
        If right = -1 Then
            Return ""
        End If
        Return text.Substring(left, right - left)
    End Function

    Public Shared Function GetStamp() As String
        Dim JS As Object = CreateObject("MSScriptControl.ScriptControl", )
        JS.Language = "JavaScript"
        JS.AddCode("function GetRandom(){" + vbCrLf + "return new Date().getTime();" + vbCrLf + "}")
        Return Str(JS.Eval("GetRandom()"))
    End Function

    Public Shared Function TheNext(ByVal i As Integer, ByVal steplen As Integer, ByVal max As Integer) As Integer
        Return (i + steplen) Mod max
    End Function

    Public Shared Function UnicodeDeco(ByVal text As String) As String
        Dim sb As New StringBuilder
        For i As Integer = 0 To Text.Length - 1
            If i > Text.Length - 6 Then
                sb.Append(Text(i))
            ElseIf Text.Substring(i, 2) = "\u" Then
                Dim tmp As Integer = Convert.ToInt32(Text.Substring(i + 2, 4), 16)
                sb.Append(ChrW(tmp))
                i += 5
            Else
                sb.Append(Text(i))
            End If
        Next
        Return sb.ToString()
    End Function

    Public Shared Function GetUid() As String
        Dim ran As New Random
        Dim stamp1 As String = Convert.ToInt32(ran.Next(10000, 19999)).ToString()
        Dim stamp2 As String = Convert.ToInt32(ran.Next(1000, 9999)).ToString()
        Dim stamp3 As String = Convert.ToInt32(ran.Next(1000, 9999)).ToString()
        Dim stamp4 As String = Convert.ToInt32(ran.Next(100, 999)).ToString()
        Return "wapp_" + stamp1 + stamp2 + stamp3 + "_" + stamp4
    End Function

    Public Shared Function ToBase64(ByVal text As String) As String
        Return Convert.ToBase64String(Encoding.Default.GetBytes(text))
    End Function
End Class
