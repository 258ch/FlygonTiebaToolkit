﻿Imports System.Net

Namespace My
    ' 以下事件可用于 MyApplication:
    ' 
    ' Startup: 应用程序启动时在创建启动窗体之前引发。
    ' Shutdown: 在关闭所有应用程序窗体后引发。如果应用程序异常终止，则不会引发此事件。
    ' UnhandledException: 在应用程序遇到未经处理的异常时引发。
    ' StartupNextInstance: 在启动单实例应用程序且应用程序已处于活动状态时引发。
    ' NetworkAvailabilityChanged: 在连接或断开网络连接时引发。
    Partial Friend Class MyApplication

        Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

        Private Sub MyApplication_Startup(ByVal sender As Object, ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
            ServicePointManager.Expect100Continue = False
            ServicePointManager.MaxServicePoints = 512
            Windows.Forms.Control.CheckForIllegalCrossThreadCalls = False
            AllocConsole()
            Console.Title = "信息输出 for Bego's Sadness"
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("欢迎使用·北狗の泣 由VB.net编写" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(".Net - 为工具注入新的活力～" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("本工具禁止作为商业用途，作者保留一切解释权利！")
            Console.WriteLine("Copyright <C> 2013 飞龙 - 苍海·国际" + vbCrLf)
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine("感谢苍海国际、风凝圣域、冰焰技术联盟和正在使用的你～" + vbCrLf)
            'LoginForm.ShowDialog()
        End Sub
    End Class


End Namespace

