﻿Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Security.Cryptography

'v0.3 生成时间 2012.1.15 by 飞龙 - CHI

Public Class MyFunctions

    Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

    Public Shared Function URLEncoUTF8(ByRef Input As String) As String
        If Input = "" Then
            URLEncoUTF8 = ""
            Exit Function
        End If
        Dim idata() As Byte = Encoding.UTF8.GetBytes(Input)
        Dim length As Integer = idata.Length - 1
        Dim i As Integer
        Dim sb As New StringBuilder()
        For i = 0 To length
            If (idata(i) >= 48 And idata(i) <= 57) Or (idata(i) >= 65 And idata(i) <= 90) Or (idata(i) >= 97 And idata(i) <= 122) Then
                sb.Append(Chr(idata(i)))
            Else
                sb.Append("%" + Hex(idata(i)))
            End If
        Next i
        URLEncoUTF8 = sb.ToString()
    End Function

    Public Shared Function URLEncoGBK(ByRef Input As String) As String
        If Input = "" Then
            URLEncoGBK = ""
            Exit Function
        End If
        Dim idata() As Byte = Encoding.Default.GetBytes(Input)
        Dim length As Integer = idata.Length - 1
        Dim i As Integer
        Dim sb As New StringBuilder()
        For i = 0 To length
            If (idata(i) >= 48 And idata(i) <= 57) Or (idata(i) >= 65 And idata(i) <= 90) Or (idata(i) >= 97 And idata(i) <= 122) Then
                sb.Append(Chr(idata(i)))
            Else
                sb.Append("%" + Hex(idata(i)))
            End If
        Next i
        URLEncoGBK = sb.ToString()
    End Function

    Public Shared Function Time() As String
        Time = "[" + TimeString + "] "
    End Function

    Public Shared Sub SetHeader_Req(ByRef req As HttpWebRequest)
        req.Accept = "*/*"
        req.Headers.Set(HttpRequestHeader.AcceptLanguage, "zh-cn")
        req.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)"
        req.KeepAlive = True
        req.Headers.Set("cache-control", "no-cache")
        req.ContentType = "application/x-www-form-urlencoded"
        req.ServicePoint.Expect100Continue = False
    End Sub

    Public Shared Function Jammer(ByVal text As String) As String
        Dim length As Integer = text.Length
        Dim sb As New StringBuilder()
        For i As Integer = 1 To length
            Randomize()
            Dim tmp1 As String = Mid(text, i, 1)
            If tmp1 = "%" Then
                Dim tmp2 As String = Mid(text, i + 1, 1)
                If tmp2 = "C" Then
                    sb.Append(Chr(Fix(Rnd() * 26 + 65)))
                    i += 1
                ElseIf tmp2 = "c" Then
                    sb.Append(Chr(Fix(Rnd() * 26 + 97)))
                    i += 1
                ElseIf tmp2 = "i" Then
                    sb.Append(Chr(Fix(Rnd() * 10 + 48)))
                    i += 1
                ElseIf tmp2 = "s" Then
                    sb.Append(Chr(Fix(Rnd() * 72 + 176) * 16 * 16 + Fix(Rnd() * 94 + 161)))
                    '第一个字节的范围是0xb0-0xF7（即176-247），第二个字节的范围是0xA1-0xFE（即161-254）
                    i += 1
                Else
                    sb.Append(tmp1)
                End If
            Else
                sb.Append(tmp1)
            End If
        Next
        Jammer = sb.ToString()
    End Function

    Public Shared Function GetStampAndroid() As String
        Randomize()
        Dim stamp1 As String = Fix(10000 + Rnd() * 90000).ToString()
        Dim stamp2 As String = Fix(1000 + Rnd() * 9000).ToString()
        Dim stamp3 As String = Fix(1000 + Rnd() * 9000).ToString()
        Dim stamp4 As String = Fix(100 + Rnd() * 900).ToString()
        GetStampAndroid = "wappc_" + stamp1 + stamp2 + stamp3 + "_" + stamp4
    End Function

    Public Shared Function MD5ToString(ByVal text As String, ByVal enco As Encoding) As String
        Dim input As Byte() = enco.GetBytes(text)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim output As Byte() = md5.ComputeHash(input)
        MD5ToString = ByteArrayToHexString(output)
    End Function

    Private Shared Function ByteArrayToHexString(ByVal values As Byte()) As String
        Dim sb As New StringBuilder()
        For Each value As Byte In values
            sb.AppendFormat("{0:X2}", value)
        Next
        ByteArrayToHexString = sb.ToString()
    End Function

    Public Shared Function GetMid(ByVal text As String, ByVal lefttext As String, ByVal righttext As String, Optional ByVal start As Integer = 1) As String
        Dim left As Integer = InStr(start, text, lefttext)
        If left = 0 Then
            Return ""
        End If
        left += lefttext.Length
        Dim right As Integer = InStr(left, text, righttext)
        If right = 0 Then
            Return ""
        End If
        GetMid = Mid(text, left, right - left)
    End Function

    Public Shared Function GetStamp() As String
        Dim JS As Object
        JS = CreateObject("MSScriptControl.ScriptControl", )
        JS.Language = "JavaScript"
        JS.AddCode("function GetRandom(){" + vbCrLf + "return new Date().getTime();" + vbCrLf + "}")
        Return Str(JS.Eval("GetRandom()"))
    End Function

    Public Shared Function TheNext(ByVal i As Integer, ByVal steplen As Integer, ByVal max As Integer) As Integer
        Return (i + steplen) Mod max
    End Function

    Public Shared Function UnicodeDeco(ByVal input As String) As String
        Dim sb As New StringBuilder
        For i As Integer = 0 To input.Length - 1
            If i > input.Length - 6 Then
                sb.Append(input(i))
            ElseIf input.Substring(i, 2) = "\u" Then
                Dim tmp As Integer = Convert.ToInt32(input.Substring(i + 2, 4), 16)
                sb.Append(ChrW(tmp))
                i += 5
            Else
                sb.Append(input(i))
            End If
        Next
        Return sb.ToString()
    End Function
End Class
