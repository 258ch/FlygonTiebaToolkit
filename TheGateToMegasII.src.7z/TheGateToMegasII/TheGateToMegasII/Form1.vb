﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports TheGateToMegasII.MyFunctions
Imports TheGateToMegasII.TBOps
Imports Sunisoft.IrisSkin

Public Class Form1

    Private UN As String
    Private PW As String
    Private Way As Integer
    Private Cookie As String
    Private BS As String
    Private Mode As Integer
    Private NdStop As Boolean
    Private Delay As Integer
    Private Iris As SkinEngine
    Private SignWay As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If File.Exists(Directory.GetCurrentDirectory() + "\settings.sve") Then
            Dim sr As New StreamReader(Directory.GetCurrentDirectory() + "\settings.sve", Encoding.Default)
            Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            If tmp.Length < 2 Then
                Exit Sub
            End If
            If tmp(1) = "" Then
                Exit Sub
            End If
            UN = tmp(0)
            Cookie = tmp(1)
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            LoginButton.Enabled = False
            ExitButton.Enabled = True
            IDTextBox.Text = UN
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "用户信息读取完毕...")
        End If
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        WayComboBox.SelectedIndex = 0
        ModeComboBox.SelectedIndex = 0
        Iris = New SkinEngine(Me, New MemoryStream(My.Resources.Emerald))
    End Sub

    Private Sub ModeComboBox_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModeComboBox.SelectionChangeCommitted
        If ModeComboBox.SelectedIndex = 0 Then '自动获取
            TBTextBox.Enabled = False
        Else '手动输入
            TBTextBox.Enabled = True
        End If
    End Sub

    Private Sub Login()
        Try
            If Way = 0 Then 'wap
                Dim poststr As String = "login_username=" + URLEncoUTF8(UN) + "&login_loginpass=" + PW + "&aaa=%E7%99%BB%E5%BD%95&login=yes&can_input=0&u=http%3A%2F%2Fwapp.baidu.com%2F&tpl=wapp&tn=bdIndex&pu=&ssid=&from=&bd_page_type=1&uid=1337004243356_897&type="
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                Dim retstr As String = wc.UploadString("http://wappass.baidu.com/passport", poststr)
                Dim left As Integer = retstr.IndexOf("genimage?")
                If left <> -1 Then ' 验证码
                    left += 9
                    Dim right As Integer = retstr.IndexOf("""", left)
                    Dim vcode As String = retstr.Substring(left, right - left)
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    Dim pic As Image = Image.FromStream(New MemoryStream(wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)))
                    BS = ""
                    BSPictureBox.Image = pic
                    BSTextBox.Enabled = True
                    While BS = ""
                        Thread.Sleep(200)
                    End While
                    BSTextBox.Enabled = False
                    poststr = "login_verifycode=" + BS + "&login_bdverify=" + vcode + "&login_username=" + URLEncoUTF8(UN) + "&login_loginpass=" + PW + "&login_save=0&login_bdtime=1350292822&login_is_wid=0&login_wid=&login=vc&u=&tn=&tpl=&ssid=&from=&bd_page_type=&uid=1350292801959_829&isphone=&login_username_input=&type="
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    retstr = wc.UploadString("http://wappass.baidu.com/passport", poststr)
                End If
                Dim rethdr As String = wc.ResponseHeaders.Get("Set-Cookie")
                Dim re As New Regex("BDUSS=.{192}")
                Dim rm As Match = re.Match(rethdr)
                If Not rm.Success Then Throw New Exception(UN + " 登录失败！")
                Cookie = rm.Value

            Else ' client
                Dim poststr As String = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(PW)) + "&un=" + URLEncoGBK(UN)
                Dim wc As New WizardHTTP
                wc.SetDefaultHeaderAdr()
                Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                Dim left As Integer = retstr.IndexOf("error_code"":5")
                If left <> -1 Then '验证码
                    left = retstr.IndexOf("vcode_md5") + 12
                    Dim right As Integer = retstr.IndexOf("""", left)
                    Dim vcode As String = retstr.Substring(left, right - left)
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    Dim pic As Image = Image.FromStream(New MemoryStream(wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)))
                    BS = ""
                    BSPictureBox.Image = pic
                    BSTextBox.Enabled = True
                    While BS = ""
                        Thread.Sleep(200)
                    End While
                    BSTextBox.Enabled = False
                    poststr = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(PW)) + "&un=" + URLEncoGBK(UN) + "&vcode=" + BS + "&vcode_md5=" + vcode
                    wc = New WizardHTTP
                    wc.SetDefaultHeaderAdr()
                    retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                End If
                Dim re As New Regex("BDUSS"":"".{192}")
                Dim rm As Match = re.Match(retstr)
                If Not rm.Success Then
                    left = retstr.IndexOf("error_msg") + 12
                    Dim right As Integer = retstr.IndexOf("""", left)
                    Dim errmsg As String = retstr.Substring(left, right - left)
                    Throw New Exception(UN + " 登录失败！" + UnicodeDeco(errmsg))
                End If
                Cookie = "BDUSS=" + rm.Value.Substring(8.192)
            End If
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + UN + " 登陆成功！")
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            ExitButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try

    End Sub

    Private Sub LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginButton.Click
        Try
            LoginButton.Enabled = False
            UN = IDTextBox.Text
            PW = PWTextBox.Text
            If UN = "" Or PW = "" Then
                Throw New Exception("请填写用户名和密码！")
            End If
            Way = WayComboBox.SelectedIndex
            Dim tr As New Thread(AddressOf Login)
            tr.Start()
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 Then
            BS = BSTextBox.Text
            BSPictureBox.Image = Nothing
            BSTextBox.Text = ""
        End If
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Cookie = ""
        IDTextBox.Enabled = True
        PWTextBox.Enabled = True
        LoginButton.Enabled = True
        ExitButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已退出。")
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If Cookie <> "" Then
            Dim sw As New StreamWriter(Directory.GetCurrentDirectory() + "\settings.sve", False, Encoding.Default)
            sw.WriteLine(UN)
            sw.WriteLine(Cookie)
            sw.Close()
        End If
    End Sub

    Private Sub SignUp() 'Thread
        '初始化贴吧
        Dim TBList As New List(Of String)
        Try
            If Mode = 0 Then '自动获取
                GetTBList(TBList)
            Else '手动输入
                Dim tmp As String() = Split(TBTextBox.Text, vbCrLf)
                Dim ubd As Integer = tmp.Length - 1
                If tmp(ubd) = "" Then ubd -= 1
                For i As Integer = 0 To ubd
                    TBList.Add(TBTextBox.Lines(i))
                Next
            End If
            If TBList.Count = 0 Then Throw New Exception("贴吧列表获取失败...")
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
            Exit Sub
        End Try

        StopButton.Enabled = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "贴吧列表获取成功！")

        '开始签到
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, Cookie)
        If SignWay = 1 Then 'client
            For Each x As String In TBList
                Try
                    If NdStop Then Exit For
                    Dim fid As String = GetFid(wc, URLEncoGBK(x))
                    Dim tbs As String = GetTbs(wc)
                    Dim cid As String = GetStampAndroid()
                    Dim poststr As String = Cookie + "&_client_id=" + cid + "&_client_type=2&_client_version=2.5.1&_phone_imei=000000000000000&fid=" + fid + "&from=tieba&kw=" + x + "&net_type=1&tbs=" + tbs
                    Dim sign As String = MD5ToString(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8).ToUpper()
                    poststr = Cookie + "&_client_id=" + cid + "&_client_type=2&_client_version=2.5.1&_phone_imei=000000000000000&fid=" + fid + "&from=tieba&kw=" + URLEncoUTF8(x) + "&net_type=1&tbs=" + tbs + "&sign=" + sign
                    wc.SetDefaultHeaderAdr()
                    Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/c/forum/sign", poststr)
                    Dim errno As String = GetMid(retstr, "code"":", ",")
                    If errno = "0" Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + UN + " 在" + x + "吧签到成功！")
                    Else
                        Dim left As Integer = retstr.IndexOf("error_msg") + 12
                        Dim right As Integer = retstr.IndexOf("""", left)
                        Dim errmsg As String = retstr.Substring(left, right - left)
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + UN + " 在" + x + "吧签到失败！" + UnicodeDeco(errmsg))
                    End If
                    Thread.Sleep(Delay)
                Catch ex As Exception
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + ex.Message)
                End Try
            Next
        Else 'wap
            wc.Encoding = Encoding.UTF8
            For Each x As String In TBList
                Try
                    If NdStop Then Exit For
                    Dim fid As String = GetFid(wc, URLEncoGBK(x))
                    Dim tbs As String = GetTbs(wc)
                    Dim poststr As String = "http://wapp.baidu.com/f/q---07BB56A13DC4C7CB2BCFA6963C1B157B--1-1-0--/sign?tbs=" + tbs + "&fid=" + fid + "&kw=" + URLEncoUTF8(x)
                    wc.SetDefaultHeader()
                    Dim retstr As String = wc.DownloadString(poststr)
                    Dim left As Integer = retstr.IndexOf("light"">") + 7
                    Dim right As Integer = retstr.IndexOf("<", left)
                    Dim errmsg As String = retstr.Substring(left, right - left)
                    If errmsg.IndexOf("签到成功") <> -1 Then
                        Console.ForegroundColor = ConsoleColor.Green
                        Console.WriteLine(Time() + UN + " 在" + x + "吧签到成功！")
                    Else
                        left = retstr.IndexOf("light"">", left) + 7
                        right = retstr.IndexOf("<", left)
                        errmsg = retstr.Substring(left, right - left)
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + UN + " 在" + x + "吧签到失败！" + errmsg)
                    End If
                    Thread.Sleep(Delay)
                Catch ex As Exception
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + ex.Message)
                End Try
            Next
        End If
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "签到完成！")
        StartButton.Enabled = True
        StopButton.Enabled = False

    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If Cookie = "" Then Throw New Exception("请先登录！")
            Delay = DelayNumeric.Value
            Mode = ModeComboBox.SelectedIndex
            SignWay = WayComboBox.SelectedIndex
            NdStop = False
            Dim tr As New Thread(AddressOf SignUp)
            tr.Start()
            '贴吧初始化在线程中进行
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
    End Sub

    Private Sub GetTBList(ByRef arr As List(Of String))
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, Cookie)
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/mylike")
        '取总页数
        Dim left As Integer = retstr.IndexOf("pn=2"">下一页<"),
            right As Integer = 0,
            Total As Integer = 0
        If left = -1 Then
            Total = 1
        Else
            left = retstr.IndexOf("&pn=", left) + 4
            right = retstr.IndexOf("""", left)
            Total = Val(retstr.Substring(left, right - left))
        End If
        '取每一页贴吧
        For i As Integer = 1 To Total
            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/f/like/mylike?pn=" + i.ToString)
            left = retstr.IndexOf("class=""forum_title")
            While True
                left = retstr.IndexOf("<a href=", left)
                If left = -1 Then Exit While
                left = retstr.IndexOf("title", left) + 7
                If left = 6 Then Exit While
                right = retstr.IndexOf("""", left)
                If right = -1 Then Exit While
                Dim tmp As String = retstr.Substring(left, right - left)
                arr.Add(tmp)
                left = right
            End While
        Next
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub
End Class
