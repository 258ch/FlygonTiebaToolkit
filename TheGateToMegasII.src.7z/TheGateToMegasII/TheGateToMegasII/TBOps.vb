﻿Public Class TBOps

    Public Shared Function GetTbs(ByRef wc As WizardHTTP) As String '请预先设置好cookie
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/dc/common/tbs")
        GetTbs = Mid(retstr, 9, 26)
    End Function

    Public Shared Function GetFid(ByRef wc As WizardHTTP, ByVal kw_GBK As String) As String
        wc.SetDefaultHeader()
        'wc.Headers.Set(HttpRequestHeader.Cookie, "TIEBAUID=; TIEBA_USERTYPE=; Hm_lvt=; TIEBA_LOGINED_USER=; wise_device=0; close_liked_forum_tip=1; BAIDUID=:FG=1; BDUSS=; BAIDU_WISE_UID=")
        Dim retstr As String = wc.DownloadString("http://wapp.baidu.com/f?kw=" + kw_GBK)
        Dim left As Integer = retstr.IndexOf("fid"" value") + 12
        If left = 11 Then Return ""
        Dim right As Integer = retstr.IndexOf("""", left)
        If right = -1 Then Return ""
        Return retstr.Substring(left, right - left)
    End Function

End Class
