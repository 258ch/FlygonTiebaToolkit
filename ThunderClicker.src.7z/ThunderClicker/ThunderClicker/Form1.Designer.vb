﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.clk_PrButton = New System.Windows.Forms.Button()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.clk_StartButton = New System.Windows.Forms.Button()
        Me.clk_StopButton = New System.Windows.Forms.Button()
        Me.clk_SucTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.clk_DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.clk_TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.clk_URLTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.hng_LookButton = New System.Windows.Forms.Button()
        Me.hng_StartButton = New System.Windows.Forms.Button()
        Me.hng_StopButton = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.hng_DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.hng_URLTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.hng_WebBrowser = New System.Windows.Forms.WebBrowser()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.clk_DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.clk_TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.hng_DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(1, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(512, 288)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.clk_PrButton)
        Me.TabPage1.Controls.Add(Me.LinkLabel2)
        Me.TabPage1.Controls.Add(Me.LinkLabel1)
        Me.TabPage1.Controls.Add(Me.clk_StartButton)
        Me.TabPage1.Controls.Add(Me.clk_StopButton)
        Me.TabPage1.Controls.Add(Me.clk_SucTextBox)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.clk_DelayNumeric)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.clk_TrNumeric)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.clk_URLTextBox)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(504, 262)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "刷点击"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'clk_PrButton
        '
        Me.clk_PrButton.Location = New System.Drawing.Point(168, 136)
        Me.clk_PrButton.Name = "clk_PrButton"
        Me.clk_PrButton.Size = New System.Drawing.Size(93, 23)
        Me.clk_PrButton.TabIndex = 12
        Me.clk_PrButton.Text = "代理设置"
        Me.clk_PrButton.UseVisualStyleBackColor = True
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(89, 141)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 11
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "获取更新"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(30, 141)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 10
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "联系作者"
        '
        'clk_StartButton
        '
        Me.clk_StartButton.Location = New System.Drawing.Point(267, 136)
        Me.clk_StartButton.Name = "clk_StartButton"
        Me.clk_StartButton.Size = New System.Drawing.Size(93, 23)
        Me.clk_StartButton.TabIndex = 9
        Me.clk_StartButton.Text = "开始"
        Me.clk_StartButton.UseVisualStyleBackColor = True
        '
        'clk_StopButton
        '
        Me.clk_StopButton.Enabled = False
        Me.clk_StopButton.Location = New System.Drawing.Point(366, 136)
        Me.clk_StopButton.Name = "clk_StopButton"
        Me.clk_StopButton.Size = New System.Drawing.Size(93, 23)
        Me.clk_StopButton.TabIndex = 8
        Me.clk_StopButton.Text = "停止"
        Me.clk_StopButton.UseVisualStyleBackColor = True
        '
        'clk_SucTextBox
        '
        Me.clk_SucTextBox.BackColor = System.Drawing.Color.White
        Me.clk_SucTextBox.Location = New System.Drawing.Point(387, 109)
        Me.clk_SucTextBox.Name = "clk_SucTextBox"
        Me.clk_SucTextBox.ReadOnly = True
        Me.clk_SucTextBox.Size = New System.Drawing.Size(72, 21)
        Me.clk_SucTextBox.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(340, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "成功"
        '
        'clk_DelayNumeric
        '
        Me.clk_DelayNumeric.Location = New System.Drawing.Point(229, 110)
        Me.clk_DelayNumeric.Name = "clk_DelayNumeric"
        Me.clk_DelayNumeric.Size = New System.Drawing.Size(72, 21)
        Me.clk_DelayNumeric.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(170, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "间隔(ms)"
        '
        'clk_TrNumeric
        '
        Me.clk_TrNumeric.Location = New System.Drawing.Point(77, 108)
        Me.clk_TrNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.clk_TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.clk_TrNumeric.Name = "clk_TrNumeric"
        Me.clk_TrNumeric.Size = New System.Drawing.Size(72, 21)
        Me.clk_TrNumeric.TabIndex = 3
        Me.clk_TrNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "线程数"
        '
        'clk_URLTextBox
        '
        Me.clk_URLTextBox.Location = New System.Drawing.Point(77, 82)
        Me.clk_URLTextBox.Name = "clk_URLTextBox"
        Me.clk_URLTextBox.Size = New System.Drawing.Size(382, 21)
        Me.clk_URLTextBox.TabIndex = 1
        Me.clk_URLTextBox.Text = "http://tieba.baidu.com/p/"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "URL"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.hng_LookButton)
        Me.TabPage2.Controls.Add(Me.hng_StartButton)
        Me.TabPage2.Controls.Add(Me.hng_StopButton)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.hng_DelayNumeric)
        Me.TabPage2.Controls.Add(Me.hng_URLTextBox)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.hng_WebBrowser)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(504, 262)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "挂机"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'hng_LookButton
        '
        Me.hng_LookButton.Location = New System.Drawing.Point(233, 235)
        Me.hng_LookButton.Name = "hng_LookButton"
        Me.hng_LookButton.Size = New System.Drawing.Size(75, 23)
        Me.hng_LookButton.TabIndex = 7
        Me.hng_LookButton.Text = "查看"
        Me.hng_LookButton.UseVisualStyleBackColor = True
        '
        'hng_StartButton
        '
        Me.hng_StartButton.Location = New System.Drawing.Point(314, 235)
        Me.hng_StartButton.Name = "hng_StartButton"
        Me.hng_StartButton.Size = New System.Drawing.Size(75, 23)
        Me.hng_StartButton.TabIndex = 6
        Me.hng_StartButton.Text = "开始"
        Me.hng_StartButton.UseVisualStyleBackColor = True
        '
        'hng_StopButton
        '
        Me.hng_StopButton.Enabled = False
        Me.hng_StopButton.Location = New System.Drawing.Point(395, 235)
        Me.hng_StopButton.Name = "hng_StopButton"
        Me.hng_StopButton.Size = New System.Drawing.Size(75, 23)
        Me.hng_StopButton.TabIndex = 5
        Me.hng_StopButton.Text = "停止"
        Me.hng_StopButton.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 237)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 12)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "间隔(min)"
        '
        'hng_DelayNumeric
        '
        Me.hng_DelayNumeric.Location = New System.Drawing.Point(81, 235)
        Me.hng_DelayNumeric.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.hng_DelayNumeric.Name = "hng_DelayNumeric"
        Me.hng_DelayNumeric.Size = New System.Drawing.Size(83, 21)
        Me.hng_DelayNumeric.TabIndex = 3
        Me.hng_DelayNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'hng_URLTextBox
        '
        Me.hng_URLTextBox.Location = New System.Drawing.Point(81, 208)
        Me.hng_URLTextBox.Name = "hng_URLTextBox"
        Me.hng_URLTextBox.Size = New System.Drawing.Size(389, 21)
        Me.hng_URLTextBox.TabIndex = 2
        Me.hng_URLTextBox.Text = "http://www.258ch.com/forum.php"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 211)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(23, 12)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "URL"
        '
        'hng_WebBrowser
        '
        Me.hng_WebBrowser.IsWebBrowserContextMenuEnabled = False
        Me.hng_WebBrowser.Location = New System.Drawing.Point(0, 0)
        Me.hng_WebBrowser.MinimumSize = New System.Drawing.Size(20, 20)
        Me.hng_WebBrowser.Name = "hng_WebBrowser"
        Me.hng_WebBrowser.Size = New System.Drawing.Size(504, 202)
        Me.hng_WebBrowser.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(513, 287)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "狂雷·通用刷点击 ThunderClicker - 飞龙"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.clk_DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.clk_TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.hng_DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents clk_URLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents clk_DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents clk_TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents clk_SucTextBox As System.Windows.Forms.TextBox
    Friend WithEvents clk_StartButton As System.Windows.Forms.Button
    Friend WithEvents clk_StopButton As System.Windows.Forms.Button
    Friend WithEvents hng_WebBrowser As System.Windows.Forms.WebBrowser
    Friend WithEvents hng_URLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents hng_DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents hng_LookButton As System.Windows.Forms.Button
    Friend WithEvents hng_StartButton As System.Windows.Forms.Button
    Friend WithEvents hng_StopButton As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents clk_PrButton As System.Windows.Forms.Button

End Class
