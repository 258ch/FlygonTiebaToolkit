﻿Imports System.Net
Imports System.Threading
Imports SkinSharp

Public Class Form1
    '刷点击
    Private clk_URL As Uri
    Private clk_Delay As Integer
    Private clk_TrNum As Integer
    Private clk_Succeed As Integer
    Private clk_NdStop As Boolean
    Private clk_EndCount As Integer
    Private clk_PrList(-1) As String
    Private clk_TimeOut As Integer
    '挂机
    Private hng_Delay As Integer
    Private hng_URL As Uri
    Private hng_Tr As Thread
    'Controls
    Private Skin As SkinH_Net

    Private Sub clk_StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clk_StartButton.Click
        Try
            clk_StartButton.Enabled = False
            If clk_URLTextBox.Text = "" Then Throw New Exception("请填写目标！")
            clk_URL = New Uri(clk_URLTextBox.Text)
            clk_Delay = clk_DelayNumeric.Value
            clk_PrList = ProxyForm.PrTextBox.Text.Split(New String() {vbCrLf}, _
                                                    StringSplitOptions.RemoveEmptyEntries)
            clk_TimeOut = ProxyForm.TimeoutNumeric.Value
            clk_TrNum = clk_TrNumeric.Value
            clk_Succeed = 0
            clk_EndCount = clk_TrNum
            clk_NdStop = False

            Dim tr As New Thread(AddressOf clk_ClickInit)
            tr.Start()
            clk_StopButton.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            clk_StartButton.Enabled = True
        End Try
    End Sub

    Private Sub clk_ClickInit()
        For i As Integer = 0 To clk_TrNum - 1
            Dim tr As New Thread(AddressOf clk_DoClick)
            tr.Start(i)
        Next

        While clk_EndCount <> 0 : Thread.Sleep(200) : End While

        clk_ClickEnd()
    End Sub

    Private Sub clk_ClickEnd()
        clk_StartButton.Enabled = True
        clk_StopButton.Enabled = False
    End Sub

    Private Sub clk_DoClick(ByVal i As Integer)
        Dim wc As New WizardHTTP
        wc.TimeOut = clk_TimeOut
        wc.ReadWriteTimeOut = clk_TimeOut
        Dim i_pr As Integer = -1
        If clk_PrList.Length <> 0 Then
            i_pr = i Mod clk_TrNum
        End If

        While Not clk_NdStop
            Try
                Dim tmp_pr As String = ""
                If i_pr <> -1 Then
                    tmp_pr = clk_PrList(i_pr)
                    wc.Proxy = New WebProxy(tmp_pr)
                    i_pr = (i_pr + clk_TrNum) Mod clk_PrList.Length
                End If

                wc.SetDefaultHeader()
                wc.DownloadString(clk_URL)
                Interlocked.Increment(clk_Succeed)
                clk_SucTextBox.Text = clk_Succeed.ToString()
                Thread.Sleep(clk_Delay)
            Catch ex As Exception
            End Try
        End While
        Interlocked.Decrement(clk_EndCount)
    End Sub

    Private Sub clk_StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clk_StopButton.Click
        clk_NdStop = True
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Sub hng_LookButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles hng_LookButton.Click
        Try
            hng_WebBrowser.Url = New Uri(hng_URLTextBox.Text)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub hng_StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles hng_StartButton.Click
        Try
            hng_StartButton.Enabled = False
            hng_URL = New Uri(hng_URLTextBox.Text)
            hng_Delay = hng_DelayNumeric.Value * 60 * 1000
            hng_Tr = New Thread(AddressOf hng_Hang)
            hng_Tr.Start()
            hng_StopButton.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            hng_StartButton.Enabled = True
        End Try
    End Sub

    Private Sub hng_Hang()
        While True
            Try
                hng_WebBrowser.Url = hng_URL
                Thread.Sleep(hng_Delay)
            Catch ex As Exception : End Try
        End While
    End Sub

    Private Sub hng_StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles hng_StopButton.Click
        hng_Tr.Abort()
        hng_StartButton.Enabled = True
        hng_StopButton.Enabled = False
    End Sub

    Private Sub WebBrowser1_Navigated(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserNavigatedEventArgs) Handles hng_WebBrowser.Navigated
        hng_URL = hng_WebBrowser.Url
        hng_URLTextBox.Text = hng_URL.AbsoluteUri
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        Skin = New SkinH_Net
        Skin.AttachRes(My.Resources.QQ影音, My.Resources.QQ影音.Length, "", 0, 0, 0)
        Skin.SetAero(True)
    End Sub

    Private Sub clk_PrButton_Click(sender As System.Object, e As System.EventArgs) Handles clk_PrButton.Click
        ProxyForm.ShowDialog()
    End Sub
End Class
