﻿Imports System.Net

Public Class Program

    'Public Declare Function AllocConsole Lib "Kernel32.dll" () As Integer

    Public Shared Sub main()
        Try
            ServicePointManager.MaxServicePoints = 512
            ServicePointManager.Expect100Continue = False
            Control.CheckForIllegalCrossThreadCalls = False

            'Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(Form1)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
