﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProxyForm
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProxyForm))
        Me.PrTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TimeoutNumeric = New System.Windows.Forms.NumericUpDown()
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PrTextBox
        '
        Me.PrTextBox.AllowDrop = True
        Me.PrTextBox.Location = New System.Drawing.Point(12, 30)
        Me.PrTextBox.Multiline = True
        Me.PrTextBox.Name = "PrTextBox"
        Me.PrTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.PrTextBox.Size = New System.Drawing.Size(219, 248)
        Me.PrTextBox.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 12)
        Me.Label1.Margin = New System.Windows.Forms.Padding(3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(191, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "代理（一行一个 为空代表不使用）"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 286)
        Me.Label2.Margin = New System.Windows.Forms.Padding(3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "超时(ms)"
        '
        'TimeoutNumeric
        '
        Me.TimeoutNumeric.Location = New System.Drawing.Point(111, 284)
        Me.TimeoutNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.TimeoutNumeric.Name = "TimeoutNumeric"
        Me.TimeoutNumeric.Size = New System.Drawing.Size(120, 21)
        Me.TimeoutNumeric.TabIndex = 3
        Me.TimeoutNumeric.Value = New Decimal(New Integer() {8000, 0, 0, 0})
        '
        'ProxyForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(243, 318)
        Me.Controls.Add(Me.TimeoutNumeric)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PrTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ProxyForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "代理设置"
        CType(Me.TimeoutNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PrTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TimeoutNumeric As System.Windows.Forms.NumericUpDown
End Class
