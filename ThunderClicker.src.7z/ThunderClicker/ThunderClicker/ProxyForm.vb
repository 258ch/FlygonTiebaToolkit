﻿Imports System.IO
Imports System.Text

Public Class ProxyForm

    Private Sub Form3_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub

    Private Sub PrTextBox_DragEnter(sender As System.Object, e As System.Windows.Forms.DragEventArgs) Handles PrTextBox.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Link
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub PrTextBox_DragDrop(sender As System.Object, e As System.Windows.Forms.DragEventArgs) Handles PrTextBox.DragDrop
        Dim files As Array = e.Data.GetData(DataFormats.FileDrop)
        For Each fname As String In files
            If fname.EndsWith(".txt") Then
                Dim lines As String() = File.ReadAllLines(fname, Encoding.Default)
                For Each line As String In lines
                    PrTextBox.AppendText(line + vbCrLf)
                Next
            End If
        Next
    End Sub
End Class