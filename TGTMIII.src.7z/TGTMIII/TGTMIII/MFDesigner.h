#define MF_W 390
#define MF_H 415
#define MF_T L"÷��˹֮��III - ����"

#define LGNGRP_X 12
#define LGNGRP_Y 12
#define LGNGRP_W 164
#define LGNGRP_H 143
#define LGNGRP_T L"��¼"

#define UNLBL_X 6
#define UNLBL_Y 31
#define UNLBL_W 41
#define UNLBL_H 20
#define UNLBL_T L"�û���"

#define UNTXT_X 53
#define UNTXT_Y 28
#define UNTXT_W 100
#define UNTXT_H 21

#define PWLBL_X 6
#define PWLBL_Y 58
#define PWLBL_W 29
#define PWLBL_H 20
#define PWLBL_T L"����"

#define PWTXT_X 53
#define PWTXT_Y 55
#define PWTXT_W 100
#define PWTXT_H 21

#define WAYLBL_X 6
#define WAYLBL_Y 85
#define WAYLBL_W 29
#define WAYLBL_H 20
#define WAYLBL_T L"��ʽ"

#define WAYCB_X 53
#define WAYCB_Y 82
#define WAYCB_W 100
#define WAYCB_H 20

#define LGBTN_X 8
#define LGBTN_Y 108
#define LGBTN_W 70
#define LGBTN_H 23
#define LGBTN_T L"��¼"

#define EXBTN_X 83
#define EXBTN_Y 108
#define EXBTN_W 70
#define EXBTN_H 23
#define EXBTN_T L"�˳�"

#define BSGRP_X 182
#define BSGRP_Y 12
#define BSGRP_W 164
#define BSGRP_H 143
#define BSGRP_T L"��֤��"

#define BSPIC_X 26
#define BSPIC_Y 28
#define BSPIC_W 118
#define BSPIC_H 50

#define BSTXT_X 26
#define BSTXT_Y 83
#define BSTXT_W 118
#define BSTXT_H 21

#define SGGRP_X 12
#define SGGRP_Y 161
#define SGGRP_W 335
#define SGGRP_H 187
#define SGGRP_T L"����"

#define DLYLBL_X 6
#define DLYLBL_Y 17
#define DLYLBL_W 53
#define DLYLBL_H 20
#define DLYLBL_T L"���(ms)"

#define DLYNUM_X 64
#define DLYNUM_Y 15
#define DLYNUM_W 100
#define DLYNUM_H 21
#define DLYNUM_V 1000

#define MDLBL_X 183
#define MDLBL_Y 17
#define MDLBL_W 29
#define MDLBL_H 20
#define MDLBL_T L"ģʽ"

#define MDCB_X 228
#define MDCB_Y 15
#define MDCB_W 100
#define MDCB_H 20

#define SGMLBL_X 6
#define SGMLBL_Y 47
#define SGMLBL_W 53
#define SGMLBL_H 20
#define SGMLBL_T L"ǩ��ģʽ"

#define SGMCB_X 64
#define SGMCB_Y 45
#define SGMCB_W 100
#define SGMCB_H 20

#define TBTXT_X 6
#define TBTXT_Y 72
#define TBTXT_W 322
#define TBTXT_H 80

#define STABTN_X 121
#define STABTN_Y 158
#define STABTN_W 100
#define STABTN_H 23
#define STABTN_T L"��ʼ"

#define STOBTN_X 228
#define STOBTN_Y 158
#define STOBTN_W 100
#define STOBTN_H 23
#define STOBTN_T L"ֹͣ"

#define LNK1_X 6
#define LNK1_Y 163
#define LNK1_W 53
#define LNK1_H 12
#define LNK1_T L"��ϵ����"

#define LNK2_X 62
#define LNK2_Y 163
#define LNK2_W 53
#define LNK2_H 12
#define LNK2_T L"��ȡ����"