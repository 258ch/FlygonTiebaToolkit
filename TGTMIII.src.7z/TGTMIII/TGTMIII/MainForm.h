#pragma once
#ifndef MAINFORM_H
#define MAINFORM_H

#ifdef _DEBUG
#pragma comment(lib, "../lib/XCGUId.lib")
#else
#pragma comment(lib, "../lib/XCGUI.lib")
#endif
#include "../lib/xcgui.h"

#include <Windows.h>

#include <vector>
#include <string>
using namespace std;

class MainForm : public CXEventMsg
{
public:
	MainForm();
	void show();
	void hide();
	
private:
	//Controls
	HWINDOW _MainForm;
	HELE LoginGroup;
	HELE UNLabel;
	HELE UNText;
	HELE PWLabel;
	HELE PWText;
	HELE WayLabel;
	HELE WayCombo;
	HELE LgButton;
	HELE ExButton;
	//-----------------------------
	HELE BSGroup;
	HELE BSPic;
	HELE BSText;
	//-----------------------------
	HELE SignGroup;
	HELE DelayLabel;
	HELE DelayNum;
	HELE ModeLabel;
	HELE ModeCombo;
	HELE SgModeLabel;
	HELE SgModeCombo;
	HELE TBText;
	HELE StartButton;
	HELE StopButton;
	HELE LkLabel1;
	HELE LkLabel2;
	
	//args
	string UN;
	string PW;
	//int Way;
	string Cookie;
	string BS;
	int Mode;
	int SgMode;
	bool NdStop;
	int Delay;

	//Callbacks
	BOOL LgButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL ExButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL StartButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL StopButton_OnClick(HELE hEle, HELE hEleEvent);
	BOOL Lk1_OnClick(HELE hEle, HELE hEleEvent);
	BOOL Lk2_OnClick(HELE hEle, HELE hEleEvent);
	BOOL ModeCB_Selected(HELE hEle, HELE hEleEvent, int id);
	BOOL Form_OnClose(HELE hEle, HELE hEleEvent);
	BOOL BsText_OnTextChange(HELE hEle, HELE hEleEvent);
	
	static void Login(MainForm *p);
	static void SignUp(MainForm *p);
	vector<string> GetTBList();
	void LoadUsr();

	//avoid copying
	MainForm(MainForm &w);
	MainForm &operator=(MainForm &w);

};

#endif