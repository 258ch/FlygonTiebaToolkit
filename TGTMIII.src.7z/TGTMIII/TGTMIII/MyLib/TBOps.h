//v0.35 2013.12.25 by飞龙 - 苍海·国际

#include"WizardHTTP.h"

#include<string>
using std::string;

//请预先设置好Cookie
string GetTbs(WizardHTTP &wc);

string GetFid(WizardHTTP &wc, const string &KW_GBK);
