#include "Console.h"
#include <Windows.h>
#include <io.h>
#include <fcntl.h>
#include <iostream>
using std::ios;

void RedirectStdOut()
{
	HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	int hCrt = _open_osfhandle((int)hCon, _O_TEXT);
	FILE *hf = _fdopen(hCrt, "w"); 
	setvbuf(hf, NULL, _IONBF, 0);
	*stdout = *hf;
	ios::sync_with_stdio();
}