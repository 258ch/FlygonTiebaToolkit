#include"TBOps.h"

//Set Cookie Ready Before
string GetTbs(WizardHTTP &wc)
{
	string retstr = wc.HTTPSubmit("http://tieba.baidu.com/dc/common/tbs");
	return retstr.substr(8, 26);
}

string GetFid(WizardHTTP &wc, const string &KW_GBK)
{
	string retstr = wc.HTTPSubmit("http://tieba.baidu.com/f/commit/share/fnameShareApi?fname=" + KW_GBK);
	int left = retstr.find("fid\":");
	if(left == -1) return "";
	left += 5;
	int right = retstr.find(',', left);
	if(right == -1) return "";
	return retstr.substr(left, right - left);
}