#ifndef CONSOLE_H
#define CONSOLE_H

#define OPTHANDLE GetStdHandle(STD_OUTPUT_HANDLE)
#define SetConsoleColor(c) SetConsoleTextAttribute(OPTHANDLE, c);

enum ConsoleColor
{
	Black, DarkBlue, DarkGreen, DarkCyan, DarkRed, DarkPurple, DarkYellow, DarkGray,
	Gray, Blue, Green, Cyan, Red, Purple, Yellow, White
};

//����̨�ض���
void RedirectStdOut();

#endif

