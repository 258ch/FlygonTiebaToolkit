/*********************************
 * C++ WizardClient - ���� - CHI
 * v0.7 2013.12.25
 * �ṩHTTP�����Լ�Э��ͷ�Ĺ���
 *********************************/
 
#ifndef WIZARDCLIENT_H
#define WIZARDCLIENT_H

#include <string>
#include <vector>
using std::string;
using std::vector;

#define HTTPGet(URL) HTTPSubmit(URL)
#define HTTPPost(URL, data) HTTPSubmit(URL, "POST", data)
#define HTTPGetData(URL) HTTPSubmitData(URL)
#define HTTPPostData(URL, data) HTTPSubmitData(URL, "POST", data)

class WizardClient
{
protected:

    struct Header
    {
	    string name;
	    string value;

	    Header(const string &n, const string &v)
	        : name(n), value(v) {}
    };

	struct URI
	{
		string Host;
		string SubAddr;
		int Port;

		URI(const string &h, const string &s, int p)
			: Host(h), SubAddr(s), Port(p) {}
	};

public:
	
	WizardClient();
	~WizardClient();

	//Ҫ��֤ÿ��ͷ�����ֲ��ظ�
	void SetHeader(const string &name, const string &value);
	string GetHeader(const string &name) const;
	void ClearHeader(const string &name);
	void ClearAllHeaders();
	void SetDefaultHeader(bool mobile = false);
	//void SetDefaultHeaderAdr();

	void SetCharset(int newchar);
	int GetCharset() const;
	int GetTimeout() const;
	void SetTimeout(int newtime);
	string GetProxy() const;
	void SetProxy(const string &newproxy);
	string GetRethdr() const;
	bool GetAutoRedirect() const;
	void SetAutoRedirect(bool newauto);

	string HTTPSubmit(const string &URL, const string &method = "GET", const string &data = "");
	virtual string HTTPSubmitData(const string &URL, const string &method = "GET", const string &data = "") =0;

protected:

	vector<Header> Headers;
	int Charset; // ���� CP_ACP CP_UTF7 CP_UTF8 ��
	int Timeout;
	string Proxy;
	string Rethdr;
	bool AutoRedirect;
    
	//����� ���� �ӵ�ַ �Ͷ˿�
	static URI SplitURL(const string &URL);
};

#endif