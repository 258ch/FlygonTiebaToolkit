#include"WizardClient.h"
#include"Utility.h"

#include <exception>
using namespace std;

WizardClient::WizardClient()
{
	//this->SetDefaultHeader();
	this->Charset = CP_ACP;
	this->Proxy = "";
	this->Timeout = 8000;
	this->Rethdr = "";
	this->AutoRedirect = true;
}

WizardClient::~WizardClient(){}

void WizardClient::SetHeader(const string &name, const string &value)
{
	if(value == "")
	{
		ClearHeader(name);
		return;
	}

	for(int i = 0; i < this->Headers.size(); i++)
	{
		if(this->Headers.at(i).name == name)
		{
			this->Headers.at(i).value = value;
			return;
		}
	}
	this->Headers.push_back(Header(name, value));
}

string WizardClient::GetHeader(const string &name) const
{
	for(int i = 0; i < this->Headers.size(); i++)
	{
		if(this->Headers.at(i).name == name)
            return this->Headers.at(i).value;
	}
	return "";
}

void WizardClient::ClearHeader(const string &name)
{
	for(int i = 0; i < this->Headers.size(); i++)
	{
		if(this->Headers.at(i).name == name)
		{
			vector<Header>::iterator it = this->Headers.begin();
			it += i;
			this->Headers.erase(it);
			return;
		}
	}
}

void WizardClient::ClearAllHeaders()
{
	this->Headers.clear();
}

void WizardClient::SetDefaultHeader(bool mobile)
{
	this->SetHeader("Accept","*/*");
	this->SetHeader("Accept-Language","zh-cn");
	if (mobile)
		this->SetHeader("User-Agent","Dalvik/1.1.0 (Linux; U; Android 2.1; sdk Build/ERD79)");
	else
		this->SetHeader("User-Agent","Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)"); //IE7
	this->SetHeader("Connection","Keep-Alive");
	this->SetHeader("Content-Type","application/x-www-form-urlencoded");
	this->SetHeader("Cache-Control","no-cache");
}

void WizardClient::SetCharset(int newchar)
{
	this->Charset = newchar;
}

int WizardClient::GetCharset() const
{
	return this->Charset;
}

int WizardClient::GetTimeout() const
{
	return this->Timeout;
}

void WizardClient::SetTimeout(int newtime)
{
	this->Timeout = newtime;
}

string WizardClient::GetProxy() const
{
	return this->Proxy;
}

void WizardClient::SetProxy(const string &newproxy)
{
	this->Proxy = newproxy;
}

string WizardClient::GetRethdr() const
{
	return this->Rethdr;
}

bool WizardClient::GetAutoRedirect() const
{
	return this->AutoRedirect;
}

void WizardClient::SetAutoRedirect(bool newauto)
{
	this->AutoRedirect = newauto;
}

string WizardClient::HTTPSubmit(const string &URL, const string &method, const string &data)
{
    string retn = HTTPSubmitData(URL, method, data);
    if(Charset == CP_ACP || Charset == CP_GBK)
	    return retn;
    else
	    return CharsetConvert(retn, Charset, CP_GBK);
}

WizardClient::URI WizardClient::SplitURL(const string &URL)
{
	string host = "", sub = "";
	int port = 0;

	int left = URL.find("://");
	if(left == -1) throw exception("URL��ʽ����");
	string tmp = URL.substr(0, left);
	if(tmp == "http")
        port = 80;
	else if(tmp == "https")
        port = 443;
	else throw exception("URL��ʽ����");
	left += 3;
	int right = URL.find("/", left);
	if(right == -1)
	{
		host = URL.substr(left, URL.size() - left);
		sub = "/";
	}
	else
	{
		host = URL.substr(left, right - left);
		right += 1;
		sub = URL.substr(right, URL.size() - right);
	}
	return URI(host, sub, port);
}