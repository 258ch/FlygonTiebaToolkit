/*********************************
 * C++ WizardHTTP - ���� - CHI
 * v0.6 2013.12.25
 * ����WinHTTP��HTTP����ʵ��
 *********************************/

#ifndef WIZARDHTTP_H
#define WIZARDHTTP_H

#include"WizardClient.h"

class WizardHTTP : public WizardClient
{
public:
	virtual string HTTPSubmitData(const string &URL, const string &method = "GET", const string &data = "");
};

#endif