#include <Windows.h>

#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")

#include "WizardHTTP.h"
#include "Utility.h"

using namespace std;

string WizardHTTP::HTTPSubmitData(const string &URL, const string &method, const string &data)
{
	URI uri = SplitURL(URL);
	HINTERNET hInternet;
	if(this->Proxy == "")
        hInternet = WinHttpOpen(m2w(this->GetHeader("User-Agent")).c_str(), WINHTTP_ACCESS_TYPE_NO_PROXY, 0, 0, 0);
	else
        hInternet = WinHttpOpen(m2w(this->GetHeader("User-Agent")).c_str(), WINHTTP_ACCESS_TYPE_NAMED_PROXY, m2w(this->Proxy).c_str(), 0, 0);
	if(!hInternet) throw exception("�������ʧ�ܣ�");
	WinHttpSetTimeouts(hInternet, this->Timeout, this->Timeout, this->Timeout, this->Timeout);
	int redirect = 0;
	if(this->AutoRedirect)
        redirect = WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;
	else
		redirect = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
	WinHttpSetOption(hInternet, WINHTTP_OPTION_REDIRECT_POLICY, &redirect, 4);
	HINTERNET hConnect = WinHttpConnect(hInternet, m2w(uri.Host).c_str(), uri.Port, 0);
	if(!hConnect)
	{
		WinHttpCloseHandle(hInternet);
		throw exception("��������ʧ�ܣ�");
	}
	HINTERNET hReq = WinHttpOpenRequest(hConnect, m2w(method).c_str(), m2w(uri.SubAddr).c_str(), 0, 0, 0, uri.Port==80?0:WINHTTP_FLAG_SECURE);
	if(!hReq)
	{
		WinHttpCloseHandle(hInternet);
		WinHttpCloseHandle(hConnect);
		throw exception("��������ʧ�ܣ�");
	}
	for(int i = 0; i < this->Headers.size(); i++)
	{
		wstring tmp = m2w(this->Headers.at(i).name);
		tmp += L": ";
		tmp += m2w(this->Headers.at(i).value);
		tmp += L"\n";
		WinHttpAddRequestHeaders(hReq, tmp.c_str(), -1, WINHTTP_ADDREQ_FLAG_ADD | WINHTTP_ADDREQ_FLAG_REPLACE);
	}
	if(method == "POST")
	{
		wstring tmp = L"Content-Length: ";
		tmp += itows(data.size());
		tmp += L"\n";
		WinHttpAddRequestHeaders(hReq, tmp.c_str(), -1, WINHTTP_ADDREQ_FLAG_ADD | WINHTTP_ADDREQ_FLAG_REPLACE);
		WinHttpSendRequest(hReq, 0, 0, (void *)data.c_str(), data.size(), data.size(), 0);
	}
	else
        WinHttpSendRequest(hReq, 0, 0, 0, 0, 0, 0);
	while(!WinHttpReceiveResponse(hReq, 0))
		DoEvent();
	DWORD size = 0; //�Ѷ��ֽ��� __inout
	WinHttpQueryHeaders(hReq, 22, 0, 0, &size, 0); //�ȿ����ж����ֽڵ�����
	wchar_t *wbuff = new wchar_t[size + 1];
	WinHttpQueryHeaders(hReq, 22, 0, wbuff, &size, 0);
	wbuff[size] = 0;
	this->Rethdr = w2m(wstring(wbuff));
	delete[] wbuff;
	const int BUFFSIZE = 2048;
	char buff[BUFFSIZE];
	size = 0;
	string retn;
	do
	{
		WinHttpReadData(hReq, buff, BUFFSIZE, &size);
		for(int i = 0; i < size; i++) retn += buff[i];
		DoEvent();
	}
	while(size);
	WinHttpCloseHandle(hReq);
	WinHttpCloseHandle(hConnect);
	WinHttpCloseHandle(hInternet);
	return retn;
}