#include "MainForm.h"
#include "resource.h"
#include "MFDesigner.h"

#include "MyLib\md5.h"
#include "MyLib\Utility.h"
#include "MyLib\WizardHTTP.h"
#include "MyLib\TBOps.h"
#include "MyLib\Console.h"

#include <fstream>
#include <regex>
#include <string>
#include <iostream>
using namespace std;

#define SGMODE_WAP 0
#define SGMODE_CLIENT 1

MainForm::MainForm()
{
	_MainForm = XWnd_CreateWindow(0, 0, MF_W, MF_H, MF_T, 0, XC_SY_DEFAULT & ~XC_SY_MAXIMIZE); //��������
	XWnd_SetIcon(_MainForm, LoadIcon(GetModuleHandle(0), (wchar_t *)IDI_ICON1), false);
	XWnd_SetIconSize(_MainForm, 16, 16);
	XWnd_EnableDragBorder(_MainForm, false);
	XWnd_SetTransparentAlpha(_MainForm, 200);
	XWnd_SetTransparentFlag(_MainForm, XC_WIND_TRANSPARENT_SHADOW);
	XCGUI_RegEleEvent(XWnd_GetButtonClose(_MainForm), XE_BNCLICK, &MainForm::Form_OnClose);
	
	LoginGroup = XGBox_Create(LGNGRP_X, LGNGRP_Y, LGNGRP_W, LGNGRP_H, LGNGRP_T, _MainForm);
	//{
	UNLabel = XStatic_Create(UNLBL_X, UNLBL_Y, UNLBL_W, UNLBL_H, UNLBL_T, LoginGroup);

	UNText = XEdit_Create(UNTXT_X, UNTXT_Y, UNTXT_W, UNTXT_H, LoginGroup);

	PWLabel = XStatic_Create(PWLBL_X, PWLBL_Y, PWLBL_W, PWLBL_H, PWLBL_T, LoginGroup);

	PWText = XEdit_Create(PWTXT_X, PWTXT_Y, PWTXT_W, PWTXT_H, LoginGroup);
	XEdit_EnablePassBox (PWText, true);

	WayLabel = XStatic_Create(WAYLBL_X, WAYLBL_Y, WAYLBL_W, WAYLBL_H, WAYLBL_T, LoginGroup);

	WayCombo = XComboBox_Create(WAYCB_X, WAYCB_Y, WAYCB_W, WAYCB_H, LoginGroup);
	//{
	XComboBox_EnableEdit(WayCombo, false);
	//XComboBox_AddString(WayCombo, L"wap");
	XComboBox_AddString(WayCombo, L"client");
	XComboBox_SetSelectItem(WayCombo, 0);
	//}
	XEle_EnableEle(WayCombo, false);

	LgButton = XBtn_Create(LGBTN_X, LGBTN_Y, LGBTN_W, LGBTN_H, LGBTN_T, LoginGroup);
	XCGUI_RegEleEvent(LgButton, XE_BNCLICK, &MainForm::LgButton_OnClick);

	ExButton = XBtn_Create(EXBTN_X, EXBTN_Y, EXBTN_W, EXBTN_H, EXBTN_T, LoginGroup);
	XCGUI_RegEleEvent(ExButton, XE_BNCLICK, &MainForm::ExButton_OnClick);
	XEle_EnableEle(ExButton, false);
	//}

	BSGroup = XGBox_Create(BSGRP_X, BSGRP_Y, BSGRP_W, BSGRP_H, BSGRP_T, _MainForm);
	//{
	BSPic = XPic_Create(BSPIC_X, BSPIC_Y, BSPIC_W, BSPIC_H, BSGroup);
	BSText = XEdit_Create(BSTXT_X, BSTXT_Y, BSTXT_W, BSTXT_H, BSGroup);
	XCGUI_RegEleEvent(BSText, XE_EDIT_CHANGE, &MainForm::BsText_OnTextChange);
	XEle_EnableEle(BSText, false);
	//}

	SignGroup = XGBox_Create(SGGRP_X, SGGRP_Y, SGGRP_W, SGGRP_H, SGGRP_T, _MainForm);
	//{
	DelayLabel = XStatic_Create(DLYLBL_X, DLYLBL_Y, DLYLBL_W, DLYLBL_H, DLYLBL_T, SignGroup);

	DelayNum = XEdit_Create(DLYNUM_X, DLYNUM_Y, DLYNUM_W, DLYNUM_H, SignGroup);
	XEdit_SetInt (DelayNum, DLYNUM_V);
	XEdit_EnableNumber (DelayNum, true);

	ModeLabel = XStatic_Create(MDLBL_X, MDLBL_Y, MDLBL_W, MDLBL_H, MDLBL_T, SignGroup);

	ModeCombo = XComboBox_Create(MDCB_X, MDCB_Y, MDCB_W, MDCB_H, SignGroup);
	//{
	XComboBox_EnableEdit(ModeCombo, false);
	XComboBox_AddString(ModeCombo, L"�Զ���ȡ");
	XComboBox_AddString(ModeCombo, L"�ֶ�����");
	XComboBox_SetSelectItem(ModeCombo, 0);
	XCGUI_RegEleEvent(ModeCombo, XE_COMBOBOX_SELECT, &MainForm::ModeCB_Selected);
	//}

	SgModeLabel = XStatic_Create(SGMLBL_X, SGMLBL_Y, SGMLBL_W, SGMLBL_H, SGMLBL_T, SignGroup);

	SgModeCombo = XComboBox_Create(SGMCB_X, SGMCB_Y, SGMCB_W, SGMCB_H, SignGroup);
	//{
	XComboBox_EnableEdit(SgModeCombo, false);
	XComboBox_AddString(SgModeCombo, L"wap");
	XComboBox_AddString(SgModeCombo, L"client");
	XComboBox_SetSelectItem(SgModeCombo, 0);
	//}

	TBText = XEdit_Create(TBTXT_X, TBTXT_Y, TBTXT_W, TBTXT_H, SignGroup);
	XEle_EnableEle(TBText, false);
	XEdit_EnableMultiLine (TBText, true);

	StartButton = XBtn_Create(STABTN_X, STABTN_Y, STABTN_W, STABTN_H, STABTN_T, SignGroup);
	XCGUI_RegEleEvent(StartButton, XE_BNCLICK, &MainForm::StartButton_OnClick);

	StopButton = XBtn_Create(STOBTN_X, STOBTN_Y, STOBTN_W, STOBTN_H, STOBTN_T, SignGroup);
	XCGUI_RegEleEvent(StopButton, XE_BNCLICK, &MainForm::StopButton_OnClick);
	XEle_EnableEle(StopButton, false);

	LkLabel1 = XTextLink_Create(LNK1_X, LNK1_Y, LNK1_W, LNK1_H, LNK1_T, SignGroup);
	XTextLink_ShowUnderline(LkLabel1, true, true);
	XCGUI_RegEleEvent(LkLabel1, XE_BNCLICK, &MainForm::Lk1_OnClick);

	LkLabel2 = XTextLink_Create(LNK2_X, LNK2_Y, LNK2_W, LNK2_H, LNK2_T, SignGroup);
	XTextLink_ShowUnderline(LkLabel2, true, true);
	XCGUI_RegEleEvent(LkLabel2, XE_BNCLICK, &MainForm::Lk2_OnClick);
	//}

	LoadUsr();
}

void MainForm::LoadUsr()
{
	const int buffsize = 256;
	char buff[buffsize];
	int size = GetPrivateProfileStringA("settings", "cookie", "", buff, buffsize, ".\\settings.ini");
	Cookie = buff;
	
	if(Cookie != "")
	{
		size = GetPrivateProfileStringA("settings", "username", "", buff, buffsize, ".\\settings.ini");
		UN = buff;
		XEdit_SetText(UNText, (wchar_t *)m2w(UN).c_str());
		XEle_EnableEle(this->UNText, false);
		XEle_EnableEle(this->PWText, false);
		XEle_EnableEle(this->LgButton, false);
		XEle_EnableEle(this->ExButton, true);
		SetConsoleColor(Green);
		cout << TimeString() + "�û���Ϣ��ȡ���...\n";
	}
}

void MainForm::show()
{
	XWnd_ShowWindow(_MainForm, SW_SHOW); //��ʾ����
}

void MainForm::hide()
{
	XWnd_ShowWindow(_MainForm, SW_HIDE); 
}

BOOL MainForm::LgButton_OnClick(HELE hEle,HELE hEleEvent)
{
	try
	{
		XEle_EnableEle(LgButton, false);

		int len = XEdit_GetTextLength (UNText);
		if(len == 0) throw exception("����д�û�����");
		wchar_t *buff = new wchar_t[len + 1];
		XEdit_GetText (UNText, buff, len + 1);
		wstring wcs = buff;
		delete[] buff;
		UN = w2m(wcs);
		
		len = XEdit_GetTextLength (PWText);
		if(len == 0) throw exception("����д���룡");
		buff = new wchar_t[len + 1];
		XEdit_GetText (PWText, buff, len + 1);
		wcs = buff;
		delete[] buff;
		PW = w2m(wcs);

		//Way = XComboBox_GetSelectItem (WayCombo);

		HANDLE htr = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)Login, this, 0, 0);
		CloseHandle(htr);
	}
	catch(exception& ex)
	{
		SetConsoleColor(Red);
		cout << TimeString() + ex.what() + "\n";
		XEle_EnableEle(LgButton, true);
	}

	return 0;
}

BOOL MainForm::ExButton_OnClick(HELE hEle,HELE hEleEvent)
{
	this->Cookie = "";
	XEle_EnableEle(this->LgButton, true);
	XEle_EnableEle(this->ExButton, false);
	XEle_EnableEle(this->UNText, true);
	XEle_EnableEle(this->PWText, true);
	SetConsoleColor(Green);
	cout << TimeString() + "���˳���\n";
	return 0;
}

BOOL MainForm::StartButton_OnClick(HELE hEle, HELE hEleEvent)
{
	try
	{
		XEle_EnableEle(this->StartButton, false);
		if(this->Cookie == "") throw exception("���ȵ�¼��");
		this->Delay = XEdit_GetInt(this->DelayNum);
		this->Mode = XComboBox_GetSelectItem(this->ModeCombo);
		this->SgMode = XComboBox_GetSelectItem(this->SgModeCombo);
		this->NdStop = false;
		HANDLE htr = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)SignUp, this, 0, 0);
		CloseHandle(htr);
	}
	catch(exception& ex)
	{
		SetConsoleColor(Red);
		cout << TimeString() + ex.what() + "\n";
		XEle_EnableEle(this->StartButton, true);
	}
	return 0;
}

BOOL MainForm::StopButton_OnClick(HELE hEle, HELE hEleEvent)
{
	this->NdStop = true;
	return 0;
}

BOOL MainForm::Lk1_OnClick(HELE hEle, HELE hEleEvent)
{
	ShellExecuteA(0, "open", "http://www.flygon.net", NULL, NULL, SW_SHOW);
	return 0;
}

BOOL MainForm::Lk2_OnClick(HELE hEle, HELE hEleEvent)
{
	ShellExecuteA(0, "open", "http://www.258ch.com/forum-48-1.html", NULL, NULL, SW_SHOW);
	return 0;
}

BOOL MainForm::ModeCB_Selected(HELE hEle, HELE hEleEvent, int id)
{
	if(id == 0) XEle_EnableEle(TBText, false);
	else XEle_EnableEle(TBText, true);
	return 0;
}

BOOL MainForm::BsText_OnTextChange(HELE hEle, HELE hEleEvent)
{
	int tmp = XEdit_GetTextLength (BSText);
	if(tmp == 4)
	{
		wchar_t wbuff[5];
		XEdit_GetText (BSText, wbuff, 5);
		wstring stmp = wbuff;
		BS = w2m(stmp);
		XEdit_SetText(BSText, L"");
		XPic_SetImage(BSPic, 0);
		XEle_RedrawEle(this->BSPic, true);//<!!!>
	}
	return 0;
}

void MainForm::Login(MainForm *p)
{
	try
	{
		WizardHTTP wh;
		string poststr  = "_client_id=" + GetStampMobile(true) + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + Base64Encrypt(p->PW) + "&un=" + UrlEncoding(p->UN, CP_UTF8);
		wh.SetDefaultHeader(true);
		string retstr = wh.HTTPPost("http://c.tieba.baidu.com/c/s/login", poststr);
		int left = retstr.find("error_code\":5");
		if(left != -1)
		{
			left = retstr.find("vcode_md5") + 12;
			int right = retstr.find('\"', left);
			string vcode = retstr.substr(left, right - left);
			string picdata = wh.HTTPGetData("http://passport.baidu.com/cgi-bin/genimage?" + vcode);
			fstream fs("pic.png", ios::out | ios::binary);
			if(!fs) throw exception("��ȡͼƬʧ�ܣ�");
			for(int i = 0; i < picdata.size(); i++) fs << picdata[i];
			fs.close();
			XEle_EnableEle(p->BSText, true);
			XPic_SetImage(p->BSPic, XImage_LoadFile(L"pic.png"));
			XEle_RedrawEle(p->BSPic, true);//<!!!>
			p->BS = "";
			while(p->BS == "") Sleep(200);
			XEle_EnableEle(p->BSText, false);
			poststr = "_client_id=" + GetStampMobile(true) + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + Base64Encrypt(p->PW) + "&un=" + UrlEncoding(p->UN, CP_UTF8) + "&vcode=" + p->BS + "&vcode_md5=" + vcode;
			retstr = wh.HTTPPost("http://c.tieba.baidu.com/c/s/login", poststr);
		}	
		string err = GetMid(retstr, "code\":", ",");
		if(err != "0")
		{
			int left = retstr.find("error_msg") + 12;
			int right = retstr.find('\"', left);
			string errmsg = retstr.substr(left, right - left);
			throw exception(("��¼ʧ�ܣ�" + UnicodeDeco(errmsg)).c_str());
		}
		const regex re("BDUSS\":\".{192}");
		smatch rm;
		tr1::regex_search(retstr, rm, re);
		p->Cookie = "BDUSS=" + rm[0].str().substr(8, 192);
	    
		SetConsoleColor(Green);
		cout << TimeString() + "��¼�ɹ���\n";
     	XEle_EnableEle(p->UNText, false);
		XEle_EnableEle(p->PWText, false);
		XEle_EnableEle(p->ExButton, true);
	}
	catch(exception& ex)
	{
		SetConsoleColor(Red);
		cout << TimeString() + ex.what() + "\n";
		XEle_EnableEle(p->LgButton, true);
	}

}

void MainForm::SignUp(MainForm *p)
{
	//��ʼ������
	vector<string> list;

	try
	{
		if(!p->Mode)
			list = p->GetTBList(); //��ȡ
		else//�б�
		{
			int size = XEdit_GetTextLength(p->TBText);
			wchar_t *buff = new wchar_t[size + 1];
			buff[0] = 0;
			XEdit_GetText(p->TBText, buff, size + 1);
			string str = w2m(wstring(buff));
			delete[] buff;
			list = Split(str, "\r\n", true);
		}
		if(list.size() == 0) throw exception("�����б���ȡʧ��...");
	}
	catch(exception& ex)
	{
		SetConsoleColor(Red);
		cout << TimeString() + ex.what() + "\n";
		XEle_EnableEle(p->StartButton, true);
		return;
	}

	XEle_EnableEle(p->StopButton, true);
	SetConsoleColor(Yellow);
	cout << TimeString() + "�����б���ȡ�ɹ���\n";

	WizardHTTP wh;
	wh.SetDefaultHeader(true);
	if(p->SgMode == SGMODE_WAP) wh.SetCharset(CP_UTF8);
	wh.SetHeader("Cookie", p->Cookie);
	//wh.SetHeader("User-Agent", "Mozilla/5.0 (Linux; U; Android 2.3.4; zh-cn; W806 Build/GRJ22) AppleWebKit/530.17 (KHTML, like Gecko) FlyFlow/2.4 Version/4.0 Mobile Safari/530.17 baidubrowser/042_1.8.4.2_diordna_008_084/AIDIVN_01_4.3.2_608W/1000591a/9B673AC85965A58761CF435A48076629%7C880249110567268/1");
	for(int i = 0; i < list.size(); i++)
	{
		try
		{
			if(p->NdStop) break;
			string fid = GetFid(wh, UrlEncoding(list.at(i), CP_GBK));
			string tbs = GetTbs(wh);
			//string cid = GetStampAndroid();

			string poststr, retstr, err, cid, sign;
			int left, right;
			switch(p->SgMode)
			{
			case SGMODE_WAP:
				poststr = "http://wapp.baidu.com/f/q---07BB56A13DC4C7CB2BCFA6963C1B157B--1-1-0--/sign?tbs=" + tbs +"&fid=" + fid + "&kw=" + UrlEncoding(list.at(i), CP_UTF8);
				retstr = wh.HTTPGet(poststr);
				left = retstr.find("light\">") + 7;
				right = retstr.find('<', left);
				err = retstr.substr(left, right - left);
				if(err.find("ǩ���ɹ�") != -1)
				{
					SetConsoleColor(Green);
					cout << TimeString() + p->UN + " ��" + list.at(i) + "��ǩ���ɹ���\n";
				}
				else
				{
					left = retstr.find("light\">", left) + 7;
					right = retstr.find('<', left);
					err = retstr.substr(left, right - left);
					SetConsoleColor(Red);
					cout << TimeString() + p->UN + " ��" + list.at(i) + "��ǩ��ʧ�ܣ�" + err + "\n";
				}
				break;

			case SGMODE_CLIENT:
				cid = GetStampMobile(true);
				poststr = p->Cookie + "_client_id=" + cid + "_client_type=2_client_version=2.5.1_phone_imei=000000000000000fid=" + fid + "from=tiebakw=" + list.at(i) + "net_type=1tbs=" + tbs + "tiebaclient!!!";
				sign = MD5Encrypt(poststr, CP_UTF8);
				poststr = p->Cookie + "&_client_id=" + cid + "&_client_type=2&_client_version=2.5.1&_phone_imei=000000000000000&fid=" + fid + "&from=tieba&kw=" + UrlEncoding(list.at(i), CP_UTF8) + "&net_type=1&tbs=" + tbs + "&sign=" + sign;
				retstr = wh.HTTPPost("http://c.tieba.baidu.com/c/c/forum/sign", poststr);
				err = GetMid(retstr, "code\":\"", "\"");
				if(err == "0")
				{
					SetConsoleColor(Green);
					cout << TimeString() + p->UN + " ��" + list.at(i) + "��ǩ���ɹ���\n";
				}
				else
				{
					left = retstr.find("error_msg") + 12;
					right = retstr.find('\"', left);
					err = retstr.substr(left, right - left);
					SetConsoleColor(Red);
					cout << TimeString() + p->UN + " ��" + list.at(i) + "��ǩ��ʧ�ܣ�" + UnicodeDeco(err) + "\n";
				}
				break;

			default: throw exception("ģʽ����");
			}

			Sleep(p->Delay);
		}
		catch(exception& ex)
		{
			SetConsoleColor(Red);
			cout << TimeString() + ex.what() + "\n";
		}
	}
	SetConsoleColor(Yellow);
	cout << TimeString() + "ǩ����ɣ�\n";
	XEle_EnableEle(p->StopButton, false);
	XEle_EnableEle(p->StartButton, true);
}

BOOL MainForm::Form_OnClose(HELE hEle, HELE hEleEvent)
{
	if(this->Cookie != "")
	{
		WritePrivateProfileStringA("settings", "cookie", Cookie.c_str(), ".\\settings.ini");
		WritePrivateProfileStringA("settings", "username", UN.c_str(), ".\\settings.ini");
	}
	return 0;
}

vector<string> MainForm::GetTBList()
{
	vector<string> list;
	WizardHTTP wh;
	wh.SetDefaultHeader();
	wh.SetHeader("Cookie", this->Cookie);
	string retstr = wh.HTTPGet("http://tieba.baidu.com/f/like/mylike");
	int left = retstr.find("pn=2\">��һҳ<"),
		right = 0,
		total = 0;
	if(left == -1) total = 1;
	else
	{
		left = retstr.find("&pn=", left)+ 4;
		right = retstr.find('\"', left);
		total = stoi(retstr.substr(left,right - left));
	}
	//ȡÿһҳ����
	for(int i = 1; i <= total; i++)
	{
		retstr = wh.HTTPGet("http://tieba.baidu.com/f/like/mylike?pn=" + itos(i));
		//left = retstr.find("class=\"forum_title");
		left = 0;
		while(true)
		{
			left = retstr.find("<a href=", left);
			if(left == -1) break;
			left = retstr.find("title=\"", left);
			if(left == -1) break;
			left += 7;
			right = retstr.find('\"', left);
			if(right == -1) break;
			string tmp = retstr.substr(left, right - left);
			list.push_back(tmp);
			left = right + 1;
		}
	}
	return list;
}