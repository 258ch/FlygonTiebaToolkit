﻿Imports System.Net
Imports System.Threading
Imports System.Text
Imports System.Text.RegularExpressions
Imports 残灭III.MyFunctions
Imports 残灭III.TBOps
Imports System.IO
Imports Sunisoft.IrisSkin

Public Class Form1

    Private Skin As SkinEngine
    Private BigBar As ID
    Private SmallBar As New List(Of ID)
    Private kw_gbk As String
    Private kw_utf8 As String
    Private fid As String
    Private ForePage As Integer
    Private EndPage As Integer
    Private Delay As Integer
    Private Mode As Integer
    Private TrOper As Thread
    Private TrLog As Thread
    'Private LogWay As Integer
    Private BigBarUN As String
    Private BigBarPW As String
    Private BS As String

    Public Const DELETE As Integer = 0
    Public Const ADDELITE As Integer = 1
    Public Const REMOVEELITE As Integer = 2
    Public Const BAN As Integer = 3

    Private Sub BigBarLogin()
        Try
            Dim wc As New WizardHTTP
            wc.SetDefaultHeaderAdr()
            Dim poststr As String = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + ToBase64(BigBarPW) + "&un=" + URLEncoding(BigBarUN, Encoding.UTF8)
            Dim retstream As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            Dim left As Integer = retstream.IndexOf("error_code"":5")
            If left <> -1 Then '检查验证码
                left = retstream.IndexOf("vcode_md5", left) + 12
                Dim right As Integer = retstream.IndexOf("""", left)
                Dim vcode As String = retstream.Substring(left, right - left)
                wc.SetDefaultHeader()
                Dim postdata As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                Dim pic = Image.FromStream(New MemoryStream(postdata))
                BSPictureBox.Image = pic
                BS = ""
                BSTextBox.Enabled = True
                While BS = "" : Thread.Sleep(200) : End While
                BSTextBox.Enabled = False
                poststr = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + ToBase64(BigBarPW) + "&un=" + URLEncoding(BigBarUN, Encoding.UTF8) + "&vcode=" + BS + "&vcode_md5=" + vcode
                wc.SetDefaultHeaderAdr()
                retstream = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
            End If
            '-------------------------------------------
            Dim re As New Regex("BDUSS"":"".{192}""")
            Dim rm As Match = re.Match(retstream)
            If Not rm.Success Then
                left = retstream.IndexOf("error_msg") + 12
                Dim right As Integer = retstream.IndexOf("""", left)
                Dim errmsg As String = retstream.Substring(left, right - left)
                Throw New Exception(BigIDTextBox.Text + " 登录失败！" + UnicodeDeco(errmsg))
            End If
            Dim cookie As String = "BDUSS=" + Mid(rm.Value, 9, 192)
            BigBar = New ID With {.UN = BigBarUN, .Cookie = cookie}
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "登录成功！")
            BigIDTextBox.Enabled = False
            BigPWTextBox.Enabled = False
            ExitButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            LoginButton.Enabled = True
        End Try
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        BigBar = Nothing
        BigIDTextBox.Enabled = True
        BigPWTextBox.Enabled = True
        LoginButton.Enabled = True
        ExitButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已退出！")
    End Sub

    Public Sub DeleteSub()

        Dim i_id As Integer = 0
        Dim wc As New WizardHTTP
        Dim re As New Regex("<a href=""/p/\d+")

        For i As Integer = ForePage To EndPage
            Try '取帖子号
                Dim tid As New List(Of String)
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Cookie, "TIEBAUID=; TIEBA_USERTYPE=; Hm_lvt=; TIEBA_LOGINED_USER=; wise_device=0; close_liked_forum_tip=1; BAIDUID=:FG=1; BDUSS=; BAIDU_WISE_UID=")
                Dim retstream As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + kw_gbk + "&pn=" + Str(50 * (i - 1)))
                Dim rmc As MatchCollection = re.Matches(retstream)
                If rmc.Count = 0 Then
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + "第" + i.ToString + "页获取失败。")
                    Continue For
                End If
                For Each rm As Match In rmc
                    Dim tmp As String = Mid(rm.Value, 13, rm.Value.Length)
                    tid.Add(tmp)
                Next
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "第" + i.ToString + "页获取完毕。")
                For Each tmp As String In tid
                    Try
                        wc.Headers.Set(HttpRequestHeader.Cookie, SmallBar.Item(i_id).Cookie)
                        '取tbs
                        wc.SetDefaultHeader()
                        retstream = wc.DownloadString("http://tieba.baidu.com/dc/common/tbs")
                        Dim left As Integer = InStr(retstream, "tbs") + 6
                        Dim right As Integer = InStr(left, retstream, """")
                        Dim tbs As String = Mid(retstream, left, right - left)
                        '发送删帖请求
                        Dim poststr As String = "ie=utf-8&tbs=" + tbs + "&kw=" + kw_utf8 + "&fid=" + fid + "&tid=" + tmp
                        wc.SetDefaultHeader()
                        retstream = wc.UploadString("http://tieba.baidu.com/f/commit/thread/delete", poststr)
                        left = InStr(retstream, """:") + 2
                        right = InStr(left, retstream, ",")
                        Dim info As String = Mid(retstream, left, right - left)
                        If info = "0" Then
                            Console.ForegroundColor = ConsoleColor.Green
                            Console.WriteLine(Time() + SmallBar(i_id).UN + " " + tmp + " 删除成功！")
                        Else
                            Console.ForegroundColor = ConsoleColor.Red
                            Console.WriteLine(Time() + SmallBar(i_id).UN + " " + tmp + " 删除失败！错误信息：" + info)
                        End If
                        If i_id = SmallBar.Count - 1 Then i_id = 0 Else i_id += 1
                        Thread.Sleep(Delay)
                    Catch ex As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + ex.Message)
                    End Try
                Next
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        TrEnd()
    End Sub

    Public Sub EliteSub()

        Dim re As New Regex("<a href=""/p/\d+")
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, BigBar.Cookie)

        For i As Integer = ForePage To EndPage
            Try '取帖子号
                Dim tid As New List(Of String)
                wc.SetDefaultHeader()
                Dim retstream As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + kw_gbk + "&pn=" + Str(50 * (i - 1)))
                Dim rmc As MatchCollection = re.Matches(retstream)
                If rmc.Count = 0 Then
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + "第" + i.ToString + "页获取失败。")
                    Continue For
                End If
                For Each rm As Match In rmc
                    Dim tmp As String = Mid(rm.Value, 13, rm.Value.Length)
                    tid.Add(tmp)
                Next
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "第" + i.ToString + "页获取完毕。")
                For Each tmp As String In tid
                    Try '取tbs
                        wc.SetDefaultHeader()
                        retstream = wc.DownloadString("http://tieba.baidu.com/dc/common/tbs")
                        Dim left As Integer = InStr(retstream, "tbs") + 6
                        Dim right As Integer = InStr(left, retstream, """")
                        Dim tbs As String = Mid(retstream, left, right - left)
                        '发送加精或撤精请求
                        wc.SetDefaultHeader()
                        If Mode = ADDELITE Then
                            Dim poststr As String = "ie=utf-8&tbs=" + tbs + "&kw=" + kw_utf8 + "&fid=" + fid + "&tid=" + tmp + "&cid=0"
                            retstream = wc.UploadString("http://tieba.baidu.com/f/commit/thread/good/add", poststr)
                        Else
                            Dim poststr As String = "ie=utf-8&tbs=" + tbs + "&kw=" + kw_utf8 + "&fid=" + fid + "&tid=" + tmp
                            retstream = wc.UploadString("http://tieba.baidu.com/f/commit/thread/good/cancel", poststr)
                        End If
                        left = InStr(retstream, """:") + 2
                        right = InStr(left, retstream, ",")
                        Dim info As String = Mid(retstream, left, right - left)
                        If info = "0" Then
                            Console.ForegroundColor = ConsoleColor.Green
                            Console.WriteLine(Time() + tmp + " 操作成功！")
                        Else
                            Console.ForegroundColor = ConsoleColor.Red
                            Console.WriteLine(Time() + tmp + " 操作失败！错误信息：" + info)
                        End If
                        Thread.Sleep(Delay)
                    Catch ex As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + ex.Message)
                    End Try
                Next
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        TrEnd()
    End Sub

    Public Sub BanSub()

        Dim re As New Regex("username="".{1,14}"" ")
        Dim wc As New WizardHTTP
        wc.Headers.Set(HttpRequestHeader.Cookie, BigBar.Cookie)

        For i As Integer = ForePage To EndPage
            Try '取会员ID
                Dim banid As New List(Of String)
                wc.SetDefaultHeader()
                Dim retstream As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + kw_gbk + "&pn=" + i.ToString)
                Dim rmc As MatchCollection = re.Matches(retstream)
                For Each rm As Match In rmc
                    Try
                        Dim usn As String = Mid(rm.Value, 11, rm.Value.Length - 12)
                        '取uid
                        wc.SetDefaultHeader()
                        retstream = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoding(usn, Encoding.Default))
                        Dim Left As Integer = InStr(retstream, "{""id""") + 6
                        Dim right As Integer = InStr(Left, retstream, ",")
                        Dim uid As String = Mid(retstream, Left, right - Left)
                        '取tbs
                        wc.SetDefaultHeader()
                        retstream = wc.DownloadString("http://tieba.baidu.com/dc/common/tbs")
                        Left = InStr(retstream, "tbs") + 6
                        right = InStr(Left, retstream, """")
                        Dim tbs As String = Mid(retstream, Left, right - Left)
                        '发送封禁请求
                        wc.SetDefaultHeader()
                        Dim poststr As String = "ie=gbk&tbs=" + tbs + "&uid=" + uid + "&usn=" + usn + "&fid=" + fid + "&fname=" + kw_utf8
                        retstream = wc.UploadString("http://tieba.baidu.com/f/like/commit/black/add", poststr)
                        Left = InStr(retstream, """:") + 2
                        right = InStr(Left, retstream, ",")
                        Dim info As String = Mid(retstream, Left, right - Left)
                        If info = "0" Then
                            Console.ForegroundColor = ConsoleColor.Green
                            Console.WriteLine(Time() + usn + " " + uid + " 封禁成功！")
                        Else
                            Console.ForegroundColor = ConsoleColor.Red
                            Console.WriteLine(Time() + usn + " " + uid + " 封禁失败！错误信息：" + info)
                        End If
                        Thread.Sleep(Delay)
                    Catch ex As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(Time() + ex.Message)
                    End Try
                Next
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        TrEnd()
    End Sub

    Private Sub TrEnd()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已完成！")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub LoginButtonSmall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginSmallBarButton.Click
        If LoginSmallBarButton.Text = "登录" Then
            Try
                If SmallBarTextBox.TextLength = 0 Then Throw New Exception("请填写待登陆账号！")
                TrLog = New Thread(AddressOf SmallBarLogin)
                TrLog.Start()
                BSTextBox.Enabled = True
                LoginSmallBarButton.Text = "停止"
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Else
            TrLog.Abort()
            BSPictureBox.Image = Nothing
            BSTextBox.Text = ""
            BSTextBox.Enabled = False
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "登录完毕！")
            LoginSmallBarButton.Text = "登录"
        End If
    End Sub

    Public Sub SmallBarLogin()
        Dim wc As New WizardHTTP
        Dim re As New Regex("BDUSS"":"".{192}""")
        For Each x As String In SmallBarTextBox.Lines
            Try
                Dim tmp As String() = Split(x, ":")
                If UBound(tmp) < 1 Then Continue For

                wc.SetDefaultHeaderAdr()
                Dim poststr As String = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + ToBase64(tmp(1)) + "&un=" + URLEncoding(tmp(0), Encoding.UTF8)
                Dim retstream As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                '检查验证码
                Dim left As Integer = retstream.IndexOf("error_code"":5")
                If left <> -1 Then
                    left = retstream.IndexOf("vcode_md5", left) + 12
                    Dim right As Integer = retstream.IndexOf("""", left)
                    Dim vcode As String = retstream.Substring(left, right - left)
                    wc.SetDefaultHeader()
                    Dim postdata As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                    Dim pic = Image.FromStream(New MemoryStream(postdata))
                    BSPictureBox.Image = pic
                    BS = ""
                    While BS = "" : Thread.Sleep(200) : End While
                    poststr = "_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(tmp(1))) + "&un=" + URLEncoding(tmp(0), Encoding.UTF8) + "&vcode=" + BS + "&vcode_md5=" + vcode
                    wc.SetDefaultHeaderAdr()
                    retstream = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                End If
                '-------------------------------------------
                Dim rm As Match = re.Match(retstream)
                If Not rm.Success Then
                    left = retstream.IndexOf("error_msg") + 12
                    Dim right As Integer = retstream.IndexOf("""", left)
                    Dim errmsg As String = retstream.Substring(left, right - left)
                    Throw New Exception(tmp(0) + " 登录失败！" + UnicodeDeco(errmsg))
                End If
                Dim cookie As String = "BDUSS=" + Mid(rm.Value, 9, 192)
                SmallBar.Add(New ID With {.UN = tmp(0), .Cookie = cookie})
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + tmp(0) + " 登录成功！")
                LoggedListView.Items.Add(tmp(0))
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        BSPictureBox.Image = Nothing
        BSTextBox.Text = ""
        BSTextBox.Enabled = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "登录完毕！")
        LoginSmallBarButton.Text = "登录"
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        If MessageBox.Show("的确要清空么？", "", MessageBoxButtons.OKCancel) = Windows.Forms.DialogResult.OK Then
            LoggedListView.Items.Clear()
            SmallBar.Clear()
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "已清除。")
        End If
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If TBTextBox.Text = "" Then Throw New Exception("请输入目标！")
            Dim tb As String = TBTextBox.Text
            kw_gbk = URLEncoding(tb, Encoding.Default)
            kw_utf8 = URLEncoding(tb, Encoding.UTF8)
            ForePage = ForeNumeric.Value
            EndPage = EndNumeric.Value
            Delay = DelayNumeric.Value
            Mode = OpComboBox.SelectedIndex
            Dim wc As New WizardHTTP
            fid = GetFid(wc, kw_gbk)

            Dim func As ThreadStart
            Select Case Mode
                Case DELETE
                    If SmallBar.Count = 0 Then Throw New Exception("请先添加小吧！")
                    func = AddressOf DeleteSub
                    Exit Select
                Case ADDELITE
                    If BigBar.Cookie = "" Then Throw New Exception("请登录大吧！")
                    func = AddressOf EliteSub
                    Exit Select
                Case REMOVEELITE
                    If BigBar.Cookie = "" Then Throw New Exception("请登录大吧！")
                    func = AddressOf EliteSub
                    Exit Select
                Case BAN
                    If BigBar.Cookie = "" Then Throw New Exception("请登录大吧！")
                    func = AddressOf BanSub
                    Exit Select
                Case Else
                    Throw New Exception("未知错误！")
                    Exit Select
            End Select
            TrOper = New Thread(func)
            TrOper.Start()
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        TrOper.Abort()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已完成！")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        LogWayComboBox.SelectedIndex = 0
        OpComboBox.SelectedIndex = 0
        Skin = New SkinEngine(Me, New MemoryStream(My.Resources.Page))
    End Sub

    Private Sub LoginButton_Click(sender As System.Object, e As System.EventArgs) Handles LoginButton.Click
        Try
            LoginButton.Enabled = False
            BigBarUN = BigIDTextBox.Text
            BigBarPW = BigPWTextBox.Text
            If BigBarUN = "" Or BigBarPW = "" Then Throw New Exception("请填写用户名和密码！")
            'LogWay = LogWayComboBox.SelectedIndex
            Dim tr As New Thread(AddressOf BigBarLogin)
            tr.Start()
        Catch ex As Exception
            LoginButton.Enabled = True
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
        End Try
    End Sub

    Private Sub SaveData()
        Dim sw As New StreamWriter(Directory.GetCurrentDirectory() + "\small.dat", False, Encoding.Default)
        For i As Integer = 0 To SmallBar.Count - 1
            sw.WriteLine(SmallBar(i).UN + ":" + SmallBar(i).Cookie)
        Next
        sw.Close()
        sw = New StreamWriter(Directory.GetCurrentDirectory() + "\big.dat", False, Encoding.Default)
        sw.Write(BigBar.UN + vbCrLf + BigBar.Cookie)
        sw.Close()
    End Sub

    Private Sub LoadData()
        If File.Exists(Directory.GetCurrentDirectory() + "\small.dat") Then
            Dim tmp As String() = File.ReadAllLines(Directory.GetCurrentDirectory() + "\small.dat", Encoding.Default)
            For Each x As String In tmp
                Dim tmp2 As String() = Split(x, ":")
                If tmp2.Length < 2 Then Continue For
                LoggedListView.Items.Add(tmp2(0))
                SmallBar.Add(New ID With {.UN = tmp2(0), .Cookie = tmp2(1)})
            Next
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(Time() + "文件读取完毕！")
        End If
        If File.Exists(Directory.GetCurrentDirectory() + "\big.dat") Then
            Dim tmp As String() = File.ReadAllLines(Directory.GetCurrentDirectory() + "\big.dat", Encoding.Default)
            If tmp.Length > 1 Then
                BigBar = New ID With {.UN = tmp(0), .Cookie = tmp(1)}
                BigIDTextBox.Text = tmp(0)
                BigIDTextBox.Enabled = False
                BigPWTextBox.Enabled = False
                LoginButton.Enabled = False
                ExitButton.Enabled = True
            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Private Sub Form1_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        SaveData()
        End
    End Sub

    Private Sub BSTextBox_TextChanged(sender As System.Object, e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.TextLength = 4 Then
            BS = BSTextBox.Text
            BSTextBox.Clear()
            BSPictureBox.Image = Nothing
        End If
    End Sub
End Class
