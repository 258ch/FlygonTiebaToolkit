﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BSTextBox = New System.Windows.Forms.TextBox()
        Me.LoggedListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.BSPictureBox = New System.Windows.Forms.PictureBox()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.LoginSmallBarButton = New System.Windows.Forms.Button()
        Me.SmallBarTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LogWayComboBox = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.LoginButton = New System.Windows.Forms.Button()
        Me.BigPWTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BigIDTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ForeNumeric = New System.Windows.Forms.NumericUpDown()
        Me.EndNumeric = New System.Windows.Forms.NumericUpDown()
        Me.OpComboBox = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TBTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.ForeNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EndNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BSTextBox)
        Me.GroupBox2.Controls.Add(Me.LoggedListView)
        Me.GroupBox2.Controls.Add(Me.BSPictureBox)
        Me.GroupBox2.Controls.Add(Me.ClearButton)
        Me.GroupBox2.Controls.Add(Me.LoginSmallBarButton)
        Me.GroupBox2.Controls.Add(Me.SmallBarTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(322, 317)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "小吧登录"
        '
        'BSTextBox
        '
        Me.BSTextBox.Enabled = False
        Me.BSTextBox.Location = New System.Drawing.Point(162, 230)
        Me.BSTextBox.Name = "BSTextBox"
        Me.BSTextBox.Size = New System.Drawing.Size(154, 21)
        Me.BSTextBox.TabIndex = 5
        '
        'LoggedListView
        '
        Me.LoggedListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LoggedListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.LoggedListView.FullRowSelect = True
        Me.LoggedListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.LoggedListView.Location = New System.Drawing.Point(6, 20)
        Me.LoggedListView.MultiSelect = False
        Me.LoggedListView.Name = "LoggedListView"
        Me.LoggedListView.Size = New System.Drawing.Size(150, 289)
        Me.LoggedListView.TabIndex = 5
        Me.LoggedListView.UseCompatibleStateImageBehavior = False
        Me.LoggedListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 140
        '
        'BSPictureBox
        '
        Me.BSPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox.Location = New System.Drawing.Point(162, 176)
        Me.BSPictureBox.Name = "BSPictureBox"
        Me.BSPictureBox.Size = New System.Drawing.Size(154, 45)
        Me.BSPictureBox.TabIndex = 4
        Me.BSPictureBox.TabStop = False
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(162, 286)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(154, 23)
        Me.ClearButton.TabIndex = 4
        Me.ClearButton.Text = "清除"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'LoginSmallBarButton
        '
        Me.LoginSmallBarButton.Location = New System.Drawing.Point(162, 257)
        Me.LoginSmallBarButton.Name = "LoginSmallBarButton"
        Me.LoginSmallBarButton.Size = New System.Drawing.Size(154, 23)
        Me.LoginSmallBarButton.TabIndex = 2
        Me.LoginSmallBarButton.Text = "登录"
        Me.LoginSmallBarButton.UseVisualStyleBackColor = True
        '
        'SmallBarTextBox
        '
        Me.SmallBarTextBox.Location = New System.Drawing.Point(162, 20)
        Me.SmallBarTextBox.Multiline = True
        Me.SmallBarTextBox.Name = "SmallBarTextBox"
        Me.SmallBarTextBox.Size = New System.Drawing.Size(154, 150)
        Me.SmallBarTextBox.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LogWayComboBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.ExitButton)
        Me.GroupBox1.Controls.Add(Me.LoginButton)
        Me.GroupBox1.Controls.Add(Me.BigPWTextBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.BigIDTextBox)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(340, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(185, 145)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "大吧登录"
        '
        'LogWayComboBox
        '
        Me.LogWayComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LogWayComboBox.Enabled = False
        Me.LogWayComboBox.FormattingEnabled = True
        Me.LogWayComboBox.Items.AddRange(New Object() {"client"})
        Me.LogWayComboBox.Location = New System.Drawing.Point(78, 79)
        Me.LogWayComboBox.Name = "LogWayComboBox"
        Me.LogWayComboBox.Size = New System.Drawing.Size(100, 20)
        Me.LogWayComboBox.TabIndex = 69
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 68
        Me.Label3.Text = "方式"
        '
        'ExitButton
        '
        Me.ExitButton.Enabled = False
        Me.ExitButton.Location = New System.Drawing.Point(103, 105)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 7
        Me.ExitButton.Text = "退出"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'LoginButton
        '
        Me.LoginButton.Location = New System.Drawing.Point(8, 105)
        Me.LoginButton.Name = "LoginButton"
        Me.LoginButton.Size = New System.Drawing.Size(75, 23)
        Me.LoginButton.TabIndex = 6
        Me.LoginButton.Text = "登录"
        Me.LoginButton.UseVisualStyleBackColor = True
        '
        'BigPWTextBox
        '
        Me.BigPWTextBox.Location = New System.Drawing.Point(78, 52)
        Me.BigPWTextBox.MaxLength = 16
        Me.BigPWTextBox.Name = "BigPWTextBox"
        Me.BigPWTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.BigPWTextBox.Size = New System.Drawing.Size(100, 21)
        Me.BigPWTextBox.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "密码"
        '
        'BigIDTextBox
        '
        Me.BigIDTextBox.Location = New System.Drawing.Point(78, 25)
        Me.BigIDTextBox.MaxLength = 14
        Me.BigIDTextBox.Name = "BigIDTextBox"
        Me.BigIDTextBox.Size = New System.Drawing.Size(100, 21)
        Me.BigIDTextBox.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "用户名"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ForeNumeric)
        Me.GroupBox4.Controls.Add(Me.EndNumeric)
        Me.GroupBox4.Controls.Add(Me.OpComboBox)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.StopButton)
        Me.GroupBox4.Controls.Add(Me.StartButton)
        Me.GroupBox4.Controls.Add(Me.DelayNumeric)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.TBTextBox)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Location = New System.Drawing.Point(340, 163)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(185, 166)
        Me.GroupBox4.TabIndex = 63
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "控制"
        '
        'ForeNumeric
        '
        Me.ForeNumeric.Location = New System.Drawing.Point(78, 77)
        Me.ForeNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.ForeNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ForeNumeric.Name = "ForeNumeric"
        Me.ForeNumeric.Size = New System.Drawing.Size(42, 21)
        Me.ForeNumeric.TabIndex = 69
        Me.ForeNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'EndNumeric
        '
        Me.EndNumeric.Location = New System.Drawing.Point(137, 77)
        Me.EndNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.EndNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.EndNumeric.Name = "EndNumeric"
        Me.EndNumeric.Size = New System.Drawing.Size(42, 21)
        Me.EndNumeric.TabIndex = 68
        Me.EndNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'OpComboBox
        '
        Me.OpComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OpComboBox.FormattingEnabled = True
        Me.OpComboBox.Items.AddRange(New Object() {"删帖", "加精", "撤精", "封禁"})
        Me.OpComboBox.Location = New System.Drawing.Point(78, 51)
        Me.OpComboBox.Name = "OpComboBox"
        Me.OpComboBox.Size = New System.Drawing.Size(100, 20)
        Me.OpComboBox.TabIndex = 67
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 54)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 12)
        Me.Label12.TabIndex = 64
        Me.Label12.Text = "操作"
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(103, 133)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(75, 23)
        Me.StopButton.TabIndex = 63
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(8, 133)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(75, 23)
        Me.StartButton.TabIndex = 62
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(78, 106)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(100, 21)
        Me.DelayNumeric.TabIndex = 61
        Me.DelayNumeric.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 108)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 12)
        Me.Label9.TabIndex = 60
        Me.Label9.Text = "间隔(ms)"
        '
        'TBTextBox
        '
        Me.TBTextBox.Location = New System.Drawing.Point(78, 22)
        Me.TBTextBox.Name = "TBTextBox"
        Me.TBTextBox.Size = New System.Drawing.Size(100, 21)
        Me.TBTextBox.TabIndex = 56
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 25)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(53, 12)
        Me.Label11.TabIndex = 55
        Me.Label11.Text = "目标贴吧"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 82)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(125, 12)
        Me.Label10.TabIndex = 57
        Me.Label10.Text = "页数               -"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(538, 341)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "残灭III·暗黑苍穹 - 飞龙"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.ForeNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EndNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents SmallBarTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents LoginButton As System.Windows.Forms.Button
    Friend WithEvents BigPWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BigIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents LoginSmallBarButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents OpComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TBTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LogWayComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LoggedListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents BSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BSPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ForeNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents EndNumeric As System.Windows.Forms.NumericUpDown

End Class
