﻿Imports System.Threading
Imports SkinSharp

Public Class Form1

    Private WorkTr As Thread
    Private Skin As SkinH_Net

    Private Delegate Sub Func_v_v()

    Private Sub LogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogButton.Click
        WebBrowser1.Url = New Uri("https://passport.baidu.com/v2/?login")
    End Sub

    Private Sub PlButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlButton.Click
        WebBrowser1.Url = New Uri("http://tieba.baidu.com/cuseraudit/browser")
    End Sub

    Private Sub RefButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefButton.Click
        WebBrowser1.Refresh()
    End Sub

    Private Sub SubButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubButton.Click
        Submit()
    End Sub

    Private Sub AllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllButton.Click
        SelectAll()
    End Sub

    Private Sub SelectAll()
        Dim i As Integer = 0
        While True
            Dim tmp As HtmlElementCollection = WebBrowser1.Document.All.GetElementsByName("results[" + i.ToString() + "][judge]")
            If tmp.Count = 0 Then Exit While
            tmp(0).InvokeMember("click")
            i += 1
        End While
    End Sub

    Private Sub Submit()
        For Each x As HtmlElement In WebBrowser1.Document.All
            If x.InnerHtml = "提交本页" Then
                x.InvokeMember("click")
                Exit For
            End If
        Next
    End Sub

    Private Sub AuthButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AuthButton.Click
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        WorkTr = New Thread(AddressOf DoWork)
        WorkTr.Start(DelayNumeric.Value * 1000)
        StartButton.Enabled = False
        StopButton.Enabled = True
        EnableHM(False)
    End Sub

    Private Sub DoWork(ByVal delay As Integer)
        While True
            Me.Invoke(New Func_v_v(AddressOf SelectAll))
            Me.Invoke(New Func_v_v(AddressOf Submit))
            Thread.Sleep(delay)
        End While
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        WorkTr.Abort()
        StartButton.Enabled = True
        StopButton.Enabled = False
        EnableHM(True)
    End Sub

    Private Sub EnableHM(ByVal b As Boolean)
        AllButton.Enabled = b
        SubButton.Enabled = b
        RefButton.Enabled = b
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        Skin = New SkinH_Net
        Skin.AttachRes(My.Resources.Aero, My.Resources.Aero.Length, "", 0, 0, 0)
        Skin.SetAero(1)
    End Sub
End Class
