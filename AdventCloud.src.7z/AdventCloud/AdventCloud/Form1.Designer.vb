﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.LogButton = New System.Windows.Forms.Button()
        Me.PlButton = New System.Windows.Forms.Button()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.AllButton = New System.Windows.Forms.Button()
        Me.SubButton = New System.Windows.Forms.Button()
        Me.RefButton = New System.Windows.Forms.Button()
        Me.AuthButton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 0)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScriptErrorsSuppressed = True
        Me.WebBrowser1.Size = New System.Drawing.Size(1041, 482)
        Me.WebBrowser1.TabIndex = 0
        Me.WebBrowser1.Url = New System.Uri("http://www.258ch.com/forum.php", System.UriKind.Absolute)
        '
        'LogButton
        '
        Me.LogButton.Location = New System.Drawing.Point(23, 502)
        Me.LogButton.Name = "LogButton"
        Me.LogButton.Size = New System.Drawing.Size(75, 23)
        Me.LogButton.TabIndex = 1
        Me.LogButton.Text = "贴吧登录"
        Me.LogButton.UseVisualStyleBackColor = True
        '
        'PlButton
        '
        Me.PlButton.Location = New System.Drawing.Point(126, 502)
        Me.PlButton.Name = "PlButton"
        Me.PlButton.Size = New System.Drawing.Size(75, 23)
        Me.PlButton.TabIndex = 2
        Me.PlButton.Text = "标注平台"
        Me.PlButton.UseVisualStyleBackColor = True
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(233, 502)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(75, 23)
        Me.StartButton.TabIndex = 3
        Me.StartButton.Text = "开始自动"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(341, 502)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(75, 23)
        Me.StopButton.TabIndex = 4
        Me.StopButton.Text = "停止自动"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(439, 507)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 12)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "间隔(s)"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(492, 502)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(55, 21)
        Me.DelayNumeric.TabIndex = 6
        Me.DelayNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'AllButton
        '
        Me.AllButton.Location = New System.Drawing.Point(751, 502)
        Me.AllButton.Name = "AllButton"
        Me.AllButton.Size = New System.Drawing.Size(75, 23)
        Me.AllButton.TabIndex = 7
        Me.AllButton.Text = "全部选择"
        Me.AllButton.UseVisualStyleBackColor = True
        '
        'SubButton
        '
        Me.SubButton.Location = New System.Drawing.Point(849, 502)
        Me.SubButton.Name = "SubButton"
        Me.SubButton.Size = New System.Drawing.Size(75, 23)
        Me.SubButton.TabIndex = 8
        Me.SubButton.Text = "提交一次"
        Me.SubButton.UseVisualStyleBackColor = True
        '
        'RefButton
        '
        Me.RefButton.Location = New System.Drawing.Point(945, 502)
        Me.RefButton.Name = "RefButton"
        Me.RefButton.Size = New System.Drawing.Size(75, 23)
        Me.RefButton.TabIndex = 9
        Me.RefButton.Text = "刷新"
        Me.RefButton.UseVisualStyleBackColor = True
        '
        'AuthButton
        '
        Me.AuthButton.Location = New System.Drawing.Point(568, 502)
        Me.AuthButton.Name = "AuthButton"
        Me.AuthButton.Size = New System.Drawing.Size(75, 23)
        Me.AuthButton.TabIndex = 10
        Me.AuthButton.Text = "联系作者"
        Me.AuthButton.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(681, 507)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "手动区："
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1041, 546)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.AuthButton)
        Me.Controls.Add(Me.RefButton)
        Me.Controls.Add(Me.SubButton)
        Me.Controls.Add(Me.AllButton)
        Me.Controls.Add(Me.DelayNumeric)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.PlButton)
        Me.Controls.Add(Me.LogButton)
        Me.Controls.Add(Me.WebBrowser1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "云归·百度贴吧核心用户自动标注机 - 飞龙"
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents LogButton As System.Windows.Forms.Button
    Friend WithEvents PlButton As System.Windows.Forms.Button
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents AllButton As System.Windows.Forms.Button
    Friend WithEvents SubButton As System.Windows.Forms.Button
    Friend WithEvents RefButton As System.Windows.Forms.Button
    Friend WithEvents AuthButton As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
