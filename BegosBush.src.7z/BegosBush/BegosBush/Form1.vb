﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Imports BegosBush.Utility
Imports BegosBush.TBOps
Imports SkinSharp

Public Class Form1

    Private Skin As SkinH_Net

    Private id_ID As String
    Private id_Page As Integer
    Private kw_TB As String
    Private kw_KW As String
    Private kw_Page As Integer
    Private Bawu_TB As String

    Private get_TB As String
    Private get_ID As String
    Private get_StartPage As Integer
    Private get_EndPage As Integer
    Private get_List As Integer
    Private get_NdLv3 As Boolean
    Private get_Fdir As String
    Private get_Sdir As String
    Private get_Tr As Thread
    Private get_TaskRunning As Boolean = False

    Private query_ToTest(-1) As String
    Private query_NdStop As Boolean

    Private Const GET_MEMBER As Integer = 0
    Private Const GET_CONCERN As Integer = 1
    Private Const GET_FANS As Integer = 2
    Private Const GET_BAWU As Integer = 3
    Private Const GET_TID As Integer = 4

    Private Sub id_Sniff()
        Try
            qid_ListView.Items.Clear()
            Dim wc As New WizardHTTP
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/search/ures?ie=utf-8&un=" + URLEncoding(id_ID, Encoding.UTF8) + "&rn=30&sm=1&pn=" + ID_Page.ToString())
            Dim left As Integer = 0,
                right As Integer = 0

            While True
                left = retstr.IndexOf("/p/", right)
                If left = -1 Then Exit While
                left += 3
                right = retstr.IndexOf("?", left)
                If right = -1 Then Exit While
                Dim tid As String = retstr.Substring(left, right - left) 'index 0

                left = retstr.IndexOf("_blank", right)
                If left = -1 Then Exit While
                left += 9
                right = retstr.IndexOf("</a>", left)
                If right = -1 Then Exit While
                Dim title As String = retstr.Substring(left, right - left) 'index 2
                title = title.Replace("<em>", "")
                title = title.Replace("</em>", "")

                'content
                left = retstr.IndexOf("violet", right)
                If left = -1 Then Exit While
                left += 8
                right = retstr.IndexOf("</font>", left)
                If right = -1 Then Exit While
                Dim tb As String = retstr.Substring(left, right - left) ' index 1

                'ID
                left = retstr.IndexOf("green", right)
                If left = -1 Then Exit While
                left += 14
                right = retstr.IndexOf("</font>", left)
                If right = -1 Then Exit While
                Dim reply As String = retstr.Substring(left, right - left) ' index 3

                Dim item As New ListViewItem(New String() {tid, tb, title, reply})
                qid_ListView.Items.Add(item)
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        id_SniffButton.Enabled = True
    End Sub

    Private Sub kw_Sniff()
        Try
            kw_ListView.Items.Clear()
            Dim wc As New WizardHTTP
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/search/res?kw=" + URLEncoding(kw_TB, Encoding.Default) + "&qw=" + URLEncoding(kw_KW, Encoding.Default) + "&rn=30&sm=1&pn=" + kw_Page.ToString())
            Dim left As Integer = 0,
                right As Integer = 0

            While True
                left = retstr.IndexOf("/p/", right)
                If left = -1 Then Exit While
                left += 3
                right = retstr.IndexOf("?", left)
                If right = -1 Then Exit While
                Dim tid As String = retstr.Substring(left, right - left) 'index 0

                left = retstr.IndexOf("_blank", right)
                If left = -1 Then Exit While
                left += 9
                right = retstr.IndexOf("</a>", left)
                If right = -1 Then Exit While
                Dim title As String = retstr.Substring(left, right - left) 'index 1
                title = title.Replace("<em>", "")
                title = title.Replace("</em>", "")

                left = retstr.IndexOf("p_content", right)
                If left = -1 Then Exit While
                left += 11
                right = retstr.IndexOf("</div>", left)
                If right = -1 Then Exit While
                Dim content As String = retstr.Substring(left, right - left) 'index 2
                content = content.Replace("<em>", "")
                content = content.Replace("</em>", "")

                left = retstr.IndexOf("作者：", right)
                left = retstr.IndexOf("violet", left)
                If left = -1 Then Exit While
                left += 8
                right = retstr.IndexOf("</font>", left)
                If right = -1 Then Exit While
                Dim author As String = retstr.Substring(left, right - left) 'index 3


                left = retstr.IndexOf("green", right)
                If left = -1 Then Exit While
                left += 14
                right = retstr.IndexOf("</font>", left)
                If right = -1 Then Exit While
                Dim reply As String = retstr.Substring(left, right - left) 'index 4

                Dim item As New ListViewItem(New String() {tid, title, content, author, reply})
                kw_ListView.Items.Add(item)
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        kw_SniffButton.Enabled = True
    End Sub

    Private Sub bawu_Sniff()
        Try
            bawu_TextBox.Clear()
            Dim wc As New WizardHTTP()
            wc.SetDefaultHeader()
            wc.Encoding = Encoding.UTF8
            Dim retstr As String = wc.DownloadString("http://wapp.baidu.com/f/m?tn=bdBIW&word=" + URLEncoding(Bawu_TB, Encoding.Default))
            Dim bawu As New List(Of String)
            Dim onlinenum As New Integer
            Dim left As Integer = retstr.IndexOf("吧主"),
                right As Integer = retstr.IndexOf("小吧主"),
                cutdown As Integer = retstr.IndexOf("主题")
            If left = -1 Or right = -1 Or cutdown = -1 Then
                Throw New Exception("贴吧信息获取失败！")
            End If
            Dim bz As String = retstr.Substring(left, right - left)
            Dim littlebz As String = retstr.Substring(right, cutdown - right)

            '取吧主  
            left = 0
            right = 0
            While True
                left = bz.IndexOf(""">", left) + 2
                If left = 1 Then Exit While
                right = bz.IndexOf("</a>", left)
                If right = -1 Then Exit While
                bawu.Add(bz.Substring(left, right - left))
                left = right
            End While

            '取小吧主
            left = 0
            right = 0
            While True
                left = littlebz.IndexOf(""">", left) + 2
                If left = 1 Then Exit While
                right = littlebz.IndexOf("</a>", left)
                If right = -1 Then Exit While
                bawu.Add(littlebz.Substring(left, right - left))
                left = right
            End While
            bawu_TextBox.AppendText("吧务获取完毕..." + vbCrLf + vbCrLf)

            If bawu.Count = 0 Then
                bawu_TextBox.AppendText("检测完毕，该吧没有吧主！" + vbCrLf + vbCrLf)
            Else
                For Each x As String In bawu
                    Try
                        wc.SetDefaultHeader()
                        Dim ret2 As String = wc.DownloadString("http://www.baidu.com/p/" + URLEncoding(x, Encoding.Default))
                        If ret2.IndexOf("offline") = -1 Then
                            bawu_TextBox.AppendText(x + "：在线" + vbCrLf + vbCrLf)
                            onlinenum += 1
                        Else
                            bawu_TextBox.AppendText(x + "：离线" + vbCrLf + vbCrLf)
                        End If
                    Catch ex As Exception
                        bawu_TextBox.AppendText(x + "：获取失败" + vbCrLf + vbCrLf)
                    End Try
                Next
                bawu_TextBox.AppendText("吧务共计 " + bawu.Count.ToString() + " 个，在线 " + onlinenum.ToString() + " 个。" + vbCrLf + vbCrLf)
            End If

            Dim fid As String = GetFid(wc, URLEncoding(Bawu_TB, Encoding.Default))
            wc.SetDefaultHeader()
            wc.Encoding = Encoding.Default
            retstr = wc.DownloadString("http://tieba.baidu.com/f/user/json_needvcode?rs1=0&rs10=1&lm=" + fid + "&word=" + URLEncoding(Bawu_TB, Encoding.UTF8))
            Dim open As String = GetMid(retstr, "open_shenshou"":", ",")
            If open = "0" Then
                bawu_TextBox.AppendText("该吧没有开启超级验证码！")
            Else
                Dim lv As String = GetMid(retstr, "shenshou_lv"":", ",")
                bawu_TextBox.AppendText("该吧已开启超级验证码，等级：" + lv)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        bawu_SniffButton.Enabled = True
    End Sub

    Private Sub ToolStripStatusLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel1.Click
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub ToolStripStatusLabel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel2.Click
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub id_SniffButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles id_SniffButton.Click
        Try
            id_SniffButton.Enabled = False
            id_ID = id_IDTextBox.Text
            If id_ID = "" Then Throw New Exception("请填写目标ID！")
            ID_Page = id_PageNumeric.Value
            Dim tr As New Thread(AddressOf id_Sniff)
            tr.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            id_SniffButton.Enabled = True
        End Try
    End Sub

    Private Sub kw_SniffButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles kw_SniffButton.Click
        Try
            kw_SniffButton.Enabled = False
            kw_KW = kw_KWTextBox.Text
            If kw_KW = "" Then Throw New Exception("请填写关键词！")
            kw_TB = kw_TBTextBox.Text
            kw_Page = kw_PageNumeric.Value
            Dim tr As New Thread(AddressOf kw_Sniff)
            tr.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            kw_SniffButton.Enabled = True
        End Try
    End Sub

    Private Sub bawu_SniffButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bawu_SniffButton.Click
        Try
            bawu_SniffButton.Enabled = False
            Bawu_TB = bawu_TBtextbox.Text
            If Bawu_TB = "" Then Throw New Exception("请填写目标贴吧！")
            Dim tr As New Thread(AddressOf bawu_Sniff)
            tr.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            bawu_SniffButton.Enabled = True
        End Try
    End Sub

    Private Sub id_ListView_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles qid_ListView.DoubleClick
        Dim tid As String = qid_ListView.SelectedItems(0).SubItems(0).Text
        Process.Start("http://tieba.baidu.com/p/" + tid)
    End Sub

    Private Sub kw_ListView_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles kw_ListView.DoubleClick
        Dim tid As String = kw_ListView.SelectedItems(0).SubItems(0).Text
        Process.Start("http://tieba.baidu.com/p/" + tid)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        get_ModeComboBox.SelectedIndex = 0
        query_WayComboBox.SelectedIndex = 0

        Skin = New SkinH_Net()
        Skin.AttachRes(My.Resources.黑色流光, My.Resources.黑色流光.Length, "", 0, 0, 0)
        Skin.SetAero(True)
    End Sub

    Private Sub get_AtButton_Click(sender As System.Object, e As System.EventArgs) Handles get_AtButton.Click
        If get_TaskRunning Then
            MessageBox.Show("请等待当前任务结束！")
            Return
        End If

        GenForm.ShowDialog()
    End Sub

    Private Sub get_CopyButton_Click(sender As System.Object, e As System.EventArgs) Handles get_CopyButton.Click
        If get_OutTextBox.Text <> "" Then
            Clipboard.SetText(get_OutTextBox.Text)
            MessageBox.Show("复制成功！")
        End If
    End Sub

    Private Sub get_GetMember() '取会员

        Dim wc As New WizardHTTP
        '取总页数
        Dim kw As String = URLEncoding(get_TB, Encoding.Default)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + kw)
            Dim left As Integer = retstr.IndexOf(""">下一页")
            If left = -1 Then : get_EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                Dim right As Integer = retstr.IndexOf("""", left)
                get_EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If get_StartPage > get_EndPage Then get_StartPage = 1
        Catch ex As Exception
            MessageBox.Show("会员信息初始化失败！")
            get_TaskEnd()
            Return
        End Try

        For i As Integer = get_StartPage To get_EndPage
            Try
                get_StartNumeric.Value = i

                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + kw + "&pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("id=""member_list"""),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("id=""j_pagebar""")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)

                left = 0
                right = 0
                While True
                    left = retstr.IndexOf("bg_lv", right)
                    If left = -1 Then Exit While
                    left += 5
                    Dim lv As String = retstr.Substring(left, 1)
                    left = retstr.IndexOf("_blank", left)
                    If left = -1 Then Exit While
                    left += 8
                    right = retstr.IndexOf("<", left)
                    If right = -1 Then Exit While
                    Dim un As String = retstr.Substring(left, right - left)
                    If Not get_NdLv3 Or lv = "2" Then
                        get_OutTextBox.AppendText(un + vbCrLf)
                    End If
                End While
            Catch ex As Exception : End Try
        Next
        get_TaskEnd()
    End Sub

    Private Sub get_GetFans() '取粉丝(fans)
        Dim wc As New WizardHTTP
        '读页数
        Dim itieba As String = ""
        Try
            get_ID = URLEncoding(get_ID, Encoding.Default)
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + get_ID)
            Dim left As Integer = retstr.IndexOf("id") + 4
            Dim right As Integer = retstr.IndexOf(",", left)
            itieba = retstr.Substring(left, right - left)

            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/fans")
            left = retstr.IndexOf(""">下一页")
            If left = -1 Then : get_EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                right = retstr.IndexOf("""", left)
                get_EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If get_StartPage > get_EndPage Then get_StartPage = 1
        Catch ex As Exception
            MessageBox.Show("ID信息初始化失败！")
            get_TaskEnd()
            Return
        End Try

        '取ID
        For i As Integer = get_StartPage To get_EndPage
            Try
                get_StartNumeric.Value = i
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/fans?pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("main_wrapper"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("pagerPanel")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)

                left = 0
                right = 0
                While True
                    left = retstr.IndexOf("_blank"">", right)
                    If left = -1 Then Exit While
                    left += 8
                    right = retstr.IndexOf("<", left)
                    If right = -1 Then Exit While
                    Dim tmp As String = retstr.Substring(left, right - left)
                    get_OutTextBox.AppendText(tmp + vbCrLf)
                End While
            Catch ex As Exception : End Try
        Next
        get_TaskEnd()
    End Sub

    Private Sub get_GetConcern() '取关注(concern)

        Dim wc As New WizardHTTP
        '读页数
        Dim itieba As String = ""
        Try
            get_ID = URLEncoding(get_ID, Encoding.Default)
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + get_ID)
            Dim left As Integer = retstr.IndexOf("id") + 4
            Dim right As Integer = retstr.IndexOf(",", left)
            itieba = retstr.Substring(left, right - left)

            wc.SetDefaultHeader()
            retstr = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/concern")
            left = retstr.IndexOf(""">下一页")
            If left = -1 Then : get_EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                right = retstr.IndexOf("""", left)
                get_EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If get_StartPage > get_EndPage Then get_StartPage = 1
        Catch ex As Exception
            MessageBox.Show("ID信息初始化失败！")
            get_TaskEnd()
            Return
        End Try

        '取ID
        For i As Integer = get_StartPage To get_EndPage
            Try
                get_StartNumeric.Value = i
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/" + itieba + "/concern?pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("main_wrapper"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("pagerPanel")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)

                left = 0
                right = 0
                While True
                    left = retstr.IndexOf("_blank"">", right)
                    If left = -1 Then Exit While
                    left += 8
                    right = retstr.IndexOf("<", left)
                    If right = -1 Then Exit While
                    Dim tmp As String = retstr.Substring(left, right - left)
                    get_OutTextBox.AppendText(tmp + vbCrLf)
                End While
            Catch ex As Exception : End Try
        Next
        get_TaskEnd()
    End Sub

    Private Sub get_GetBawu() '取吧务 贴吧列表
        Dim wc As New WizardHTTP
        get_Fdir = URLEncoding(get_Fdir, Encoding.Default)
        get_Sdir = URLEncoding(get_Sdir, Encoding.Default)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/fdir?fd=" + get_Fdir + _
                                                     "&sd=" + get_Sdir)
            Dim left As Integer = retstr.IndexOf(""">下一页")
            If left = -1 Then : get_EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                Dim right As Integer = retstr.IndexOf("""", left)
                get_EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If get_StartPage > get_EndPage Then get_StartPage = 1
        Catch ex As Exception
            MessageBox.Show("目录信息初始化失败！")
            get_TaskEnd()
            Return
        End Try

        For i As Integer = get_StartPage To get_EndPage
            Try
                get_StartNumeric.Value = i
                wc.SetDefaultHeader()
                wc.Encoding = Encoding.Default
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f/fdir?fd=" + _
                                                         get_Fdir + "&sd=" + get_Sdir + "&pn=" + i.ToString())
                Dim left As Integer = retstr.IndexOf("贴吧列表start"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("贴吧列表end")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)

                '取贴吧
                left = 0
                right = 0
                Dim TBList As New List(Of String)
                While True
                    left = retstr.IndexOf("_blank'>", right)
                    If left = -1 Then Exit While
                    left += 8
                    right = retstr.IndexOf("<", left)
                    If right = -1 Then Exit While
                    TBList.Add(retstr.Substring(left, right - left))
                End While
                '取吧务
                For Each x As String In TBList
                    Try
                        wc.Encoding = Encoding.UTF8
                        get_GetBawuID(wc, x)
                    Catch ex As Exception : End Try
                Next
            Catch ex As Exception : End Try
        Next
        get_TaskEnd()
    End Sub

    Private Sub get_GetTid() '取帖子号
        Dim wc As New WizardHTTP
        '取总页数
        Dim kw As String = URLEncoding(get_TB, Encoding.Default)
        Try
            wc.SetDefaultHeader()
            Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + kw)
            Dim left As Integer = retstr.IndexOf(""">下一页")
            If left = -1 Then : get_EndPage = 1
            Else
                left = retstr.IndexOf("pn=", left) + 3
                Dim right As Integer = retstr.IndexOf("""", left)
                get_EndPage = Convert.ToInt32(retstr.Substring(left, right - left))
            End If
            If get_StartPage > get_EndPage Then get_StartPage = 1
        Catch ex As Exception
            MessageBox.Show("贴吧信息初始化失败！")
            get_TaskEnd()
            Return
        End Try

        For i As Integer = get_StartPage To get_EndPage
            Try
                get_StartNumeric.Value = i
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/f?kw=" + kw + "&pn=" + (50 * (i - 1)).ToString())
                Dim left As Integer = retstr.IndexOf("class=""threadlist_li_right"),
                    right As Integer = 0,
                    cutdown As Integer = retstr.IndexOf("id=""frs_list_pager")
                If left = -1 Or cutdown = -1 Then Continue For
                retstr = retstr.Substring(left, cutdown - left)

                left = 0
                right = 0
                While True
                    left = retstr.IndexOf("/p/", right)
                    If left = -1 Then Exit While
                    left += 3
                    right = retstr.IndexOf("""", left)
                    If right = -1 Then Exit While
                    '防止特殊帖子带后缀
                    Dim tmp As String = retstr.Substring(left, right - left).Substring(0, 10)
                    get_OutTextBox.AppendText(tmp + vbCrLf)
                End While
            Catch ex As Exception : End Try
        Next
        get_TaskEnd()
    End Sub

    Private Sub get_TaskEnd()
        get_StartButton.Enabled = True
        get_StopButton.Enabled = False
        get_TaskRunning = False
    End Sub

    Private Sub get_GetBawuID(ByRef wc As WizardHTTP, ByVal tb As String) '取每个贴吧的吧务
        wc.SetDefaultHeader()
        Dim retstr As String = wc.DownloadString("http://wapp.baidu.com/f/m?tn=bdBIW&word=" + tb)
        Dim left As Integer = retstr.IndexOf("吧主"),
            right As Integer = 0,
            cutdown As Integer = retstr.IndexOf("主题")
        If left = -1 Or cutdown = -1 Then Return
        retstr = retstr.Substring(left, cutdown - left)
        left = 0

        While True
            left = retstr.IndexOf(""">", left) + 2
            If left = 1 Then Exit While
            right = retstr.IndexOf("</a>", left)
            If right = -1 Then Exit While
            Dim tmp As String = retstr.Substring(left, right - left)
            get_OutTextBox.AppendText(tmp + vbCrLf)
            left = right
        End While
    End Sub

    Private Sub get_StopButton_Click(sender As System.Object, e As System.EventArgs) Handles get_StopButton.Click
        get_Tr.Abort()
        get_TaskEnd()
    End Sub

    Private Sub get_StartButton_Click(sender As System.Object, e As System.EventArgs) Handles get_StartButton.Click
        Try
            get_StartButton.Enabled = False

            Dim func As ThreadStart
            Select Case get_ModeComboBox.SelectedIndex
                Case GET_MEMBER  '会员
                    get_TB = get_InfoTextBox.Text
                    If get_TB = "" Then Throw New Exception("请填写贴吧！")
                    get_StartPage = get_StartNumeric.Value
                    get_NdLv3 = get_Lv3CheckBox.Checked
                    func = AddressOf get_GetMember
                Case GET_CONCERN  '关注
                    get_ID = get_InfoTextBox.Text
                    If get_ID = "" Then Throw New Exception("请填写ID！")
                    get_StartPage = get_StartNumeric.Value
                    func = AddressOf get_GetConcern
                Case GET_FANS  '粉丝
                    get_ID = get_InfoTextBox.Text
                    If get_ID = "" Then Throw New Exception("请填写ID！")
                    get_StartPage = get_StartNumeric.Value
                    func = AddressOf get_GetFans
                Case GET_BAWU  '吧务
                    get_Fdir = get_InfoTextBox.Text
                    get_Sdir = get_SubTextBox.Text
                    If get_Fdir = "" Or get_Sdir = "" Then Throw New Exception("请填写分类！")
                    get_StartPage = get_StartNumeric.Value
                    func = AddressOf get_GetBawu
                Case GET_TID  '帖子
                    get_TB = get_InfoTextBox.Text
                    If get_TB = "" Then Throw New Exception("请填写贴吧！")
                    get_StartPage = get_StartNumeric.Value
                    func = AddressOf get_GetTid
                Case Else
                    Throw New Exception("未知错误！")
            End Select

            get_TaskRunning = True
            get_Tr = New Thread(func)
            get_Tr.Start()
            get_StopButton.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            get_StartButton.Enabled = True
        End Try
    End Sub

    Private Sub get_ModeComboBox_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles get_ModeComboBox.SelectionChangeCommitted
        Select Case get_ModeComboBox.SelectedIndex

            Case GET_MEMBER '会员
                InfoLabel.Text = "贴吧"
                get_InfoTextBox.Enabled = True
                get_StartNumeric.Enabled = True
                get_SubTextBox.Enabled = False
                get_Lv3CheckBox.Enabled = True
            Case GET_CONCERN  '关注
                InfoLabel.Text = "ID"
                get_InfoTextBox.Enabled = True
                get_StartNumeric.Enabled = True
                get_SubTextBox.Enabled = False
                get_Lv3CheckBox.Enabled = False
            Case GET_FANS  '粉丝
                InfoLabel.Text = "ID"
                get_InfoTextBox.Enabled = True
                get_StartNumeric.Enabled = True
                get_SubTextBox.Enabled = False
                get_Lv3CheckBox.Enabled = False
            Case GET_BAWU  '吧务
                InfoLabel.Text = "大分类"
                get_InfoTextBox.Enabled = True
                get_StartNumeric.Enabled = True
                get_SubTextBox.Enabled = True
                get_Lv3CheckBox.Enabled = False
            Case GET_TID  '帖子
                InfoLabel.Text = "贴吧"
                get_InfoTextBox.Enabled = True
                get_StartNumeric.Enabled = True
                get_SubTextBox.Enabled = False
                get_Lv3CheckBox.Enabled = False
            Case Else
                MessageBox.Show("未知错误！")
        End Select
    End Sub

    Private Sub query_StartButton_Click(sender As System.Object, e As System.EventArgs) Handles query_StartButton.Click
        Try
            query_StartButton.Enabled = False
            query_ToTest = query_UnTestTextBox.Text.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
            If query_ToTest.Length = 0 Then Throw New Exception("无待测ID！")
            query_NdStop = False
            Dim func As ThreadStart
            Select Case query_WayComboBox.SelectedIndex
                Case 0
                    func = AddressOf query_TestInfo
                Case 1
                    func = AddressOf query_TestUnLog
                Case Else
                    Throw New Exception("未知错误。")
            End Select
            Dim tr As New Thread(func)
            tr.Start()
            query_StopButton.Enabled = True
        Catch ex As Exception
            query_InfoOut(ex.Message)
            query_StartButton.Enabled = True
        End Try
    End Sub

    Private Sub query_StopButton_Click(sender As System.Object, e As System.EventArgs) Handles query_StopButton.Click
        query_NdStop = True
    End Sub

    Private Sub query_TestInfo()
        Dim wc As New WizardHTTP
        For i As Integer = 0 To query_ToTest.Length - 1
            Try
                If query_NdStop Then Exit For
                Dim tmpid As String = Split(query_ToTest(i), ":")(0)
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoding(tmpid, Encoding.Default))
                Dim left As Integer = retstr.IndexOf("is_prison") + 11
                Dim right As Integer = retstr.IndexOf(",", left)
                Dim prison As String = retstr.Substring(left, right - left)
                left = retstr.IndexOf("creator"":{""id")
                left += 15
                right = retstr.IndexOf("""", left)
                Dim uid As String = retstr.Substring(left, right - left)


                wc.SetDefaultHeader()
                Dim poststr As String = "pn=1&rn=1&uid=" + uid
                Dim sign As String = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                poststr += "&sign=" + sign
                retstr = wc.UploadString("http://c.tieba.baidu.com/c/u/user/profile", poststr)
                left = retstr.IndexOf("concern_num") + 13
                right = retstr.IndexOf(",", left)
                Dim concern As String = retstr.Substring(left, right - left)
                left = retstr.IndexOf("fans_num") + 10
                right = retstr.IndexOf(",", left)
                Dim fans As String = retstr.Substring(left, right - left)
                left = retstr.IndexOf("tb_age") + 9
                right = retstr.IndexOf("""", left)
                Dim age As String = retstr.Substring(left, right - left)

                If prison = "false" Then
                    query_InfoOut(tmpid + " 粉丝数：" + fans + " 关注数：" + concern + " 吧龄：" + age + "年 永封：否。")
                    query_SucTextBox.AppendText(tmpid + vbCrLf)
                Else
                    query_InfoOut(tmpid + " 粉丝数：" + fans + " 关注数：" + concern + " 吧龄：" + age + " 永封：是。")
                End If
            Catch ex As Exception
                query_InfoOut(ex.Message)
            End Try
        Next
        query_StartButton.Enabled = True
        query_StopButton.Enabled = False
    End Sub

    Private Sub query_TestUnLog()
        Dim wc As New WizardHTTP
        wc.Encoding = Encoding.UTF8
        For i As Integer = 0 To query_ToTest.Length - 1
            Try
                If query_NdStop Then Exit For
                Dim tmpid As String = Split(query_ToTest(i), ":")(0)
                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("https://passport.baidu.com/v2/?regnamesugg&tpl=pp&apiver=v3&username=" + URLEncoding(tmpid, Encoding.UTF8))
                Dim left As Integer = retstr.IndexOf("no") + 6
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim errno As String = retstr.Substring(left, right - left)
                If errno <> "0" Then
                    query_InfoOut(tmpid + " 无法注册！")
                Else
                    left = retstr.IndexOf("userExsit") + 13
                    right = retstr.IndexOf("""", left)
                    Dim exist As String = retstr.Substring(left, right - left)
                    If exist = "0" Then
                        query_InfoOut(tmpid + " 未注册！")
                        query_SucTextBox.AppendText(tmpid + vbCrLf)
                    Else
                        query_InfoOut(tmpid + " 已注册！")
                    End If
                End If
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                query_InfoOut(ex.Message)
            End Try
        Next
        query_StartButton.Enabled = True
        query_StopButton.Enabled = False
    End Sub

    Private Sub query_InfoOut(ByVal str As String)
        query_InfoTextBox.AppendText(Time() + str + vbCrLf)
    End Sub
End Class
