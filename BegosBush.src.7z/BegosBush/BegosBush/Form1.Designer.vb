﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.id_PageNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.qid_ListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.id_SniffButton = New System.Windows.Forms.Button()
        Me.id_IDTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.kw_TBTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.kw_ListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.kw_SniffButton = New System.Windows.Forms.Button()
        Me.kw_PageNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.kw_KWTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.bawu_TextBox = New System.Windows.Forms.TextBox()
        Me.bawu_SniffButton = New System.Windows.Forms.Button()
        Me.bawu_TBtextbox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.get_AtButton = New System.Windows.Forms.Button()
        Me.get_CopyButton = New System.Windows.Forms.Button()
        Me.get_StartButton = New System.Windows.Forms.Button()
        Me.get_StopButton = New System.Windows.Forms.Button()
        Me.get_OutTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.get_Lv3CheckBox = New System.Windows.Forms.CheckBox()
        Me.get_StartNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.get_SubTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.get_ModeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.InfoLabel = New System.Windows.Forms.Label()
        Me.get_InfoTextBox = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.query_WayComboBox = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.query_StopButton = New System.Windows.Forms.Button()
        Me.query_StartButton = New System.Windows.Forms.Button()
        Me.query_UnTestTextBox = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.query_SucTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.query_InfoTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.id_PageNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.kw_PageNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.get_StartNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(-1, -2)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(721, 346)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(713, 320)
        Me.TabPage4.TabIndex = 7
        Me.TabPage4.Text = "欢迎"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("微软雅黑", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label7.Location = New System.Drawing.Point(166, 126)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(538, 64)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "欢迎使用·Bego's Bush"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.id_PageNumeric)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.qid_ListView)
        Me.TabPage1.Controls.Add(Me.id_SniffButton)
        Me.TabPage1.Controls.Add(Me.id_IDTextBox)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(713, 320)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "动态探测"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'id_PageNumeric
        '
        Me.id_PageNumeric.Location = New System.Drawing.Point(211, 10)
        Me.id_PageNumeric.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.id_PageNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.id_PageNumeric.Name = "id_PageNumeric"
        Me.id_PageNumeric.Size = New System.Drawing.Size(60, 21)
        Me.id_PageNumeric.TabIndex = 8
        Me.id_PageNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(176, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "页码"
        '
        'qid_ListView
        '
        Me.qid_ListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader1, Me.ColumnHeader2})
        Me.qid_ListView.FullRowSelect = True
        Me.qid_ListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.qid_ListView.HideSelection = False
        Me.qid_ListView.Location = New System.Drawing.Point(6, 37)
        Me.qid_ListView.MultiSelect = False
        Me.qid_ListView.Name = "qid_ListView"
        Me.qid_ListView.ShowGroups = False
        Me.qid_ListView.Size = New System.Drawing.Size(701, 277)
        Me.qid_ListView.TabIndex = 6
        Me.qid_ListView.UseCompatibleStateImageBehavior = False
        Me.qid_ListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "tid"
        Me.ColumnHeader3.Width = 70
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "贴吧"
        Me.ColumnHeader4.Width = 70
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "标题"
        Me.ColumnHeader1.Width = 350
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "最后回复"
        Me.ColumnHeader2.Width = 120
        '
        'id_SniffButton
        '
        Me.id_SniffButton.Location = New System.Drawing.Point(325, 8)
        Me.id_SniffButton.Name = "id_SniffButton"
        Me.id_SniffButton.Size = New System.Drawing.Size(75, 23)
        Me.id_SniffButton.TabIndex = 2
        Me.id_SniffButton.Text = "探测"
        Me.id_SniffButton.UseVisualStyleBackColor = True
        '
        'id_IDTextBox
        '
        Me.id_IDTextBox.Location = New System.Drawing.Point(32, 10)
        Me.id_IDTextBox.Name = "id_IDTextBox"
        Me.id_IDTextBox.Size = New System.Drawing.Size(100, 21)
        Me.id_IDTextBox.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.kw_TBTextBox)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.kw_ListView)
        Me.TabPage2.Controls.Add(Me.kw_SniffButton)
        Me.TabPage2.Controls.Add(Me.kw_PageNumeric)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.kw_KWTextBox)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(713, 320)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "关键词搜索"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'kw_TBTextBox
        '
        Me.kw_TBTextBox.Location = New System.Drawing.Point(209, 9)
        Me.kw_TBTextBox.Name = "kw_TBTextBox"
        Me.kw_TBTextBox.Size = New System.Drawing.Size(100, 21)
        Me.kw_TBTextBox.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(162, 12)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 12)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "(贴吧)"
        '
        'kw_ListView
        '
        Me.kw_ListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader7, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader8, Me.ColumnHeader9})
        Me.kw_ListView.FullRowSelect = True
        Me.kw_ListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.kw_ListView.HideSelection = False
        Me.kw_ListView.Location = New System.Drawing.Point(6, 37)
        Me.kw_ListView.MultiSelect = False
        Me.kw_ListView.Name = "kw_ListView"
        Me.kw_ListView.ShowGroups = False
        Me.kw_ListView.Size = New System.Drawing.Size(701, 277)
        Me.kw_ListView.TabIndex = 7
        Me.kw_ListView.UseCompatibleStateImageBehavior = False
        Me.kw_ListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "tid"
        Me.ColumnHeader7.Width = 70
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "标题"
        Me.ColumnHeader5.Width = 280
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "内容"
        Me.ColumnHeader6.Width = 280
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "作者"
        Me.ColumnHeader8.Width = 120
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "最后回复"
        Me.ColumnHeader9.Width = 120
        '
        'kw_SniffButton
        '
        Me.kw_SniffButton.Location = New System.Drawing.Point(448, 7)
        Me.kw_SniffButton.Name = "kw_SniffButton"
        Me.kw_SniffButton.Size = New System.Drawing.Size(75, 23)
        Me.kw_SniffButton.TabIndex = 4
        Me.kw_SniffButton.Text = "探测"
        Me.kw_SniffButton.UseVisualStyleBackColor = True
        '
        'kw_PageNumeric
        '
        Me.kw_PageNumeric.Location = New System.Drawing.Point(362, 9)
        Me.kw_PageNumeric.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.kw_PageNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.kw_PageNumeric.Name = "kw_PageNumeric"
        Me.kw_PageNumeric.Size = New System.Drawing.Size(60, 21)
        Me.kw_PageNumeric.TabIndex = 3
        Me.kw_PageNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(327, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "页码"
        '
        'kw_KWTextBox
        '
        Me.kw_KWTextBox.Location = New System.Drawing.Point(56, 9)
        Me.kw_KWTextBox.Name = "kw_KWTextBox"
        Me.kw_KWTextBox.Size = New System.Drawing.Size(100, 21)
        Me.kw_KWTextBox.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "关键词"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.bawu_TextBox)
        Me.TabPage3.Controls.Add(Me.bawu_SniffButton)
        Me.TabPage3.Controls.Add(Me.bawu_TBtextbox)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(713, 320)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "吧主检测"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'bawu_TextBox
        '
        Me.bawu_TextBox.BackColor = System.Drawing.Color.White
        Me.bawu_TextBox.Location = New System.Drawing.Point(11, 36)
        Me.bawu_TextBox.Multiline = True
        Me.bawu_TextBox.Name = "bawu_TextBox"
        Me.bawu_TextBox.ReadOnly = True
        Me.bawu_TextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.bawu_TextBox.Size = New System.Drawing.Size(684, 268)
        Me.bawu_TextBox.TabIndex = 3
        '
        'bawu_SniffButton
        '
        Me.bawu_SniffButton.Location = New System.Drawing.Point(243, 7)
        Me.bawu_SniffButton.Name = "bawu_SniffButton"
        Me.bawu_SniffButton.Size = New System.Drawing.Size(75, 23)
        Me.bawu_SniffButton.TabIndex = 2
        Me.bawu_SniffButton.Text = "探测"
        Me.bawu_SniffButton.UseVisualStyleBackColor = True
        '
        'bawu_TBtextbox
        '
        Me.bawu_TBtextbox.Location = New System.Drawing.Point(56, 9)
        Me.bawu_TBtextbox.Name = "bawu_TBtextbox"
        Me.bawu_TBtextbox.Size = New System.Drawing.Size(100, 21)
        Me.bawu_TBtextbox.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 12)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "贴吧"
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.get_AtButton)
        Me.TabPage7.Controls.Add(Me.get_CopyButton)
        Me.TabPage7.Controls.Add(Me.get_StartButton)
        Me.TabPage7.Controls.Add(Me.get_StopButton)
        Me.TabPage7.Controls.Add(Me.get_OutTextBox)
        Me.TabPage7.Controls.Add(Me.GroupBox1)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(713, 320)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "各种取"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'get_AtButton
        '
        Me.get_AtButton.Location = New System.Drawing.Point(9, 291)
        Me.get_AtButton.Name = "get_AtButton"
        Me.get_AtButton.Size = New System.Drawing.Size(75, 23)
        Me.get_AtButton.TabIndex = 14
        Me.get_AtButton.Text = "召唤辅助"
        Me.get_AtButton.UseVisualStyleBackColor = True
        '
        'get_CopyButton
        '
        Me.get_CopyButton.Location = New System.Drawing.Point(98, 291)
        Me.get_CopyButton.Name = "get_CopyButton"
        Me.get_CopyButton.Size = New System.Drawing.Size(75, 23)
        Me.get_CopyButton.TabIndex = 13
        Me.get_CopyButton.Text = "复制"
        Me.get_CopyButton.UseVisualStyleBackColor = True
        '
        'get_StartButton
        '
        Me.get_StartButton.Location = New System.Drawing.Point(189, 291)
        Me.get_StartButton.Name = "get_StartButton"
        Me.get_StartButton.Size = New System.Drawing.Size(75, 23)
        Me.get_StartButton.TabIndex = 12
        Me.get_StartButton.Text = "开始"
        Me.get_StartButton.UseVisualStyleBackColor = True
        '
        'get_StopButton
        '
        Me.get_StopButton.Enabled = False
        Me.get_StopButton.Location = New System.Drawing.Point(277, 291)
        Me.get_StopButton.Name = "get_StopButton"
        Me.get_StopButton.Size = New System.Drawing.Size(75, 23)
        Me.get_StopButton.TabIndex = 11
        Me.get_StopButton.Text = "停止"
        Me.get_StopButton.UseVisualStyleBackColor = True
        '
        'get_OutTextBox
        '
        Me.get_OutTextBox.Location = New System.Drawing.Point(358, 13)
        Me.get_OutTextBox.Multiline = True
        Me.get_OutTextBox.Name = "get_OutTextBox"
        Me.get_OutTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.get_OutTextBox.Size = New System.Drawing.Size(346, 301)
        Me.get_OutTextBox.TabIndex = 10
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.get_Lv3CheckBox)
        Me.GroupBox1.Controls.Add(Me.get_StartNumeric)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.get_SubTextBox)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.get_ModeComboBox)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.InfoLabel)
        Me.GroupBox1.Controls.Add(Me.get_InfoTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(343, 279)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "设置"
        '
        'get_Lv3CheckBox
        '
        Me.get_Lv3CheckBox.AutoSize = True
        Me.get_Lv3CheckBox.Location = New System.Drawing.Point(227, 153)
        Me.get_Lv3CheckBox.Name = "get_Lv3CheckBox"
        Me.get_Lv3CheckBox.Size = New System.Drawing.Size(72, 16)
        Me.get_Lv3CheckBox.TabIndex = 12
        Me.get_Lv3CheckBox.Text = "三级以上"
        Me.get_Lv3CheckBox.UseVisualStyleBackColor = True
        '
        'get_StartNumeric
        '
        Me.get_StartNumeric.Location = New System.Drawing.Point(63, 123)
        Me.get_StartNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.get_StartNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.get_StartNumeric.Name = "get_StartNumeric"
        Me.get_StartNumeric.Size = New System.Drawing.Size(100, 21)
        Me.get_StartNumeric.TabIndex = 10
        Me.get_StartNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(169, 126)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 12)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "小分类"
        '
        'get_SubTextBox
        '
        Me.get_SubTextBox.Enabled = False
        Me.get_SubTextBox.Location = New System.Drawing.Point(227, 123)
        Me.get_SubTextBox.Name = "get_SubTextBox"
        Me.get_SubTextBox.Size = New System.Drawing.Size(100, 21)
        Me.get_SubTextBox.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(12, 126)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(41, 12)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "起始页"
        '
        'get_ModeComboBox
        '
        Me.get_ModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.get_ModeComboBox.FormattingEnabled = True
        Me.get_ModeComboBox.Items.AddRange(New Object() {"会员", "关注", "粉丝", "吧务", "帖子号"})
        Me.get_ModeComboBox.Location = New System.Drawing.Point(63, 97)
        Me.get_ModeComboBox.Name = "get_ModeComboBox"
        Me.get_ModeComboBox.Size = New System.Drawing.Size(100, 20)
        Me.get_ModeComboBox.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 100)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 12)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "模式"
        '
        'InfoLabel
        '
        Me.InfoLabel.AutoSize = True
        Me.InfoLabel.Location = New System.Drawing.Point(169, 100)
        Me.InfoLabel.Name = "InfoLabel"
        Me.InfoLabel.Size = New System.Drawing.Size(29, 12)
        Me.InfoLabel.TabIndex = 0
        Me.InfoLabel.Text = "贴吧"
        '
        'get_InfoTextBox
        '
        Me.get_InfoTextBox.Location = New System.Drawing.Point(227, 97)
        Me.get_InfoTextBox.Name = "get_InfoTextBox"
        Me.get_InfoTextBox.Size = New System.Drawing.Size(100, 21)
        Me.get_InfoTextBox.TabIndex = 1
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Label9)
        Me.TabPage5.Controls.Add(Me.query_InfoTextBox)
        Me.TabPage5.Controls.Add(Me.query_WayComboBox)
        Me.TabPage5.Controls.Add(Me.Label19)
        Me.TabPage5.Controls.Add(Me.query_StopButton)
        Me.TabPage5.Controls.Add(Me.query_StartButton)
        Me.TabPage5.Controls.Add(Me.query_UnTestTextBox)
        Me.TabPage5.Controls.Add(Me.Label16)
        Me.TabPage5.Controls.Add(Me.query_SucTextBox)
        Me.TabPage5.Controls.Add(Me.Label8)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(713, 320)
        Me.TabPage5.TabIndex = 8
        Me.TabPage5.Text = "各种查"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'query_WayComboBox
        '
        Me.query_WayComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.query_WayComboBox.FormattingEnabled = True
        Me.query_WayComboBox.Items.AddRange(New Object() {"基本信息", "未注册"})
        Me.query_WayComboBox.Location = New System.Drawing.Point(578, 266)
        Me.query_WayComboBox.Name = "query_WayComboBox"
        Me.query_WayComboBox.Size = New System.Drawing.Size(124, 20)
        Me.query_WayComboBox.TabIndex = 15
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(356, 269)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 12)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "方式"
        '
        'query_StopButton
        '
        Me.query_StopButton.Enabled = False
        Me.query_StopButton.Location = New System.Drawing.Point(578, 291)
        Me.query_StopButton.Name = "query_StopButton"
        Me.query_StopButton.Size = New System.Drawing.Size(126, 23)
        Me.query_StopButton.TabIndex = 13
        Me.query_StopButton.Text = "停止"
        Me.query_StopButton.UseVisualStyleBackColor = True
        '
        'query_StartButton
        '
        Me.query_StartButton.Location = New System.Drawing.Point(356, 291)
        Me.query_StartButton.Name = "query_StartButton"
        Me.query_StartButton.Size = New System.Drawing.Size(126, 23)
        Me.query_StartButton.TabIndex = 12
        Me.query_StartButton.Text = "开始"
        Me.query_StartButton.UseVisualStyleBackColor = True
        '
        'query_UnTestTextBox
        '
        Me.query_UnTestTextBox.Location = New System.Drawing.Point(356, 24)
        Me.query_UnTestTextBox.Multiline = True
        Me.query_UnTestTextBox.Name = "query_UnTestTextBox"
        Me.query_UnTestTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.query_UnTestTextBox.Size = New System.Drawing.Size(348, 236)
        Me.query_UnTestTextBox.TabIndex = 11
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(354, 6)
        Me.Label16.Margin = New System.Windows.Forms.Padding(3)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(41, 12)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "待检测"
        '
        'query_SucTextBox
        '
        Me.query_SucTextBox.Location = New System.Drawing.Point(9, 24)
        Me.query_SucTextBox.Multiline = True
        Me.query_SucTextBox.Name = "query_SucTextBox"
        Me.query_SucTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.query_SucTextBox.Size = New System.Drawing.Size(341, 147)
        Me.query_SucTextBox.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 6)
        Me.Label8.Margin = New System.Windows.Forms.Padding(3)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 12)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "成功区"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 344)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(719, 22)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel1.IsLink = True
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel1.Text = "联系作者"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.ToolStripStatusLabel2.IsLink = True
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(56, 17)
        Me.ToolStripStatusLabel2.Text = "获取更新"
        '
        'query_InfoTextBox
        '
        Me.query_InfoTextBox.BackColor = System.Drawing.Color.White
        Me.query_InfoTextBox.Location = New System.Drawing.Point(9, 195)
        Me.query_InfoTextBox.Multiline = True
        Me.query_InfoTextBox.Name = "query_InfoTextBox"
        Me.query_InfoTextBox.ReadOnly = True
        Me.query_InfoTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.query_InfoTextBox.Size = New System.Drawing.Size(341, 119)
        Me.query_InfoTextBox.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 177)
        Me.Label9.Margin = New System.Windows.Forms.Padding(3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 12)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "信息输出"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(719, 366)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "北狗の撸·各种查 Bego's Bush - 飞龙"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.id_PageNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.kw_PageNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.get_StartNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents id_SniffButton As System.Windows.Forms.Button
    Friend WithEvents id_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents qid_ListView As System.Windows.Forms.ListView
    Friend WithEvents bawu_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents bawu_SniffButton As System.Windows.Forms.Button
    Friend WithEvents bawu_TBtextbox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents kw_ListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents kw_SniffButton As System.Windows.Forms.Button
    Friend WithEvents kw_PageNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents kw_KWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents kw_TBTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents id_PageNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents get_AtButton As System.Windows.Forms.Button
    Friend WithEvents get_CopyButton As System.Windows.Forms.Button
    Friend WithEvents get_StartButton As System.Windows.Forms.Button
    Friend WithEvents get_StopButton As System.Windows.Forms.Button
    Friend WithEvents get_OutTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents get_Lv3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents get_StartNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents get_SubTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents get_ModeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents InfoLabel As System.Windows.Forms.Label
    Friend WithEvents get_InfoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents query_WayComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents query_StopButton As System.Windows.Forms.Button
    Friend WithEvents query_StartButton As System.Windows.Forms.Button
    Friend WithEvents query_UnTestTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents query_SucTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents query_InfoTextBox As System.Windows.Forms.TextBox

End Class
