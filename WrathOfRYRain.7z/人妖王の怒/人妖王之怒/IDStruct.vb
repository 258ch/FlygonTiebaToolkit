﻿Public Structure IDStruct
    Public UN As String
    Public PW As String
End Structure
