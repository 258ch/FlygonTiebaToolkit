﻿Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Threading
Imports System.Text.RegularExpressions
Imports 人妖王之怒.MyFunctions

Public Class Form1

    Private IDList As New List(Of IDStruct)
    Private IDUbd As Integer = -1
    Private NdStop As Boolean
    Private TrNum As Integer
    Private Ori_PW As String
    Private SW As StreamWriter
    Private SveFile As String = ""
    Private EndCount As Integer
    Private CdsIndex As Integer
    Private Retry As Integer

    Public Declare Function LoadLibFromBuffer Lib "Sunday.dll" (ByVal FileBuffer As Byte(), ByVal FileLen As Integer, Optional ByVal Password As String = "123") As Integer
    Public Declare Function GetCodeFromBuffer Lib "Sunday.dll" (ByVal CdsIndex As Integer, ByVal ImgBuffer As Byte(), ByVal ImgBufLen As Integer, ByVal Vcode As Byte()) As Boolean

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.258ch.com/forum.php")
    End Sub

    Private Sub ChsButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChsButton1.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            SrcTextBox.Text = OpenFileDialog1.FileName
            Dim sr As New StreamReader(OpenFileDialog1.FileName, Encoding.Default)
            Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
            sr.Close()
            IDList.Clear()
            For i As Integer = 0 To tmp.Length - 1
                Dim tmp2 As String() = Split(tmp(i), ":")
                If tmp2.Length < 2 Then Continue For
                Dim tmpid As New IDStruct With {.UN = tmp2(0), .PW = tmp2(1)}
                IDList.Add(tmpid)
            Next
            IDUbd = IDList.Count - 1
            ProgressBar1.Maximum = IDList.Count
            Console.ForegroundColor = ConsoleColor.Yellow
            Console.WriteLine(MyFunctions.Time() + "马甲读取完毕...共{0}个。", IDList.Count)
        End If
    End Sub

    Private Sub ChsButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChsButton2.Click
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            SveFile = SaveFileDialog1.FileName
            SaveTextBox.Text = SaveFileDialog1.FileName
        End If
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If IDUbd = -1 Then Throw New Exception("无待改密马甲！")
            If SveFile = "" Then Throw New Exception("请设置输出文件！")
            Ori_PW = PWTextBox.Text
            If Ori_PW = "" Then Throw New Exception("请设置密码！")
            SW = New StreamWriter(SveFile, True, Encoding.Default)
            SW.AutoFlush = True
            TrNum = TrNumeric.Value
            EndCount = TrNum
            NdStop = False
            ProgressBar1.Value = 0
            Retry = RetryNumeric.Value
            For i As Integer = 0 To TrNum - 1
                Dim tr As New Thread(AddressOf ChangePW)
                tr.Start(i)
            Next
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(MyFunctions.Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Public Sub ChangePW(ByVal index As Integer)

        For i As Integer = index To IDUbd Step TrNum
            Try
                If NdStop Then Exit For
                ProgressBar1.Value += 1
                '检测密码是否相同
                Dim jam = New Jammer(Environment.TickCount + index)
                Dim pw As String = jam.Jammer(Ori_PW)
                If IDList(i).PW = pw Then Continue For
                Dim cookie As String = Login(IDList(i).UN, IDList(i).PW) '登录
                '改密的具体实现
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Referer, "http://passport.baidu.com/v2/?accountchangepwd")
                wc.Headers.Set(HttpRequestHeader.Cookie, cookie)
                wc.Encoding = Encoding.UTF8
                Dim retstr As String = wc.DownloadString("http://passport.baidu.com/v2/?accountchangepwd")
                Dim left As Integer = InStr(retstr, "token value=") + 13
                Dim right As Integer = InStr(left, retstr, """")
                Dim safe_token As String = Mid(retstr, left, right - left)
                left = InStr(retstr, "time value=") + 12
                right = InStr(left, retstr, """")
                Dim safe_time As String = Mid(retstr, left, right - left)
                wc = New WizardHTTP
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Cookie, cookie)
                wc.Headers.Set(HttpRequestHeader.Referer, "http://passport.baidu.com/v2/?lockresetpwd")
                wc.Encoding = Encoding.UTF8
                Dim poststr As String = "password=" + IDList(i).PW + "&newpassword=" + pw + "&verifypassword=" + pw + "&type=0&token=" + safe_token + "&time=" + safe_time + "&tpl=&t="
                retstr = wc.UploadString("http://passport.baidu.com/v2/?lockresetpwd", poststr)
                left = InStr(retstr, "errno") + 7
                right = InStr(left, retstr, ",")
                Dim errno As String = Mid(retstr, left, right - left)
                If errno = "0" Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(MyFunctions.Time() + IDList(i).UN + " 改密成功！")
                    SW.WriteLine(IDList(i).UN + ":" + pw)
                Else
                    left = InStr(retstr, "errmsg") + 9
                    right = InStr(left, retstr, """")
                    Dim errmsg As String = Mid(retstr, left, right - left)
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(MyFunctions.Time() + IDList(i).UN + " 改密失败！" + errmsg)
                End If
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(MyFunctions.Time() + ex.Message)
            End Try
        Next
        EndCount -= 1
        If EndCount = 0 Then
            Dim tr As New Thread(AddressOf TrEnd)
            tr.Start()
        End If
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(MyFunctions.Time() + "用户终止任务，请等待当前线程结束！")
    End Sub

    Public Sub TrEnd()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(MyFunctions.Time() + "任务结束...")
        SW.Close()
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Function Login(ByVal un As String, ByVal pw As String) As String '成功返回cookie 失败抛出异常
        Dim wc As New WizardHTTP
        wc.SetDefaultHeader()
        Dim poststr As String = "login_username=" + URLEncoUTF8(un) + "&login_loginpass=" + pw + "&aaa=%E7%99%BB%E5%BD%95&login=yes&can_input=0&u=http%3A%2F%2Fwapp.baidu.com%2F&tpl=wapp&tn=bdIndex&pu=&ssid=&from=&bd_page_type=1&uid=1337004243356_897&type="
        Dim retstr As String = wc.UploadString("http://wappass.baidu.com/passport", poststr)
        Dim left As Integer = retstr.IndexOf("genimage?")
        Dim i As Integer = 0
        While left <> -1 '需要验证码
            If i = Retry Then Exit While
            left += 9
            Dim right As Integer = retstr.IndexOf("""", left)
            Dim vcode As String = retstr.Substring(left, right - left)
            wc = New WizardHTTP
            wc.SetDefaultHeader()
            Dim picdata As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
            Dim tmpbs As String = ""
            Dim buff(64 - 1) As Byte
            GetCodeFromBuffer(CdsIndex, picdata, picdata.Length, buff)
            tmpbs = Encoding.Default.GetString(buff).Substring(0, 4)
            poststr = "login_verifycode=" + tmpbs + "&login_bdverify=" + vcode + "&login_username=" + URLEncoUTF8(un) + "&login_loginpass=" + pw + "&login_save=0&login_bdtime=1350292822&login_is_wid=0&login_wid=&login=vc&u=&tn=&tpl=&ssid=&from=&bd_page_type=&uid=1350292801959_829&isphone=&login_username_input=&type="
            wc = New WizardHTTP
            wc.SetDefaultHeader()
            retstr = wc.UploadString("http://wappass.baidu.com/passport", poststr)
            left = retstr.IndexOf("genimage?")
            i += 1
        End While
        Dim rethdr As String = wc.ResponseHeaders.Get("Set-Cookie")
        Dim re As New Regex("BDUSS=.{192}; ")
        Dim rm As Match = re.Match(rethdr)
        If Not rm.Success Then
            Throw New Exception(un + " 登录失败！")
        End If
        Dim bduss As String = rm.Value
        re = New Regex("PTOKEN=.{32}; ")
        rm = re.Match(rethdr)
        Dim ptoken As String = rm.Value
        re = New Regex("STOKEN=.{32}; ")
        rm = re.Match(rethdr)
        Dim stoken As String = rm.Value
        Return bduss + ptoken + stoken
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CdsIndex = LoadLibFromBuffer(My.Resources.baidu, My.Resources.baidu.Length)
    End Sub
End Class
