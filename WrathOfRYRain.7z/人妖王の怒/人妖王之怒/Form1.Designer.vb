﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SrcTextBox = New System.Windows.Forms.TextBox()
        Me.ChsButton1 = New System.Windows.Forms.Button()
        Me.ChsButton2 = New System.Windows.Forms.Button()
        Me.SaveTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.RetryNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RetryNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "源文件"
        '
        'SrcTextBox
        '
        Me.SrcTextBox.BackColor = System.Drawing.Color.White
        Me.SrcTextBox.Location = New System.Drawing.Point(70, 22)
        Me.SrcTextBox.Name = "SrcTextBox"
        Me.SrcTextBox.ReadOnly = True
        Me.SrcTextBox.Size = New System.Drawing.Size(207, 21)
        Me.SrcTextBox.TabIndex = 1
        '
        'ChsButton1
        '
        Me.ChsButton1.Location = New System.Drawing.Point(283, 22)
        Me.ChsButton1.Name = "ChsButton1"
        Me.ChsButton1.Size = New System.Drawing.Size(49, 21)
        Me.ChsButton1.TabIndex = 2
        Me.ChsButton1.Text = "选择"
        Me.ChsButton1.UseVisualStyleBackColor = True
        '
        'ChsButton2
        '
        Me.ChsButton2.Location = New System.Drawing.Point(283, 48)
        Me.ChsButton2.Name = "ChsButton2"
        Me.ChsButton2.Size = New System.Drawing.Size(49, 21)
        Me.ChsButton2.TabIndex = 5
        Me.ChsButton2.Text = "选择"
        Me.ChsButton2.UseVisualStyleBackColor = True
        '
        'SaveTextBox
        '
        Me.SaveTextBox.BackColor = System.Drawing.Color.White
        Me.SaveTextBox.Location = New System.Drawing.Point(70, 49)
        Me.SaveTextBox.Name = "SaveTextBox"
        Me.SaveTextBox.ReadOnly = True
        Me.SaveTextBox.Size = New System.Drawing.Size(207, 21)
        Me.SaveTextBox.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "生成文件"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "密码"
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(70, 76)
        Me.PWTextBox.MaxLength = 14
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.Size = New System.Drawing.Size(96, 21)
        Me.PWTextBox.TabIndex = 7
        Me.PWTextBox.Text = "123456a"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 105)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "线程数"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(25, 130)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(307, 23)
        Me.ProgressBar1.TabIndex = 10
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(114, 159)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(100, 23)
        Me.StartButton.TabIndex = 11
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(232, 159)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(100, 23)
        Me.StopButton.TabIndex = 12
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(23, 164)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(65, 12)
        Me.LinkLabel1.TabIndex = 13
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "苍海·国际"
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(70, 103)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(96, 21)
        Me.TrNumeric.TabIndex = 14
        Me.TrNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "*.txt"
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "*.txt"
        Me.SaveFileDialog1.Filter = "文本文件(*.txt)|*.txt"
        '
        'RetryNumeric
        '
        Me.RetryNumeric.Location = New System.Drawing.Point(227, 103)
        Me.RetryNumeric.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.RetryNumeric.Name = "RetryNumeric"
        Me.RetryNumeric.Size = New System.Drawing.Size(105, 21)
        Me.RetryNumeric.TabIndex = 16
        Me.RetryNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(172, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "登录重试"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(360, 197)
        Me.Controls.Add(Me.RetryNumeric)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TrNumeric)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PWTextBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ChsButton2)
        Me.Controls.Add(Me.SaveTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ChsButton1)
        Me.Controls.Add(Me.SrcTextBox)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "人妖王の怒·批量改密 - 飞龙"
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RetryNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SrcTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ChsButton1 As System.Windows.Forms.Button
    Friend WithEvents ChsButton2 As System.Windows.Forms.Button
    Friend WithEvents SaveTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents RetryNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
