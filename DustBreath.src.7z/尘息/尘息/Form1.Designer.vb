﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.LogButton = New System.Windows.Forms.Button()
        Me.WayComboBox = New System.Windows.Forms.ComboBox()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BSTextBox = New System.Windows.Forms.TextBox()
        Me.BSPictureBox = New System.Windows.Forms.PictureBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.EndNumeric = New System.Windows.Forms.NumericUpDown()
        Me.SendRadio = New System.Windows.Forms.RadioButton()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TargetTextBox = New System.Windows.Forms.TextBox()
        Me.ForeNumeric = New System.Windows.Forms.NumericUpDown()
        Me.BoomRadio = New System.Windows.Forms.RadioButton()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TBTextBox = New System.Windows.Forms.TextBox()
        Me.ContentTextBox = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.EndNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ForeNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ExitButton)
        Me.GroupBox1.Controls.Add(Me.LogButton)
        Me.GroupBox1.Controls.Add(Me.WayComboBox)
        Me.GroupBox1.Controls.Add(Me.PWTextBox)
        Me.GroupBox1.Controls.Add(Me.IDTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(178, 139)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "登录"
        '
        'ExitButton
        '
        Me.ExitButton.Enabled = False
        Me.ExitButton.Location = New System.Drawing.Point(98, 103)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(64, 23)
        Me.ExitButton.TabIndex = 7
        Me.ExitButton.Text = "退出"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'LogButton
        '
        Me.LogButton.Location = New System.Drawing.Point(17, 103)
        Me.LogButton.Name = "LogButton"
        Me.LogButton.Size = New System.Drawing.Size(64, 23)
        Me.LogButton.TabIndex = 6
        Me.LogButton.Text = "登录"
        Me.LogButton.UseVisualStyleBackColor = True
        '
        'WayComboBox
        '
        Me.WayComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.WayComboBox.FormattingEnabled = True
        Me.WayComboBox.Items.AddRange(New Object() {"wap", "客户端"})
        Me.WayComboBox.Location = New System.Drawing.Point(62, 74)
        Me.WayComboBox.Name = "WayComboBox"
        Me.WayComboBox.Size = New System.Drawing.Size(100, 20)
        Me.WayComboBox.TabIndex = 5
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(62, 47)
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.PWTextBox.Size = New System.Drawing.Size(100, 21)
        Me.PWTextBox.TabIndex = 4
        '
        'IDTextBox
        '
        Me.IDTextBox.Location = New System.Drawing.Point(62, 20)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(100, 21)
        Me.IDTextBox.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "引擎"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(17, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "PW"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BSTextBox)
        Me.GroupBox2.Controls.Add(Me.BSPictureBox)
        Me.GroupBox2.Location = New System.Drawing.Point(196, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(181, 139)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "验证码"
        '
        'BSTextBox
        '
        Me.BSTextBox.Enabled = False
        Me.BSTextBox.Location = New System.Drawing.Point(18, 88)
        Me.BSTextBox.Name = "BSTextBox"
        Me.BSTextBox.Size = New System.Drawing.Size(143, 21)
        Me.BSTextBox.TabIndex = 1
        '
        'BSPictureBox
        '
        Me.BSPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BSPictureBox.Location = New System.Drawing.Point(18, 23)
        Me.BSPictureBox.Name = "BSPictureBox"
        Me.BSPictureBox.Size = New System.Drawing.Size(143, 45)
        Me.BSPictureBox.TabIndex = 0
        Me.BSPictureBox.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LinkLabel2)
        Me.GroupBox3.Controls.Add(Me.LinkLabel1)
        Me.GroupBox3.Controls.Add(Me.EndNumeric)
        Me.GroupBox3.Controls.Add(Me.SendRadio)
        Me.GroupBox3.Controls.Add(Me.DelayNumeric)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.TargetTextBox)
        Me.GroupBox3.Controls.Add(Me.ForeNumeric)
        Me.GroupBox3.Controls.Add(Me.BoomRadio)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.TBTextBox)
        Me.GroupBox3.Controls.Add(Me.ContentTextBox)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.StartButton)
        Me.GroupBox3.Controls.Add(Me.StopButton)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 157)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(365, 155)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "设置"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(67, 128)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 11
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "获取更新"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(8, 128)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 10
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "联系作者"
        '
        'EndNumeric
        '
        Me.EndNumeric.Enabled = False
        Me.EndNumeric.Location = New System.Drawing.Point(113, 69)
        Me.EndNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.EndNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.EndNumeric.Name = "EndNumeric"
        Me.EndNumeric.Size = New System.Drawing.Size(51, 21)
        Me.EndNumeric.TabIndex = 9
        Me.EndNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'SendRadio
        '
        Me.SendRadio.AutoSize = True
        Me.SendRadio.Location = New System.Drawing.Point(247, 20)
        Me.SendRadio.Name = "SendRadio"
        Me.SendRadio.Size = New System.Drawing.Size(71, 16)
        Me.SendRadio.TabIndex = 7
        Me.SendRadio.Text = "消息群发"
        Me.SendRadio.UseVisualStyleBackColor = True
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(247, 69)
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(108, 21)
        Me.DelayNumeric.TabIndex = 8
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(185, 71)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 12)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "间隔"
        '
        'TargetTextBox
        '
        Me.TargetTextBox.Location = New System.Drawing.Point(55, 42)
        Me.TargetTextBox.Name = "TargetTextBox"
        Me.TargetTextBox.Size = New System.Drawing.Size(109, 21)
        Me.TargetTextBox.TabIndex = 1
        '
        'ForeNumeric
        '
        Me.ForeNumeric.Enabled = False
        Me.ForeNumeric.Location = New System.Drawing.Point(56, 69)
        Me.ForeNumeric.Maximum = New Decimal(New Integer() {1410065408, 2, 0, 0})
        Me.ForeNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ForeNumeric.Name = "ForeNumeric"
        Me.ForeNumeric.Size = New System.Drawing.Size(51, 21)
        Me.ForeNumeric.TabIndex = 6
        Me.ForeNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'BoomRadio
        '
        Me.BoomRadio.AutoSize = True
        Me.BoomRadio.Checked = True
        Me.BoomRadio.Location = New System.Drawing.Point(55, 20)
        Me.BoomRadio.Name = "BoomRadio"
        Me.BoomRadio.Size = New System.Drawing.Size(71, 16)
        Me.BoomRadio.TabIndex = 6
        Me.BoomRadio.TabStop = True
        Me.BoomRadio.Text = "消息轰炸"
        Me.BoomRadio.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 71)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 12)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "页数"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 45)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "目标ID"
        '
        'TBTextBox
        '
        Me.TBTextBox.Enabled = False
        Me.TBTextBox.Location = New System.Drawing.Point(247, 42)
        Me.TBTextBox.Name = "TBTextBox"
        Me.TBTextBox.Size = New System.Drawing.Size(108, 21)
        Me.TBTextBox.TabIndex = 5
        '
        'ContentTextBox
        '
        Me.ContentTextBox.Location = New System.Drawing.Point(55, 96)
        Me.ContentTextBox.Name = "ContentTextBox"
        Me.ContentTextBox.Size = New System.Drawing.Size(300, 21)
        Me.ContentTextBox.TabIndex = 5
        Me.ContentTextBox.Text = "龙哥盟-飞龙有意%c%c%c%i%i%i"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(185, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 12)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "目标贴吧"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 99)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 12)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "内容"
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(133, 123)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(108, 23)
        Me.StartButton.TabIndex = 2
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(247, 123)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(108, 23)
        Me.StopButton.TabIndex = 1
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(389, 324)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "尘息·百度消息批量发送 - 飞龙"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.BSPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.EndNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ForeNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents LogButton As System.Windows.Forms.Button
    Friend WithEvents WayComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents PWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BSPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents ContentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TargetTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ForeNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents TBTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents EndNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents SendRadio As System.Windows.Forms.RadioButton
    Friend WithEvents BoomRadio As System.Windows.Forms.RadioButton
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel

End Class
