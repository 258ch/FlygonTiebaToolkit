﻿Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Threading

Public Class Form1

    Private Sve_ID As String = "" '纯粹用来保存配置信息
    Private BDUSS As String = "" '192位cookie
    Private BDSP As String = "" '此值对于同一id相同
    Private LoginTr As Thread
    Private SendTr As Thread
    Private BS As String
    Private OriContent As String
    Private Target As String
    Private Delay As Integer
    Private TB As String
    Private StartPage As Integer
    Private EndPage As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If File.Exists(Directory.GetCurrentDirectory() + "\settings.sve") Then
            Dim sr As New StreamReader(Directory.GetCurrentDirectory() + "\settings.sve", Encoding.Default)
            Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
            If tmp.Length < 3 Then Exit Sub
            If tmp(1) = "" Then Exit Sub
            Sve_ID = tmp(0)
            BDUSS = tmp(1)
            BDSP = tmp(2)
            IDTextBox.Text = Sve_ID
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            LogButton.Enabled = False
            ExitButton.Enabled = True
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(MyFunctions.Time() + "读取用户信息成功！")
            sr.Close()
        End If
    End Sub

    Private Sub LogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogButton.Click
        If IDTextBox.Text = "" Or PWTextBox.Text = "" Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(MyFunctions.Time() + "请填写用户名和密码！")
            Exit Sub
        End If
        LogButton.Enabled = False
        LoginTr = New Thread(AddressOf Login)
        LoginTr.Start()
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        BDUSS = ""
        BDSP = ""
        'BaiduID = ""
        Sve_ID = ""
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(MyFunctions.Time() + "已退出。")
        IDTextBox.Enabled = True
        PWTextBox.Enabled = True
        LogButton.Enabled = True
        ExitButton.Enabled = False
    End Sub

    Private Sub Login() '登录的时候太卡 故写出来一个函数用多线程调用
        Try
            Dim id As String = IDTextBox.Text
            Dim wc As New WizardHTTP
            wc.SetDefaultHeader()
            If WayComboBox.SelectedIndex = 0 Then 'wap方式
                Dim poststr As String = "login_username=" + MyFunctions.URLEncoUTF8(id) + "&login_loginpass=" + PWTextBox.Text + "&aaa=%E7%99%BB%E5%BD%95&login=yes&can_input=0&u=http%3A%2F%2Fwapp.baidu.com%2F&tpl=wapp&tn=bdIndex&pu=&ssid=&from=&bd_page_type=1&uid=1337004243356_897&type="
                Dim retstr As String = wc.UploadString("http://wappass.baidu.com/passport", poststr)
                Dim left As Integer = InStr(retstr, "genimage?")
                If left <> 0 Then
                    left += 9
                    Dim right As Integer = InStr(left, retstr, """")
                    Dim vcode As String = retstr.Substring(left - 1, right - left)
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    Dim data As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                    Dim pic As Image = Image.FromStream(New MemoryStream(data))
                    BSPictureBox.Image = pic
                    BS = ""
                    BSTextBox.Enabled = True
                    While BS = ""
                        Thread.Sleep(200)
                    End While
                    BSTextBox.Enabled = False
                    poststr = "login_verifycode=" + BS + "&login_bdverify=" + vcode + "&login_username=" + MyFunctions.URLEncoUTF8(id) + "&login_loginpass=" + PWTextBox.Text + "&login_save=0&login_bdtime=1350292822&login_is_wid=0&login_wid=&login=vc&u=&tn=&tpl=&ssid=&from=&bd_page_type=&uid=1350292801959_829&isphone=&login_username_input=&type="
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    retstr = wc.UploadString("http://wappass.baidu.com/passport", poststr)
                End If
                Dim rethdr As String = wc.ResponseHeaders.Item(HttpResponseHeader.SetCookie)
                Dim re As New Regex("BDUSS=.{192}; ")
                Dim rm As Match = re.Match(rethdr)
                If Not rm.Success Then
                    Throw New Exception("登录失败！")
                End If
                BDUSS = rm.Value
            Else '客户端方式
                Dim poststr As String = "_client_id=" + MyFunctions.GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&from=tieba&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(PWTextBox.Text)) + "&un=" + MyFunctions.URLEncoGBK(id)
                Dim retstr As String = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                Dim Left As Integer = InStr(retstr, "error_code"":5")
                If Left <> 0 Then
                    Left = InStr(retstr, "vcode_md5") + 12
                    Dim right As Integer = InStr(Left, retstr, """")
                    Dim vcode As String = retstr.Substring(Left - 1, right - Left)
                    wc = New WizardHTTP
                    wc.SetDefaultHeaderAdr()
                    Dim data As Byte() = wc.DownloadData("http://passport.baidu.com/cgi-bin/genimage?" + vcode)
                    Dim pic As Image = Image.FromStream(New MemoryStream(data))
                    BSPictureBox.Image = pic
                    BS = ""
                    BSTextBox.Enabled = True
                    While BS = ""
                        Thread.Sleep(200)
                    End While
                    BSTextBox.Enabled = False
                    poststr = "_client_id=" + MyFunctions.GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=baidu_appstore&isphone=0&net_type=1&passwd=" + Convert.ToBase64String(Encoding.Default.GetBytes(PWTextBox.Text)) + "&un=" + MyFunctions.URLEncoGBK(id) + "&vcode=" + BS + "&vcode_md5=" + vcode
                    wc = New WizardHTTP
                    wc.SetDefaultHeader()
                    retstr = wc.UploadString("http://c.tieba.baidu.com/c/s/login", poststr)
                End If
                Dim re As New Regex("BDUSS"":"".{192}")
                Dim rm As Match = re.Match(retstr)
                If Not rm.Success Then
                    Left = retstr.IndexOf("error_msg") + 12
                    Dim right As Integer = retstr.IndexOf("""", Left)
                    Dim errmsg As String = retstr.Substring(Left, right - Left)
                    Throw New Exception("登录失败！" + MyFunctions.UnicodeDeco(errmsg))
                End If
                BDUSS = "BDUSS=" + Mid(rm.Value, 9, 192) + "; "
            End If
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(MyFunctions.Time() + "登录成功！")
            wc = New WizardHTTP
            wc.SetDefaultHeader()
            wc.Headers.Set(HttpRequestHeader.Cookie, BDUSS)
            wc.DownloadString("http://msg.baidu.com")
            Dim rethdr2 As String = wc.ResponseHeaders.Item(HttpResponseHeader.SetCookie)
            Dim re2 As New Regex("BDSP=.{200}; ")
            Dim rm2 As Match = re2.Match(rethdr2)
            If Not rm2.Success Then
                Throw New Exception("BDSP获取失败！")
            End If
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(MyFunctions.Time() + "BDSP获取成功！")
            BDSP = rm2.Value
            'Dim re3 As New Regex("BAIDUID=.{32}; ")
            'Dim rm3 As Match = re3.Match(rethdr2)
            'BaiduID = rm3.Value
            Sve_ID = id
            IDTextBox.Enabled = False
            PWTextBox.Enabled = False
            ExitButton.Enabled = True
        Catch e As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(MyFunctions.Time() + e.Message)
            LogButton.Enabled = True
        End Try
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If BDUSS = "" Then
                Throw New Exception("请先登录！")
            End If
            If ContentTextBox.Text = "" Then
                Throw New Exception("请填写内容！")
            End If
            OriContent = ContentTextBox.Text
            If SendRadio.Checked Then '消息群发
                TB = TBTextBox.Text
                If TB = "" Then
                    Throw New Exception("请填写贴吧！")
                End If
                StartPage = ForeNumeric.Value
                EndPage = EndNumeric.Value
                Delay = DelayNumeric.Value
                SendTr = New Thread(AddressOf MsgSend)
                SendTr.Start()
            Else '消息轰炸
                Target = TargetTextBox.Text
                If Target = "" Then
                    Throw New Exception("请填写目标！")
                End If
                Delay = DelayNumeric.Value
                SendTr = New Thread(AddressOf MsgBm)
                SendTr.Start()
            End If
            BSTextBox.Enabled = True
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(MyFunctions.Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub MsgSend() '消息群发 线程
        TB = MyFunctions.URLEncoGBK(TB)
        Dim wc As New WizardHTTP
        Dim re As New Regex("username="".{1,14}"" src")
        Dim re2 As New Regex("BDSTAT=.{64}; ")
        For i As Integer = StartPage To EndPage
            '取会员
            Dim retstr As String = ""
            Try
                wc.SetDefaultHeader()
                wc.Encoding = Encoding.Default
                retstr = wc.DownloadString("http://tieba.baidu.com/f/like/manage/list?kw=" + TB + "&pn=" + i.ToString())
                Dim rms As MatchCollection = re.Matches(retstr)
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(MyFunctions.Time() + "第" + i.ToString() + "页会员获取完毕...")
                '五个一组构造发送目标
                Dim quo As Integer = rms.Count / 5
                Dim spare As Integer = rms.Count Mod 5
                Dim IDList As New List(Of String)
                For j As Integer = 0 To quo - 1
                    Dim tmpid As String = ""
                    For k As Integer = 0 To 4
                        tmpid += Mid(rms(j * 5 + k).Value, 11, rms(j * 5 + k).Length - 15) + ";"
                    Next
                    IDList.Add(tmpid)
                Next
                If spare <> 0 Then
                    Dim tmpid As String = ""
                    For j As Integer = 0 To spare - 1
                        tmpid += Mid(rms(rms.Count - j - 1).Value, 11, rms(rms.Count - j - 1).Length - 15) + ";"
                    Next
                    IDList.Add(tmpid)
                End If

                For Each x As String In IDList
                    Try
                        wc.SetDefaultHeader()
                        retstr = wc.DownloadString("http://msg.baidu.com/msg/writing")
                        Dim rethdr As String = wc.ResponseHeaders.Item(HttpResponseHeader.SetCookie)
                        Dim rm As Match = re2.Match(rethdr)
                        Dim bdstat As String = rm.Value
                        Dim left As Integer = retstr.IndexOf("msgBdsToken") + 15
                        Dim right As Integer = retstr.IndexOf("""", left)
                        Dim token As String = retstr.Substring(left, right - left)
                        wc.SetDefaultHeader()
                        wc.Headers.Set(HttpRequestHeader.Cookie, BDUSS)
                        wc.Headers.Set(HttpRequestHeader.Referer, "http://msg.baidu.com/msg/writing")
                        retstr = wc.DownloadString("https://passport.baidu.com/v2/api/?getapi&tpl=qing&apiver=v3&class=reg&echoback=msg.home.editor.changeVerifyCode&tt=1364192615214&callback=msg.msgpublish.Form.changeVerifyCode") '<!!!>
                        left = retstr.IndexOf("codeString") + 15
                        right = retstr.IndexOf("""", left)
                        Dim vcode As String = retstr.Substring(left, right - left)
                        wc.SetDefaultHeader()
                        Dim picdata As Byte() = wc.DownloadData("https://passport.baidu.com/cgi-bin/genimage?" + vcode)
                        Dim pic As Image = Image.FromStream(New MemoryStream(picdata))
                        BSPictureBox.Image = pic
                        BS = ""
                        While BS = "" : Thread.Sleep(200) : End While
                        Dim jam As New Jammer()
                        Dim content As String = jam.Jammer(OriContent)
                        Dim poststr As String = "msgcontent=" + content + "&vcode=" + BS + "&msgvcode=" + vcode + "&msgreceiver=" + x + "&bdstoken=" + token
                        wc.SetDefaultHeader()
                        wc.Headers.Set(HttpRequestHeader.Cookie, BDUSS + BDSP + bdstat)
                        wc.Encoding = Encoding.UTF8
                        retstr = wc.UploadString("http://msg.baidu.com/msg/writing/submit/msg", poststr)
                        left = retstr.IndexOf("errorNo") + 11
                        right = retstr.IndexOf("""", left)
                        Dim errno As String = retstr.Substring(left, right - left)
                        If errno = "0" Then
                            Console.ForegroundColor = ConsoleColor.Green
                            Console.WriteLine(MyFunctions.Time() + x + " 发送成功！")
                        Else
                            left = retstr.IndexOf("errorMsg") + 12
                            right = retstr.IndexOf("""", left)
                            Dim errmsg As String = retstr.Substring(left, right - left)
                            Console.ForegroundColor = ConsoleColor.Red
                            Console.WriteLine(MyFunctions.Time() + x + " 发送失败！" + errmsg)
                        End If
                        Thread.Sleep(Delay)
                    Catch e As Exception
                        Console.ForegroundColor = ConsoleColor.Red
                        Console.WriteLine(MyFunctions.Time() + e.Message)
                        Continue For
                    End Try
                Next
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(MyFunctions.Time() + ex.Message)
            End Try
        Next
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(MyFunctions.Time() + "已完成...")
        BSTextBox.Enabled = False
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub MsgBm() '消息轰炸 线程
        Dim wc As New WizardHTTP
        While True
            Try
                wc.SetDefaultHeader()
                wc.Encoding = Encoding.Default
                wc.Headers.Set(HttpRequestHeader.Cookie, BDUSS)
                Dim retstr As String = wc.DownloadString("http://msg.baidu.com/msg/writing")
                Dim rethdr As String = wc.ResponseHeaders.Item(HttpResponseHeader.SetCookie)
                Dim re As New Regex("BDSTAT=.{64}; ")
                Dim rm As Match = re.Match(rethdr)
                Dim bdstat As String = rm.Value
                Dim left As Integer = retstr.IndexOf("msgBdsToken") + 15
                Dim right As Integer = retstr.IndexOf("""", left)
                Dim token As String = retstr.Substring(left, right - left)
                wc.Headers.Set(HttpRequestHeader.Cookie, BDUSS)
                wc.Headers.Set(HttpRequestHeader.Referer, "http://msg.baidu.com/msg/writing")
                retstr = wc.DownloadString("https://passport.baidu.com/v2/api/?getapi&tpl=qing&apiver=v3&class=reg&echoback=msg.home.editor.changeVerifyCode&tt=1364192615214&callback=msg.msgpublish.Form.changeVerifyCode") '<!!!>
                left = retstr.IndexOf("codeString") + 15
                right = retstr.IndexOf("""", left)
                Dim vcode As String = retstr.Substring(left, right - left)
                wc.SetDefaultHeader()
                Dim picdata As Byte() = wc.DownloadData("https://passport.baidu.com/cgi-bin/genimage?" + vcode)
                Dim pic As Image = Image.FromStream(New MemoryStream(picdata))
                BSPictureBox.Image = pic
                BS = ""
                While BS = "" : Thread.Sleep(200) : End While
                Dim jam As New Jammer()
                Dim content As String = jam.Jammer(OriContent)
                Dim poststr As String = "msgcontent=" + content + "&vcode=" + BS + "&msgvcode=" + vcode + "&msgreceiver=" + Target + "&bdstoken=" + token
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Cookie, BDUSS + BDSP + bdstat)
                wc.Encoding = Encoding.UTF8
                retstr = wc.UploadString("http://msg.baidu.com/msg/writing/submit/msg", poststr)
                left = retstr.IndexOf("errorNo") + 11
                right = retstr.IndexOf("""", left)
                Dim errno As String = retstr.Substring(left, right - left)
                If errno = "0" Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(MyFunctions.Time() + Target + " 发送成功！")
                Else
                    left = retstr.IndexOf("errorMsg") + 12
                    right = retstr.IndexOf("""", left)
                    Dim errmsg As String = retstr.Substring(left, right - left)
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(MyFunctions.Time() + Target + " 发送失败！" + errmsg)
                End If
            Catch e As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(MyFunctions.Time() + e.Message)
                Continue While
            End Try
        End While
    End Sub

    Private Sub BSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSTextBox.TextChanged
        If BSTextBox.Text.Length = 4 Then
            BS = BSTextBox.Text
            BSPictureBox.Image = Nothing
            BSTextBox.Text = ""
        End If
    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        SendTr.Abort()
        BSPictureBox.Image = Nothing
        BSTextBox.Text = ""
        BSTextBox.Enabled = False
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(MyFunctions.Time() + "已停止。")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If BDUSS <> "" Then
            Dim sw As New StreamWriter(Directory.GetCurrentDirectory() + "\settings.sve", False, Encoding.Default)
            sw.WriteLine(Sve_ID)
            sw.WriteLine(BDUSS)
            sw.WriteLine(BDSP)
            sw.Close()
        End If
        End
    End Sub

    Private Sub BoomRadio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BoomRadio.Click
        TargetTextBox.Enabled = True
        TBTextBox.Enabled = False
        ForeNumeric.Enabled = False
        EndNumeric.Enabled = False
    End Sub

    Private Sub SendRadio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendRadio.Click
        TargetTextBox.Enabled = False
        TBTextBox.Enabled = True
        ForeNumeric.Enabled = True
        EndNumeric.Enabled = True
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        WayComboBox.SelectedIndex = 0
    End Sub
End Class
