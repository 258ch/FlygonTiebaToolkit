#ifdef _DEBUG
#pragma comment(lib, "../lib/XCGUId.lib")
#else
#pragma comment(lib, "../lib/XCGUI.lib")
#endif

#include "../lib/xcgui.h"

#include <string>
#include <vector>
#include <stdexcept>
using namespace std;

#include "MyLib\IDStruct.h"

#ifndef MAINFORM_H
#define MAINFORM_H

class MainForm : public CXEventMsg
{
public:
	MainForm();
	void show();
	void hide();

private:
	//Controls
	HWINDOW _MainForm;
	HELE TBLabel;
	HELE TBText;
	HELE WayLabel;
	HELE WayCombo;
	HELE MJLabel;
	HELE MJText;
	HELE MJButton;
	HELE TrLabel;
	HELE TrNumeric;
	HELE StLabel;
	HELE StNumeric;
	HELE FlLabel;
	HELE FlNumeric;
	HELE DelayLabel;
	HELE DelayNumeric;
	HELE ProBar;
	HELE AuthLink;
	HELE ForumLink;
	HELE StartButton;
	HELE StopButton;

	//args
	int StartIndex;
	int EndIndex;
	volatile int EndCount;
	int TrNum;
	int Delay;
	int FollowMode; //0:http 1:wap 2:client 3:random
	volatile int Success;
	string Target;
	vector<ID> IDList;
	volatile bool NdStop;
	string Portrait;
	string UID;

	//callbacks
	BOOL MJButton_OnClick(HELE hEle,HELE hEleEvent);
	BOOL StartButton_OnClick(HELE hEle,HELE hEleEvent);
	BOOL StopButton_OnClick(HELE hEle,HELE hEleEvent);
	BOOL AuthLink_OnClick(HELE hEle,HELE hEleEvent);
	BOOL ForumLink_OnClick(HELE hEle,HELE hEleEvent);

	static void Follow(int *arglist);
	static void FollowMain(MainForm *p);
	void FollowEnd();
	void ReadMJ(const string &filename);

	//avoid copying
	MainForm(MainForm &w);
	MainForm &operator=(MainForm &w);
};
#endif