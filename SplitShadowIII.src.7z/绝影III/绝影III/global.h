#include "MyLib\console.h"

extern Console csl;