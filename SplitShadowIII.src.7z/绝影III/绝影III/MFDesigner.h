#define MF_W 435
#define MF_H 221
#define MF_T L"ˢ�ۻ�����ӰIII - ����"

#define TBLBL_X 12
#define TBLBL_Y 15
#define TBLBL_W 29
#define TBLBL_H 20
#define TBLBL_T L"ID"

#define TBTXT_X 59
#define TBTXT_Y 12
#define TBTXT_W 94
#define TBTXT_H 21

#define WAYLBL_X 161
#define WAYLBL_Y 16
#define WAYLBL_W 29
#define WAYLBL_H 20
#define WAYLBL_T L"��ʽ"

#define WAYCB_X 196
#define WAYCB_Y 12
#define WAYCB_W 69
#define WAYCB_H 20

#define MJLBL_X 12
#define MJLBL_Y 48
#define MJLBL_W 29
#define MJLBL_H 20
#define MJLBL_T L"����"

#define MJTXT_X 59
#define MJTXT_Y 45
#define MJTXT_W 286
#define MJTXT_H 21
#define MJTXT_T L"��ѡ��..."

#define MJBTN_X 351
#define MJBTN_Y 44
#define MJBTN_W 39
#define MJBTN_H 21
#define MJBTN_T L"ѡ��"

#define TRLBL_X 12
#define TRLBL_Y 80
#define TRLBL_W 41
#define TRLBL_H 20
#define TRLBL_T L"�߳���"

#define TRNUM_X 59
#define TRNUM_Y 75
#define TRNUM_W 43
#define TRNUM_H 21
#define TRNUM_V 5

#define STLBL_X 108
#define STLBL_Y 80
#define STLBL_W 53
#define STLBL_H 20
#define STLBL_T L"��ʼλ��"

#define STNUM_X 167
#define STNUM_Y 75
#define STNUM_W 43
#define STNUM_H 21
#define STNUM_V 1

#define FLLBL_X 216
#define FLLBL_Y 80
#define FLLBL_W 41
#define FLLBL_H 20
#define FLLBL_T L"��ע��"

#define FLNUM_X 263
#define FLNUM_Y 75
#define FLNUM_W 43
#define FLNUM_H 21
#define FLNUM_V 420

#define DLYLBL_X 312
#define DLYLBL_Y 70
#define DLYLBL_W 29
#define DLYLBL_H 30
#define DLYLBL_T L"���\n(ms)"

#define DLYNUM_X 347
#define DLYNUM_Y 75
#define DLYNUM_W 43
#define DLYNUM_H 21
#define DLYNUM_V 0

#define PROBAR_X 14
#define PROBAR_Y 102
#define PROBAR_W 376
#define PROBAR_H 23
#define PROBAR_V 0

#define AULNK_X 12
#define AULNK_Y 134
#define AULNK_W 53
#define AULNK_H 20
#define AULNK_T L"��ϵ����"

#define FRLNK_X 71
#define FRLNK_Y 134
#define FRLNK_W 53
#define FRLNK_H 20
#define FRLNK_T L"��ȡ����"

#define STABTN_X 181
#define STABTN_Y 131
#define STABTN_W 84
#define STABTN_H 27
#define STABTN_T L"��ʼ"

#define STOBTN_X 307
#define STOBTN_Y 131
#define STOBTN_W 84
#define STOBTN_H 27
#define STOBTN_T L"ֹͣ"