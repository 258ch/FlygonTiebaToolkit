#include "MainForm.h"
#include "MFDesigner.h"
#include "resource.h"

#include <regex>
using namespace std;

#include "MyLib\md5.h"
#include "MyLib\MyFunction.h"
#include "MyLib\WizardHTTP.h"
#include "MyLib\FileDlg.h"
#include "global.h"

//Follow Mode
#define FOLLOW_HTTP 0
#define FOLLOW_WAP 1
#define FOLLOW_CLIENT 2
#define FOLLOW_RANDOM 3

MainForm::MainForm()
{
	_MainForm = XWnd_CreateWindow(0, 0, MF_W, MF_H, MF_T, 0,
		XC_SY_DEFAULT & ~XC_SY_MAXIMIZE); //��������
	XWnd_SetIcon(_MainForm, LoadIcon(GetModuleHandle(0), MAKEINTRESOURCE(IDI_ICON1)), false);
	XWnd_SetIconSize(_MainForm, 16, 16);
	XWnd_SetTransparentAlpha (_MainForm, 200);
	XWnd_SetTransparentFlag(_MainForm, XC_WIND_TRANSPARENT_SHADOW);
	XWnd_EnableDragBorder(_MainForm, false);

	TBLabel = XStatic_Create(TBLBL_X, TBLBL_Y, TBLBL_W, TBLBL_H, TBLBL_T, _MainForm);

	TBText = XEdit_Create(TBTXT_X, TBTXT_Y, TBTXT_W, TBTXT_H, _MainForm);

	WayLabel = XStatic_Create(WAYLBL_X, WAYLBL_Y, WAYLBL_W, WAYLBL_H, WAYLBL_T, _MainForm);

	WayCombo = XComboBox_Create(WAYCB_X, WAYCB_Y, WAYCB_W, WAYCB_H, _MainForm);
	XComboBox_AddString(WayCombo, L"http");
	XComboBox_AddString(WayCombo, L"wap");
	XComboBox_AddString(WayCombo, L"client");
	XComboBox_AddString(WayCombo, L"���");
	XComboBox_EnableEdit(WayCombo, false);
	XComboBox_SetSelectItem(WayCombo, 0);

	MJLabel = XStatic_Create(MJLBL_X, MJLBL_Y, MJLBL_W, MJLBL_H, MJLBL_T, _MainForm);

	MJText = XEdit_Create(MJTXT_X, MJTXT_Y, MJTXT_W, MJTXT_H, _MainForm);
	XEdit_SetText(MJText, MJTXT_T);
	XEle_EnableEle(MJText, false);

	MJButton = XBtn_Create(MJBTN_X, MJBTN_Y, MJBTN_W, MJBTN_H, MJBTN_T, _MainForm);
	XCGUI_RegEleEvent(MJButton, XE_BNCLICK, &MainForm::MJButton_OnClick);

	TrLabel = XStatic_Create(TRLBL_X, TRLBL_Y, TRLBL_W, TRLBL_H, TRLBL_T, _MainForm);

	TrNumeric = XEdit_Create(TRNUM_X, TRNUM_Y, TRNUM_W, TRNUM_H, _MainForm);
	XEdit_EnableNumber(TrNumeric, true);
	XEdit_SetInt(TrNumeric, TRNUM_V);

	StLabel = XStatic_Create(STLBL_X, STLBL_Y, STLBL_W, STLBL_H, STLBL_T, _MainForm);

	StNumeric = XEdit_Create(STNUM_X, STNUM_Y, STNUM_W, STNUM_H, _MainForm);
	XEdit_EnableNumber(StNumeric, true);
	XEdit_SetInt(StNumeric, STNUM_V);

	FlLabel = XStatic_Create(FLLBL_X, FLLBL_Y, FLLBL_W, FLLBL_H, FLLBL_T, _MainForm);

	FlNumeric = XEdit_Create(FLNUM_X, FLNUM_Y, FLNUM_W, FLNUM_H, _MainForm);
	XEdit_EnableNumber(FlNumeric, true);
	XEdit_SetInt(FlNumeric, FLNUM_V);

	DelayLabel = XStatic_Create(DLYLBL_X, DLYLBL_Y, DLYLBL_W, DLYLBL_H, DLYLBL_T, _MainForm);

	DelayNumeric = XEdit_Create(DLYNUM_X, DLYNUM_Y, DLYNUM_W, DLYNUM_H, _MainForm);
	XEdit_EnableNumber(DelayNumeric, true);
	XEdit_SetInt(DelayNumeric, DLYNUM_V);

	ProBar = XProgBar_Create(PROBAR_X, PROBAR_Y, PROBAR_W, PROBAR_H, true, _MainForm);
	XProgBar_SetPos(ProBar, PROBAR_V);

	AuthLink = XTextLink_Create(AULNK_X, AULNK_Y, AULNK_W, AULNK_H, AULNK_T, _MainForm);
	XTextLink_ShowUnderline(AuthLink, true, true);
	XCGUI_RegEleEvent(AuthLink, XE_BNCLICK, &MainForm::AuthLink_OnClick);

	ForumLink = XTextLink_Create(FRLNK_X, FRLNK_Y, FRLNK_W, FRLNK_H, FRLNK_T, _MainForm);
	XTextLink_ShowUnderline(ForumLink, true, true);
	XCGUI_RegEleEvent(ForumLink, XE_BNCLICK, &MainForm::ForumLink_OnClick);

	StartButton = XBtn_Create(STABTN_X, STABTN_Y, STABTN_W, STABTN_H, STABTN_T, _MainForm);
	XCGUI_RegEleEvent(StartButton, XE_BNCLICK, &MainForm::StartButton_OnClick);

	StopButton = XBtn_Create(STOBTN_X, STOBTN_Y, STOBTN_W, STOBTN_H, STOBTN_T, _MainForm);
	XEle_EnableEle(StopButton, false);
	XCGUI_RegEleEvent(StopButton, XE_BNCLICK, &MainForm::StopButton_OnClick);

}

void MainForm::show()
{
	XWnd_ShowWindow(_MainForm,SW_SHOW); //��ʾ����
}

void MainForm::hide()
{
	XWnd_ShowWindow(_MainForm,SW_HIDE); 
}

BOOL MainForm::MJButton_OnClick(HELE hEle,HELE hEleEvent)
{
	try
	{
		FileDlg ofd;
		ofd.SetDefExt("*.sve");
		ofd.SetFilter("icid�ļ�(*.icid)\0*.icid\0\0");
		if(ofd.show()) ReadMJ(ofd.GetFile());
	}
	catch(exception &ex)
	{
		csl.Println(Red, ex.what(), true);
	}
	return 0;
}

BOOL MainForm::StartButton_OnClick(HELE hEle,HELE hEleEvent)
{
	try
	{
		XEle_EnableEle(StartButton, false);
		if(!IDList.size()) throw exception("�޿������ף�");
		//Ŀ��ID��ʼ��
		int size = XEdit_GetTextLength(TBText);
		if(!size) throw exception("������Ŀ��ID��");
		wchar_t *buff = new wchar_t[size + 1];
		XEdit_GetText(TBText, buff, size);
		buff[size] = 0;
		this->Target = w2m(buff);
		delete[] buff;
		//������ʼ��
		FollowMode = XComboBox_GetSelectItem(WayCombo);
		TrNum = XEdit_GetInt(TrNumeric);
		Delay = XEdit_GetInt(DelayNumeric);
		StartIndex = XEdit_GetInt(StNumeric) - 1;
		if(StartIndex < 0 || StartIndex >= IDList.size()) 
		{
			StartIndex = 0;
			csl.Println(Yellow, "�������������������á�");
		}
		EndIndex = XEdit_GetInt(FlNumeric) + StartIndex - 1;
		if(EndIndex >= IDList.size()|| EndIndex < StartIndex)
			EndIndex = IDList.size() - 1;
		NdStop = false;
		Success = 0;
		EndCount = TrNum;
		XProgBar_SetPos(ProBar, 10);
		XProgBar_SetRange(ProBar, EndIndex - StartIndex + 1);
		XEle_RedrawEle(ProBar, true);
		//�����߳�
		HANDLE htr = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)&MainForm::FollowMain, this, 0, 0);
		CloseHandle(htr);

		XEle_EnableEle(StopButton, true);
	}
	catch(exception &ex)
	{
		csl.Println(Red, ex.what());
		XEle_EnableEle(StartButton, true);
	}
	return 0;
}

BOOL MainForm::StopButton_OnClick(HELE hEle,HELE hEleEvent)
{
	this->NdStop = true;
	csl.Println(Yellow, "�û���ֹ������ȴ���ǰ�߳̽�����");
	return 0;
}

BOOL MainForm::AuthLink_OnClick(HELE hEle,HELE hEleEvent)
{
	ShellExecuteA(0, 0, "http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes", 0, 0, 0);
	return 0;
}

BOOL MainForm::ForumLink_OnClick(HELE hEle,HELE hEleEvent)
{
	ShellExecuteA(0, 0, "http://www.258ch.com/forum-48-1.html", 0, 0, 0);
	return 0;
}

void MainForm::Follow(int *arglist)
{
	MainForm *p = (MainForm *)arglist[0];
	int index = arglist[1];

	WizardHTTP wh;
	wh.SetDefaultHeader(p->FollowMode == FOLLOW_CLIENT);

	for(int i = p->StartIndex + index; i <= p->EndIndex; i += p->TrNum)
	{
		try
		{
			if(p->NdStop) break;
			XProgBar_SetPos(p->ProBar, XProgBar_GetPos(p->ProBar) + 1);
			XEle_RedrawEle(p->ProBar, true);
			//����cookie
			string &cookie = p->IDList.at(i).Cookie;
			if(p->FollowMode == FOLLOW_CLIENT || p->FollowMode == FOLLOW_RANDOM)
			{
				const regex re("BDUSS=.{192}");
				//regex_search:����ȫƥ�� regex_match:��ȫƥ��
				smatch rm;
				if(!regex_search(cookie, rm, re))
					throw exception("Cookie��ʽ����");
				cookie = rm[0]; //����ƥ��ģʽȡ����Ϳ���
			}
			wh.SetHeader("Cookie", cookie);
			wh.SetCharset(CP_GBK);
			//��ȡid��Ϣ
			string retstr = wh.HTTPGet("http://tieba.baidu.com/i/sys/user_json?un=" + UrlEncoding(p->Target));
			int left = retstr.find("tbs\":") + 6;
			int right = retstr.find('\"', left);
			string tbs = retstr.substr(left, right - left);
			//��ʼˢ��
			bool is_succeed = false;
			string lasterr = "";
			if(p->FollowMode == FOLLOW_RANDOM)
			{
				int ran = GetRandom(1, 3);
				if(ran == 1) goto Label_HTTP;
				else if(ran == 2) goto Label_Wap;
				else goto Label_Client;
			}
			else if(p->FollowMode == FOLLOW_HTTP)
			{
Label_HTTP:		string stamp = GetStamp();
				string poststr = "cmd=follow&tbs=" + tbs + "&portrait=" + p->Portrait;
				retstr = wh.HTTPPost("http://tieba.baidu.com/i/commit?stamp=" + stamp, poststr);
				left = retstr.find("error_no") + 10;
				right = retstr.find(',', left);
				string errorno = retstr.substr(left, right - left);
				if(errorno == "0") is_succeed = true;
				else
				{
					is_succeed = false;
					left = retstr.find("_info") + 8;
					right = retstr.find('\"', left);
					string errmsg = retstr.substr(left, right - left);
					lasterr = UnicodeDeco(errmsg);
				}
				
			}
			else if(p->FollowMode == FOLLOW_WAP)
			{
Label_Wap:		wh.SetCharset(CP_UTF8);
		        retstr = wh.HTTPGet("http://wapp.baidu.com/i/" + p->UID + "?op=follow&it=2&portrait=" + p->Portrait + "&pn=&rop=2&lp=7002&tbs=" + tbs + "&ssid=0&from=0&uid=&pu=&bd_page_type=1&pinf=");
				left = retstr.find("light\">") + 7;
				right = retstr.find('<', left);
				string tmp = retstr.substr(left, right - left);
				if(tmp.find("��ע�ɹ�") != -1) is_succeed = true;
				else
				{
					is_succeed = false;
					lasterr = tmp;
				}
			}
			else if(p->FollowMode == FOLLOW_CLIENT)
			{
Label_Client:	string cid = GetStampAndroid();
				string poststr = cookie + "_client_id=" + cid + "_client_type=2_client_version=1.0.1_phone_imei=000000000000000from=tiebanet_type=1portrait=" + p->Portrait + "tbs=" + tbs + "tiebaclient!!!";
				string sign = MD5Encrypt(poststr);
				poststr = cookie + "&_client_id=" + cid + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=tieba&net_type=1&portrait=" + p->Portrait + "&tbs=" + tbs + "&sign=" + sign;
				retstr = wh.HTTPPost("http://c.tieba.baidu.com/c/c/user/follow", poststr);
				left = retstr.find("error_code") + 12;
				right = retstr.find(',', left);
				string errcode = retstr.substr(left, right - left);
				if(errcode == "0") is_succeed = true;
				else
				{
					is_succeed = false;
					left = retstr.find("error_msg") + 12;
					right = retstr.find('\"', left);
					string errmsg = retstr.substr(left, right - left);
					lasterr = UnicodeDeco(errmsg);
				}

			}
			else throw exception("ˢ��ģʽ����");
			//p->lock.Enter();
			if(is_succeed)
			{
				p->Success += 1;
				csl.Println(Green, p->IDList.at(i).UN + " ��ע�ɹ���");
			}
			else
			{
				csl.Println(Red, p->IDList.at(i).UN + " ��עʧ�ܣ�" + lasterr);
			}
			//p->lock.Exit();
			Sleep(p->Delay);
		}
		catch(exception &ex)
		{
			csl.Println(Red, ex.what());
		}
	}
	p->EndCount -= 1;
	//if(!p->EndCount) p->FollowEnd();
}

void MainForm::FollowMain(MainForm *p)
{
	try
	{
		WizardHTTP wh;
		wh.SetDefaultHeader();
		//��ȡid��Ϣ
		string retstr = wh.HTTPGet("http://tieba.baidu.com/i/sys/user_json?un=" + UrlEncoding(p->Target));
		int left = retstr.find("id\":") + 4;
		int right = retstr.find(',',left);
		p->UID = retstr.substr(left, right - left);
		left = retstr.find("portrait") + 11;
		right = retstr.find('\"', left);
		p->Portrait = retstr.substr(left, right - left);

		int *arglists = new int[p->TrNum * 2];
		//�����߳�
		for(int i = 0; i < p->TrNum; i++)
		{
			arglists[i * 2] = (int)p;
			arglists[i * 2 + 1] = i;
			HANDLE htr = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)&MainForm::Follow, &arglists[i * 2], 0, 0);
			CloseHandle(htr);
		}

		while(p->EndCount) Sleep(200);

		delete[] arglists;
	}
	catch(exception &ex) {csl.Println(Red, ex.what());}

	p->FollowEnd();
}

void MainForm::FollowEnd()
{
	csl.Println(Green, "�������������" + itos(this->EndIndex - this->StartIndex + 1) + "�����ף��ɹ�" + itos(this->Success) + "����");
	XEle_EnableEle(this->StartButton, true);
	XEle_EnableEle(this->StopButton, false);
}

void MainForm::ReadMJ(const string& filename)
{
	IDList.clear();
	ifstream ifs(filename, ios::in);
	if(!ifs) throw exception("�ļ���ʧ��...");
	XEdit_SetText(MJText, (wchar_t *)m2w(filename).c_str());
	while(!ifs.eof())
	{
		string tmp;
		ifs >> tmp;
		int left = tmp.find(",");
        if (left == -1) continue;
        string un = tmp.substr(1, left - 1);
        if (un == "") continue; //�û�����ȡ���
        left += 1;
        int right = tmp.find(")", left);
        if (right == -1) continue;
        string pw = tmp.substr(left, right - left); //�����ȡ���
        right += 2;
        string cookie = tmp.substr(right, tmp.size() - 1 - right); //cookie��ȡ���
		IDList.push_back(ID(un, pw, cookie));
	}
	ifs.close();
	if(IDList.size() == 0) throw exception("�޿������ף�");
	csl.Println(Green, "���׶�ȡ��ϣ�������" + itos(IDList.size()) + "�����ף�");
}