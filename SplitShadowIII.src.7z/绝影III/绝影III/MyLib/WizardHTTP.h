/*********************************
 * C++ WizardHTTP - ���� - CHI
 * 2013.2.12
 * ����WinHTTP��HTTP����ʵ��
 *********************************/

#include"WizardClient.h"

#include<winhttp.h>
#pragma comment(lib, "winhttp.lib")

#ifndef WIZARDHTTP_H
#define WIZARDHTTP_H

class WizardHTTP : public WizardClient
{
public:

	virtual string HTTPSubmit(const string& URL, const string& method = "GET", const string& data = "");
	virtual vector<char> HTTPSubmitData(const string& URL, const string& method = "GET", const string& data = "");
};
#endif