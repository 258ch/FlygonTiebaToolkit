#include<string>
using namespace std;

#ifndef ID_STRUCT_H
#define ID_STRUCT_H

struct ID
{
	string UN;
	string PW;
	string Cookie;

	ID(const string& u, const string& p, const string& c)
	{
		this->UN = u;
		this->PW = p;
		this->Cookie = c;
	}
};
#endif