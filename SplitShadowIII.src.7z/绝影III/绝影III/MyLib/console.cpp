#include"console.h"


Console::Console()
{
	AllocConsole();
	this->hConsole = GetStdHandle(-11);
	this->title = "";
}	

Console::~Console()
{
	FreeConsole();
}

string Console::GetTitle() const
{
	return this->title;
}

void Console::SetTitle(const string& title)
{
	this->title = title;
	SetConsoleTitleA(title.c_str());
}
void Console::Print(ConsoleColor color, const string& content, bool ndtime) const
{
	SetConsoleTextAttribute(this->hConsole, color);
	string tmp = "";
	if(ndtime)
	{
		SYSTEMTIME SystemTime;
		GetLocalTime(&SystemTime);
		char buff[64];
		GetTimeFormatA(0, 0, &SystemTime, "HH:mm:ss", buff, 64);
		tmp += "[";
		tmp += buff;
		tmp += "] ";
	}
	tmp += content;
	WriteConsoleA(this->hConsole, tmp.c_str(), tmp.size(), 0, 0);
}

void Console::Println(ConsoleColor color, const string& content, bool ndtime) const
{
	this->Print(color, content + "\n", ndtime);
}