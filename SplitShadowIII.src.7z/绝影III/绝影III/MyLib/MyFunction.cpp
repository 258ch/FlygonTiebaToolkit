#include"MyFunction.h"
//#include"WizardInet.h"

URI SplitURL(const string& URL)
{
	string host = "", sub = "";
	int port = 0;

	int left = URL.find("://");
	if(left == -1) throw exception("URL��ʽ����");
	string tmp = URL.substr(0, left);
	if(tmp == "http")
	{
		port = 80;
	}
	else if(tmp == "https")
	{
		port = 443;
	}
	else throw exception("URL��ʽ����");
	left += 3;
	int right = URL.find("/", left);
	if(right == -1)
	{
		host = URL.substr(left, URL.size() - left);
		sub = "/";
	}
	else
	{
		host = URL.substr(left, right - left);
		right += 1;
		sub = URL.substr(right, URL.size() - right);
	}
	return URI(host, sub, port);
}
  
string CharsetConvert(const string& istr, int pc1, int pc2)
{
	size_t n = MultiByteToWideChar(pc1, 0, istr.c_str(), -1, 0, 0);
	wchar_t *wp =  new wchar_t[n + 1];
	n = MultiByteToWideChar(pc1, 0, istr.c_str(), -1, wp, n);
	wp[n] = 0;
	n = WideCharToMultiByte(pc2, 0, wp, -1, 0, 0, 0, 0);
	char *p = new char[n + 1];
	n = WideCharToMultiByte(pc2, 0, wp, -1, p, n, 0, 0);
	p[n] = 0;
	string ostr(p);
	delete[] wp;
	delete[] p;
	return ostr;
}

string UrlEncoding(const string& istr, int enco)
{
	stringstream ss;
	string idata;
	if(enco != CP_ACP || enco != CP_GBK)
		idata = CharsetConvert(istr, CP_ACP, enco);
	else
		idata = istr;
	for(int i = 0; i < idata.size(); i++)
	{
		int tmp = idata.at(i);
		if(tmp < 0) tmp += 256;
		if((tmp >= 'A' && tmp <= 'Z') || (tmp >= 'a' && tmp <= 'z') || (tmp >= '0' && tmp <= '9'))
		{
			ss<<(char)tmp;
		}
		else
		{
			ss<<"%"<<hex<<tmp;
		}
	}
	return ss.str();
}

wstring m2w(const string& s)
{
	size_t n = MultiByteToWideChar(0, 0, s.c_str(), -1, 0, 0);
	wchar_t *wp = new wchar_t[n + 1];
	n = MultiByteToWideChar(0, 0, s.c_str(), -1, wp, n);
	wp[n] = 0;
	wstring ws(wp);
	delete[] wp;
	return ws;
}

string w2m(const wstring& ws)
{
	size_t n = WideCharToMultiByte(0, 0, ws.c_str(), -1, 0, 0, 0, 0);
	char *p = new char[n + 1];
	n = WideCharToMultiByte(0, 0, ws.c_str(), -1, p, n, 0, 0);
	p[n] = 0;
	string s(p);
	delete[] p;
	return s;
}

short ChrW(wchar_t wc)
{
	short retn = 0;
	WideCharToMultiByte(0, 0, &wc, 1, (char *)&retn, 2, 0, 0);
	return retn;
}

wchar_t AscW(short chr)
{
	wchar_t retn = 0;
	MultiByteToWideChar(0, 0, (char *)chr, 2, &retn, 1);
	return retn;
}

string GetMid(const string& str, const string& left, const string& right, int start)
{
	int l = str.find(left, start);
	if(l == -1) return "";
	l += left.size();
	int r = str.find(right, l);
	if(r == -1) return "";
	string ret = str.substr(l, r - l);
	return ret;
}

void DoEvent()
{
    MSG msg;
    while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
    {
        if(!IsDialogMessage(0, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
}

int GetRandom(int min, int max)
{
	double rnd = (double)rand() / 0x8000; //[0,1)
	int length = max - min + 1;
	rnd *= length; //[0,(max-min + 1))
	rnd += min; //[min,(max + 1))
	return rnd; //[min,max]
}

string GetStampAndroid()
{
	int stamp1 = GetRandom(10000, 19999);
	int stamp2 = GetRandom(1000, 9999);
	int stamp3 = GetRandom(1000, 9999);
	int stamp4 = GetRandom(100, 999);
	stringstream ss;
	ss<<"wappc_"<<stamp1<<stamp2<<stamp3<<"_"<<stamp4;
	return ss.str();
}

string GetUid()
{
	int stamp1 = GetRandom(10000, 19999);
	int stamp2 = GetRandom(1000, 9999);
	int stamp3 = GetRandom(1000, 9999);
	int stamp4 = GetRandom(100, 999);
	stringstream ss;
	ss<<"wapp_"<<stamp1<<stamp2<<stamp3<<"_"<<stamp4;
	return ss.str();
}

string GetStamp()
{
	stringstream ss;
	ss<<time(0);
	return ss.str();
}

string UnicodeDeco(const string& unicode)
{
	stringstream ss;
	for(int i = 0; i < unicode.size(); i++)
	{
		if(i > unicode.size() - 6)
		{
			ss<<unicode.at(i);
		}
		else if(unicode.substr(i, 2) == "\\u")
		{
			string tmp = unicode.substr(i + 2, 4);
			int charcode = stoi(tmp, 0, 16);
			short asc = ChrW(charcode);
			char *p = (char *)&asc;
			ss<<p[0];
			if(p[1]) ss<<p[1];
			i += 5;
		}
		else
		{
			ss<<unicode.at(i);
		}
	}
	return ss.str();
}

int TheNext(int i, int steplen, int max)
{
	if(max == 0) throw exception("��������Ϊ��");
	return (i + steplen) % max;
}
string Base64Encrypt(const string& str)
{
    //�����
    const char EncodeTable[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    //����ֵ
    string strEncode;
    const char *Data = str.c_str();
    unsigned char Tmp[4]={0};
    int LineLength=0;
	for(int i = 0; i < (int)(str.size() / 3); i++)
    {
        Tmp[1] = *Data++;
        Tmp[2] = *Data++;
        Tmp[3] = *Data++;
        strEncode += EncodeTable[Tmp[1] >> 2];
        strEncode += EncodeTable[((Tmp[1] << 4) | (Tmp[2] >> 4)) & 0x3F];
        strEncode += EncodeTable[((Tmp[2] << 2) | (Tmp[3] >> 6)) & 0x3F];
        strEncode += EncodeTable[Tmp[3] & 0x3F];
        if(LineLength+=4,LineLength==76) {strEncode+="\r\n";LineLength=0;}
    }
    //��ʣ�����ݽ��б���
    int Mod = str.size() % 3;
    if(Mod == 1)
    {
        Tmp[1] = *Data++;
        strEncode += EncodeTable[(Tmp[1] & 0xFC) >> 2];
        strEncode += EncodeTable[((Tmp[1] & 0x03) << 4)];
        strEncode += "==";
    }
    else if(Mod==2)
    {
        Tmp[1] = *Data++;
        Tmp[2] = *Data++;
        strEncode += EncodeTable[(Tmp[1] & 0xFC) >> 2];
        strEncode += EncodeTable[((Tmp[1] & 0x03) << 4) | ((Tmp[2] & 0xF0) >> 4)];
        strEncode += EncodeTable[((Tmp[2] & 0x0F) << 2)];
        strEncode += "=";
    }
    return strEncode;
}

string TimeString()
{
	SYSTEMTIME SystemTime;
	GetLocalTime(&SystemTime);
	char buff[64];
	GetTimeFormatA(0, 0, &SystemTime, "HH:mm:ss", buff, 64);
	string time = "[";
	time += buff;
	time += "] ";
	return time;
}

string GetCurrentDirectoryS()
{
	int size = GetCurrentDirectoryA(0, 0);
	char *buff = new char[size + 1];
	size = GetCurrentDirectoryA(size, buff);
	buff[size] = 0;
	string retn(buff);
	delete[] buff;
	return retn;

}

string GetPrivateProfileStringS(const char *appname, const char *keyname, const char *default, const char *filename)
{
	int size = GetPrivateProfileStringA(appname, keyname, default, 0, 0, filename);
	char *buff = new char[size + 1];
	size = GetPrivateProfileStringA(appname, keyname, default, buff, size, filename);
	buff[size] = 0;
	string retn(buff);
	delete[] buff;
	return retn;
}