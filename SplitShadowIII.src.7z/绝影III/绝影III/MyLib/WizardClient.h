/*********************************
 * C++ WizardClient - ���� - CHI
 * 2013.2.14
 * �ṩHTTP�����Լ�Э��ͷ�Ĺ���
 *********************************/

#include<string>
#include<vector>
#include<sstream>
using namespace std;

#include<Windows.h>

#include"MyFunction.h"

#define HTTPGet(URL) HTTPSubmit(URL)
#define HTTPPost(URL, data) HTTPSubmit(URL, "POST", data)
#define HTTPGetData(URL) HTTPSubmitData(URL)
#define HTTPPostData(URL, data) HTTPSubmitData(URL, "POST", data)

#ifndef WIZARDCLIENT_H
#define WIZARDCLIENT_H

class WizardClient
{
public:
	
	WizardClient();
	~WizardClient();

	//Ҫ��֤ÿ��ͷ�����ֲ��ظ�
	void SetHeader(const string& name, const string& value);
	string GetHeader(const string& name) const;
	void ClearHeader(const string& name);
	void ClearAllHeaders();
	void SetDefaultHeader(bool mobile = false);
	void Reset();

	void SetCharset(int newchar);
	int GetCharset() const;
	int GetTimeout() const;
	void SetTimeout(int newtime);
	string GetProxy() const;
	void SetProxy(const string& newproxy);
	string GetRethdr() const;
	bool GetAutoRedirect() const;
	void SetAutoRedirect(bool newauto);

protected:

	vector<Header> Headers;
	int Charset; // ���� CP_ACP CP_UTF7 CP_UTF8 ��
	int Timeout;
	string Proxy;
	string Rethdr;
	bool AutoRedirect;
	
private:
	

};

#endif