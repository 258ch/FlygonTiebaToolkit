#include<Windows.h>
#include<time.h>

#include<string>
#include<sstream>
using namespace std;

#define CP_GBK 936
#define CP_BIG5 950
#define CP_EN 437
#define CP_JP 932
#define CP_RU 866
#define CP_KR 949

#define itos(i) to_string((long long)(i))
#define utos(u) to_string((unsigned long long)(u))
#define dtos(d) to_string((long double)(d))

#define itows(i) to_wstring((long long)(i))
#define utows(u) to_wstring((unsigned long long)(u))
#define dtows(d) to_wstring((long double)(d))

#ifndef MYFUNCTION_H
#define MYFUNCTION_H

struct Header
{
	string name;
	string value;

	Header(const string& n, const string& v)
	{
		name = n;
		value = v;
	}
};

struct URI
{
	string Host;
	string SubAddr;
	int Port;

	URI(const string& h, const string& s, int p)
	{
		Host = h;
		SubAddr = s;
		Port = p;
	}
};

//����� ���� �ӵ�ַ �Ͷ˿�
URI SplitURL(const string& URL);

//���ֱ���
string UrlEncoding(const string& istr, int enco = CP_ACP);

//�����ת��
#define GBK2UTF8(GBK) CharsetConvert(GBK, CP_GBK, CP_UTF8)
#define UTF82GBK(UTF8) CharsetConvert(UTF8, CP_UTF8, CP_GBK)
string CharsetConvert(const string& istr, int pc1, int pc2);

//ascll unicode ����ת��
wstring m2w(const string& s);
string w2m(const wstring& ws);

//unicode�����ansi�ַ����ת��
short ChrW(wchar_t wc);
wchar_t AscW(short chr);

//����������
string GetMid(const string& str, const string& left, const string& right, int start = 0);
void DoEvent();
int GetRandom(int min, int max);
string GetStampAndroid();
string GetUid();
string UnicodeDeco(const string& unicode);
int TheNext(int i, int steplen, int max);
string Base64Encrypt(const string& str);
string GetStamp();
string TimeString();

string GetCurrentDirectoryS();
string GetPrivateProfileStringS(const char *appname, const char *keyname, const char *default, const char *filename);

#endif