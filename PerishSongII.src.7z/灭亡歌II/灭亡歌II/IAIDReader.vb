﻿Imports System.IO
Imports System.IO.Compression
Imports System.Text

Public Class IAIDReader

    Private Shared Function GZipDecompress(ByVal input As Byte()) As Byte()
        Dim ms As New MemoryStream(input)
        Dim gs As New GZipStream(ms, CompressionMode.Decompress)
        Dim output As New MemoryStream()
        CopyStream(gs, output, 4096)
        gs.Close()
        Return output.ToArray()
    End Function

    Private Shared Function GZipCompress(ByVal input As Byte()) As Byte()
        Dim ms As New MemoryStream(input)
        Dim gs As New GZipStream(ms, CompressionMode.Compress)
        Dim output As New MemoryStream()
        CopyStream(gs, output, 4096)
        gs.Close()
        Return output.ToArray()
    End Function

    Private Shared Sub CopyStream(ByVal st1 As Stream, ByVal st2 As Stream, ByVal bufflen As Integer)
        Dim num As Integer
        Dim buffer(bufflen - 1) As Byte
        While (True)
            num = st1.Read(buffer, 0, buffer.Length)
            If num = 0 Then Exit While
            st2.Write(buffer, 0, buffer.Length)
        End While
    End Sub

    Public Shared Function ReadIAID(ByVal filename As String) As String
        Dim outdata As Byte() = GZipDecompress(File.ReadAllBytes(filename))
        Return Encoding.Default.GetString(outdata)
    End Function

    Public Shared Sub WriteIAID(ByVal data As String, ByVal filename As String)
        Dim indata As Byte() = GZipCompress(Encoding.Default.GetBytes(data))
        File.WriteAllBytes(filename, indata)
    End Sub
End Class
