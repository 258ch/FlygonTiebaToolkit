﻿Imports System.IO
Imports System.IO.Compression
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading

Public Class Form1

    Private FileName As String = ""
    Private IDList As New List(Of ID)

    Public Declare Function IdixReadIdixFormFileA Lib "idix.dll" (ByVal filename As String) As Integer
    Public Declare Function IdixGetUserCount Lib "idix.dll" (ByVal hidix As Integer) As Integer
    Public Declare Sub IdixGetUserUsernameA Lib "idix.dll" (ByVal hidix As Integer, ByVal index As Integer, ByVal buffer As Byte(), ByVal bufflen As Integer)
    Public Declare Sub IdixGetUserCookieA Lib "idix.dll" (ByVal hidix As Integer, ByVal index As Integer, ByVal buffer As Byte(), ByVal bufflen As Integer)
    Public Declare Sub IdixGetUserPasswordA Lib "idix.dll" (ByVal hidix As Integer, ByVal index As Integer, ByVal buffer As Byte(), ByVal bufflen As Integer)
    Public Declare Function IdixClose Lib "idix.dll" (ByVal hidix As Integer) As Integer

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OutputButton.Click
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            FileName = SaveFileDialog1.FileName
            OutputTextBox.Text = FileName
        End If
    End Sub

    Private Sub StartConvert()
        Dim tmp As String = ""
        For Each x As ID In IDList
            tmp += "(" + x.UN + "," + x.PW + ")[" + x.Cookie + "]" + vbCrLf
        Next
        File.WriteAllText(FileName, tmp, Encoding.Default)
        MessageBox.Show("转换完毕！")
        StartButton.Enabled = True
    End Sub

    Private Sub InputButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputButton.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            InputTextBox.Text = OpenFileDialog1.FileName
            IDList.Clear()
            If Microsoft.VisualBasic.Right(OpenFileDialog1.FileName, 5) = ".iaid" Then
                Try
                    Dim tmp As String = IAIDReader.ReadIAID(OpenFileDialog1.FileName)
                    Dim ch As Char = Chr(0)
                    Dim re As New Regex(".*?:.*?:.*?")
                    If re.IsMatch(tmp) Then
                        ch = ":"
                    Else
                        re = New Regex(".*?" + Chr(0) + ".*?" + Chr(0) + ".*?")
                        If Not re.IsMatch(tmp) Then Throw New Exception("马甲格式错误！")
                    End If
                    Dim tmp2 As String() = Split(tmp, vbCrLf)
                    For Each x As String In tmp2
                        Dim tmp3 As String() = Split(x, ch)
                        If tmp3.Length > 2 Then
                            re = New Regex("BDUSS=.{192}")
                            Dim rm As Match = re.Match(tmp3(2))
                            If Not rm.Success Then Continue For
                            Dim cookie As String = rm.Value + ";"
                            Dim tmpid As New ID With {.UN = tmp3(0), .PW = tmp3(1), .Cookie = cookie}
                            IDList.Add(tmpid)
                        End If
                    Next
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                    Exit Sub
                End Try
            Else '*.idix
                Dim hidix As Integer = IdixReadIdixFormFileA(OpenFileDialog1.FileName)
                Dim count As Integer = IdixGetUserCount(hidix)
                For i As Integer = 0 To count - 1
                    Dim buff(1024 - 1) As Byte
                    IdixGetUserUsernameA(hidix, i, buff, 1024)
                    Dim un As String = Encoding.Default.GetString(buff).Replace(Chr(0), "")
                    ReDim buff(1024 - 1)
                    IdixGetUserPasswordA(hidix, i, buff, 1024)
                    Dim pw As String = Encoding.Default.GetString(buff).Replace(Chr(0), "")
                    ReDim buff(1024 - 1)
                    IdixGetUserCookieA(hidix, i, buff, 1024)
                    Dim cookie As String = Encoding.Default.GetString(buff).Replace(Chr(0), "")
                    Dim tmpid As New ID With {.UN = un, .PW = pw, .Cookie = cookie}
                    IDList.Add(tmpid)
                Next
                IdixClose(hidix)
            End If
            MessageBox.Show("导入成功，共导入" + IDList.Count.ToString() + "个马甲。")
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If IDList.Count = 0 Then Throw New Exception("无可转换马甲！")
            If FileName = "" Then Throw New Exception("请选择导出文件！")
            Dim tr As New Thread(AddressOf StartConvert)
            tr.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub
End Class
