﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Text.RegularExpressions
Imports WindsTear.Utility
Imports WindsTear.TBOps
Imports SkinSharp

Public Class Form1

    Private Delay As Integer
    Private StartIndex As Integer
    Private NdStop As Boolean
    Private EndCount As Integer
    Private TrNum As Integer
    Private Success As Integer
    Private SW As StreamWriter

    Private IDList As New List(Of ID)
    Private TaskRunning As Boolean = False

    Private Skin As SkinH_Net


    Private Sub MJClearButton_Click(sender As System.Object, e As System.EventArgs) Handles MJClearButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请等待其他任务结束！")
            Exit Sub
        End If
        IDList.Clear()
        MJTextBox.Clear()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已清除。")
    End Sub

    Private Sub PrClearButton_Click(sender As System.Object, e As System.EventArgs)
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请等待其他任务结束！")
            Exit Sub
        End If
        'PrList.Clear()
        'PrTextBox.Clear()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "已清除。")
    End Sub

    'Private Sub PrSetButton_Click(sender As System.Object, e As System.EventArgs) Handles PrSetButton.Click
    '    If TaskRunning Then
    '        Console.ForegroundColor = ConsoleColor.Red
    '        Console.WriteLine(Time() + "请等待其他任务结束！")
    '        Exit Sub
    '    End If
    '    If PrOpenFileDialog.ShowDialog() = DialogResult.OK Then
    '        PrTextBox.Text = PrOpenFileDialog.FileName
    '        PrList.Clear()
    '        Dim tmp As String() = File.ReadAllLines(PrOpenFileDialog.FileName, Encoding.Default)
    '        PrList.AddRange(tmp)
    '        Console.ForegroundColor = ConsoleColor.Green
    '        Console.WriteLine(Time() + "导入完毕，共导入{0}个代理！", PrList.Count)
    '    End If
    'End Sub

    Private Sub MJSetButton_Click(sender As System.Object, e As System.EventArgs) Handles MJSetButton.Click
        If TaskRunning Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + "请等待其他任务结束！")
            Exit Sub
        End If
        If MJOpenFileDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            MJTextBox.Text = MJOpenFileDialog.FileName
            IDList.Clear()
            Dim tmp As String() = File.ReadAllLines(MJOpenFileDialog.FileName, Encoding.Default)
            For Each x As String In tmp
                Dim left As Integer = x.IndexOf(",")
                If left = -1 Then Continue For
                Dim un As String = x.Substring(1, left - 1)
                If un = "" Then Continue For
                left += 1
                Dim right As Integer = x.IndexOf(")", left)
                If right = -1 Then Continue For
                Dim pw As String = x.Substring(left, right - left)
                right += 2
                Dim cookie As String = x.Substring(right, x.Length - 1 - right)
                Dim tmpid As New ID With {.UN = un, .PW = pw, .Cookie = cookie}
                IDList.Add(tmpid)
            Next
            Console.ForegroundColor = ConsoleColor.Green
            Console.WriteLine(Time() + "导入完毕，共导入{0}个马甲！", IDList.Count)
        End If
    End Sub

    Private Sub StartButton_Click(sender As System.Object, e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            If TaskRunning Then Throw New Exception("请等待其他任务结束！")
            If IDList.Count = 0 Then Throw New Exception("请先选择马甲！")
            Delay = DelayNumeric.Value
            'Timeout = TimeoutNumeric.Value
            TrNum = TrNumeric.Value
            EndCount = TrNum
            StartIndex = StartNumeric.Value - 1
            If StartIndex > IDList.Count - 1 Then
                StartIndex = 0
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "超出马甲总数，已重置！")
            End If
            ProgressBar1.Maximum = IDList.Count - StartIndex
            ProgressBar1.Value = 0
            Success = 0
            NdStop = False
            SW = New StreamWriter(Directory.GetCurrentDirectory() + "\log.txt", True, Encoding.Default)

            Dim tr As New Thread(AddressOf WorkInit)
            tr.Start()
            TaskRunning = True
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub WorkInit()
        For i As Integer = 0 To TrNum - 1
            Dim tr As New Thread(AddressOf DoWork)
            tr.Start(i)
        Next

        While EndCount <> 0 : Thread.Sleep(200) : End While
        WorkEnd()
    End Sub

    Private Sub DoWork(ByVal index As Integer)
        Dim wc As New WizardHTTP

        For i As Integer = StartIndex + index To IDList.Count - 1 Step TrNum
            Try
                If NdStop Then Exit For
                ProgressBar1.Value += 1
                Dim tmp_id As ID = IDList(i)
                wc.Headers.Set(HttpRequestHeader.Cookie, tmp_id.Cookie)

                wc.SetDefaultHeader()
                Dim retstr As String = wc.DownloadString("http://yun.baidu.com/activity/spring/getlottery?channel=chunlei&clienttype=0&web=1&t=" + GetStamp())
                Dim left As Integer = retstr.IndexOf("errno")
                left += 7
                Dim right As Integer = retstr.IndexOf(",", left)
                If right = -1 Then right = retstr.IndexOf("}", left)
                Dim errno As String = retstr.Substring(left, right - left)

                If errno = "0" Then
                    left = retstr.IndexOf("prize_name") + 13
                    right = retstr.IndexOf("""", left)
                    Dim prize As String = retstr.Substring(left, right - left)
                    prize = UnicodeDeco(prize)
                    If prize <> "百度云100G容量" Then
                        SW.WriteLine(tmp_id.UN + " " + prize)
                    End If
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + tmp_id.UN + " 操作成功！奖品: " + prize)
                    Interlocked.Increment(Success)
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + tmp_id.UN + " 操作失败！错误代码: " + errno)
                End If
                Thread.Sleep(Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next
        Interlocked.Decrement(EndCount)
    End Sub

    Private Sub WorkEnd()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "任务结束，共用马甲{0}个，成功{1}个。", IDList.Count - StartIndex, Success)
        SW.Close()
        TaskRunning = False
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub StopButton_Click(sender As System.Object, e As System.EventArgs) Handles StopButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "请等待当前任务结束！")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.flygon.net")
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub

    Private Sub Form1_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        'TypeComboBox.SelectedIndex = 0

        Skin = New SkinH_Net
        Skin.AttachRes(My.Resources.Win8, My.Resources.Win8.Length, "", 0, 0, 0)
        Skin.SetAero(True)
    End Sub
End Class
