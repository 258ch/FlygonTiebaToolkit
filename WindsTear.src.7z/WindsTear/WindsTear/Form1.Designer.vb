﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MJTextBox = New System.Windows.Forms.TextBox()
        Me.MJSetButton = New System.Windows.Forms.Button()
        Me.MJClearButton = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.StartNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.MJOpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "马甲"
        '
        'MJTextBox
        '
        Me.MJTextBox.BackColor = System.Drawing.Color.White
        Me.MJTextBox.Location = New System.Drawing.Point(72, 24)
        Me.MJTextBox.Name = "MJTextBox"
        Me.MJTextBox.ReadOnly = True
        Me.MJTextBox.Size = New System.Drawing.Size(271, 21)
        Me.MJTextBox.TabIndex = 1
        '
        'MJSetButton
        '
        Me.MJSetButton.Location = New System.Drawing.Point(349, 22)
        Me.MJSetButton.Name = "MJSetButton"
        Me.MJSetButton.Size = New System.Drawing.Size(48, 23)
        Me.MJSetButton.TabIndex = 2
        Me.MJSetButton.Text = "设置"
        Me.MJSetButton.UseVisualStyleBackColor = True
        '
        'MJClearButton
        '
        Me.MJClearButton.Location = New System.Drawing.Point(403, 22)
        Me.MJClearButton.Name = "MJClearButton"
        Me.MJClearButton.Size = New System.Drawing.Size(48, 23)
        Me.MJClearButton.TabIndex = 3
        Me.MJClearButton.Text = "清除"
        Me.MJClearButton.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(184, 55)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 12)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "间隔(ms)"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(243, 52)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(100, 21)
        Me.DelayNumeric.TabIndex = 11
        '
        'StartNumeric
        '
        Me.StartNumeric.Location = New System.Drawing.Point(72, 52)
        Me.StartNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.StartNumeric.Name = "StartNumeric"
        Me.StartNumeric.Size = New System.Drawing.Size(100, 21)
        Me.StartNumeric.TabIndex = 13
        Me.StartNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 55)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 12)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "起始"
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(349, 51)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(102, 21)
        Me.StartButton.TabIndex = 16
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(349, 78)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(102, 21)
        Me.StopButton.TabIndex = 17
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(27, 106)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(424, 23)
        Me.ProgressBar1.TabIndex = 18
        '
        'MJOpenFileDialog
        '
        Me.MJOpenFileDialog.DefaultExt = "*。icid"
        Me.MJOpenFileDialog.FileName = "OpenFileDialog1"
        Me.MJOpenFileDialog.Filter = "数据文件(*.icid)|*.icid"
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(243, 79)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(100, 21)
        Me.TrNumeric.TabIndex = 20
        Me.TrNumeric.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(184, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(29, 12)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "线程"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(84, 82)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 21
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "更多工具"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(25, 82)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 22
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "联系作者"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(479, 152)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.TrNumeric)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.StartNumeric)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.DelayNumeric)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.MJClearButton)
        Me.Controls.Add(Me.MJSetButton)
        Me.Controls.Add(Me.MJTextBox)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "风之泪·百度云抽奖机 - 飞龙"
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MJTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MJSetButton As System.Windows.Forms.Button
    Friend WithEvents MJClearButton As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents StartNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents MJOpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel

End Class
