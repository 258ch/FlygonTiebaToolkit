﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TargetTextBox = New System.Windows.Forms.TextBox()
        Me.FITextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ChooseButton = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TrNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.StartNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FollowNumeric = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DelayNumeric = New System.Windows.Forms.NumericUpDown()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.FollowComboBox = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FollowNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "目标"
        '
        'TargetTextBox
        '
        Me.TargetTextBox.Location = New System.Drawing.Point(59, 12)
        Me.TargetTextBox.MaxLength = 14
        Me.TargetTextBox.Name = "TargetTextBox"
        Me.TargetTextBox.Size = New System.Drawing.Size(94, 21)
        Me.TargetTextBox.TabIndex = 1
        '
        'FITextBox
        '
        Me.FITextBox.BackColor = System.Drawing.Color.White
        Me.FITextBox.Location = New System.Drawing.Point(59, 45)
        Me.FITextBox.Name = "FITextBox"
        Me.FITextBox.ReadOnly = True
        Me.FITextBox.Size = New System.Drawing.Size(286, 21)
        Me.FITextBox.TabIndex = 2
        Me.FITextBox.Text = "（支持拖放和选择）"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "马甲"
        '
        'ChooseButton
        '
        Me.ChooseButton.Location = New System.Drawing.Point(351, 44)
        Me.ChooseButton.Name = "ChooseButton"
        Me.ChooseButton.Size = New System.Drawing.Size(39, 21)
        Me.ChooseButton.TabIndex = 4
        Me.ChooseButton.Text = "选择"
        Me.ChooseButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "线程数"
        '
        'TrNumeric
        '
        Me.TrNumeric.Location = New System.Drawing.Point(59, 75)
        Me.TrNumeric.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.TrNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.TrNumeric.Name = "TrNumeric"
        Me.TrNumeric.Size = New System.Drawing.Size(43, 21)
        Me.TrNumeric.TabIndex = 6
        Me.TrNumeric.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(108, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 12)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "起始位置"
        '
        'StartNumeric
        '
        Me.StartNumeric.Location = New System.Drawing.Point(167, 75)
        Me.StartNumeric.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.StartNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.StartNumeric.Name = "StartNumeric"
        Me.StartNumeric.Size = New System.Drawing.Size(43, 21)
        Me.StartNumeric.TabIndex = 8
        Me.StartNumeric.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(216, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 12)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "关注数"
        '
        'FollowNumeric
        '
        Me.FollowNumeric.Location = New System.Drawing.Point(263, 75)
        Me.FollowNumeric.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.FollowNumeric.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.FollowNumeric.Name = "FollowNumeric"
        Me.FollowNumeric.Size = New System.Drawing.Size(43, 21)
        Me.FollowNumeric.TabIndex = 10
        Me.FollowNumeric.Value = New Decimal(New Integer() {420, 0, 0, 0})
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(312, 80)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 12)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "延迟"
        '
        'DelayNumeric
        '
        Me.DelayNumeric.Location = New System.Drawing.Point(347, 75)
        Me.DelayNumeric.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.DelayNumeric.Name = "DelayNumeric"
        Me.DelayNumeric.Size = New System.Drawing.Size(43, 21)
        Me.DelayNumeric.TabIndex = 12
        '
        'ProgressBar1
        '
        Me.ProgressBar1.BackColor = System.Drawing.Color.White
        Me.ProgressBar1.Location = New System.Drawing.Point(14, 102)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(376, 23)
        Me.ProgressBar1.Step = 1
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgressBar1.TabIndex = 13
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(181, 131)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(84, 27)
        Me.StartButton.TabIndex = 14
        Me.StartButton.Text = "开始"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Enabled = False
        Me.StopButton.Location = New System.Drawing.Point(307, 131)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(83, 27)
        Me.StopButton.TabIndex = 15
        Me.StopButton.Text = "停止"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "*.icid"
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "数据文件(*.icid)|*.icid"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(12, 138)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel1.TabIndex = 17
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "联系作者"
        '
        'FollowComboBox
        '
        Me.FollowComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FollowComboBox.FormattingEnabled = True
        Me.FollowComboBox.Items.AddRange(New Object() {"http", "wap", "client", "随机"})
        Me.FollowComboBox.Location = New System.Drawing.Point(196, 12)
        Me.FollowComboBox.Name = "FollowComboBox"
        Me.FollowComboBox.Size = New System.Drawing.Size(69, 20)
        Me.FollowComboBox.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(161, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 12)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "关注"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(71, 138)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(53, 12)
        Me.LinkLabel2.TabIndex = 22
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "获取更新"
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(402, 173)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.FollowComboBox)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.DelayNumeric)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.FollowNumeric)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.StartNumeric)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TrNumeric)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ChooseButton)
        Me.Controls.Add(Me.FITextBox)
        Me.Controls.Add(Me.TargetTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "刷粉机·绝影II - 飞龙"
        CType(Me.TrNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StartNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FollowNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DelayNumeric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TargetTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FITextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ChooseButton As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TrNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents StartNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents FollowNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DelayNumeric As System.Windows.Forms.NumericUpDown
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Public WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents FollowComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel

End Class
