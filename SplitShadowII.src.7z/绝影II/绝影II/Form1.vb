﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Text.RegularExpressions
Imports System.Security.Cryptography
Imports 绝影II.MyFunctions

Public Class Form1
    Private NdStop As Boolean
    Private TrNum As Integer
    Private StartIndex As Integer
    Private EndIndex As Integer
    Private Delay As Integer
    Private Success As Integer
    Private IDList As New List(Of ID)
    Private IDUbd As Integer = -1
    Private Target As String
    Private EndCount As Integer
    'v0.4新增：
    Private FollowType As Integer '0:http 1:wap 2:android

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click
        NdStop = True
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "用户停止任务，请等待当前线程结束！")
    End Sub

    Private Sub TrEnd()
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine(Time() + "任务完成，共用" + Str(EndIndex - StartIndex + 1) + "个马甲刷粉，成功" + Str(Success) + "个。")
        StartButton.Enabled = True
        StopButton.Enabled = False
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then '若拖放进来的对象是文件  
            e.Effect = DragDropEffects.All '改变拖放操作的行为，使对象可以被复制或移动至列表视图框  
        End If
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles MyBase.DragDrop
        For Each sFile As String In e.Data.GetData(DataFormats.FileDrop) '将拖放进来的文件添加至列表视图框  
            If sFile.EndsWith(".txt") Or sFile.EndsWith(".icid") Or sFile.EndsWith("idix") Then
                FITextBox.Text = sFile
                ReadMJ(sFile)
            End If
        Next
    End Sub

    Private Sub ChooseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChooseButton.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            FITextBox.Text = OpenFileDialog1.FileName
            ReadMJ(OpenFileDialog1.FileName)
        End If
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        Try
            StartButton.Enabled = False
            '设置检查
            If TargetTextBox.Text = "" Then
                Throw New Exception("请输入目标！")
            End If
            If IDUbd = -1 Then
                Throw New Exception("无可用马甲！")
            End If
            '参数初始化 开始停止位置均为在数组中的下标 线程数为原值
            Target = TargetTextBox.Text
            TrNum = TrNumeric.Value
            StartIndex = StartNumeric.Value - 1
            EndIndex = StartIndex + FollowNumeric.Value - 1
            Delay = DelayNumeric.Value
            NdStop = False
            Success = 0
            EndCount = TrNum
            ProgressBar1.Value = 0
            'v0.4新增：聚合初始化方式
            FollowType = FollowComboBox.SelectedIndex
            '总数判断
            If EndIndex > IDUbd Then
                Console.ForegroundColor = ConsoleColor.Yellow
                Console.WriteLine(Time() + "超出关注数量，已重置！")
                EndIndex = IDUbd
            End If
            If StartIndex > IDUbd Then
                StartIndex = 0
            End If
            ProgressBar1.Maximum = EndIndex - StartIndex + 1
            '启动线程
            For i As Integer = 0 To TrNum - 1
                Dim tr As New Thread(AddressOf Follow)
                tr.Start(i)
            Next i
            StopButton.Enabled = True
        Catch ex As Exception
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine(Time() + ex.Message)
            StartButton.Enabled = True
        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://sighttp.qq.com/msgrd?v=3&uin=562826179&site=%c8%d9%c8%d9%c8%ed%bc%fe&menu=yes")
    End Sub

    Private Sub ReadMJ(ByVal filename As String)
        IDList.Clear()
        Dim sr As New StreamReader(filename, Encoding.Default)
        Dim tmp As String() = Split(sr.ReadToEnd(), vbCrLf)
        sr.Close()
        For i As Integer = 0 To tmp.Length - 1
            Dim left As Integer = tmp(i).IndexOf(",")
            If left = -1 Then Continue For
            Dim un As String = tmp(i).Substring(1, left - 1)
            If un = "" Then Continue For
            Dim right As Integer = tmp(i).IndexOf(")", left)
            If right = -1 Then Continue For
            Dim pw As String = tmp(i).Substring(left + 1, right - left - 1)
            Dim cookie As String = tmp(i).Substring(right + 2, tmp(i).Length - right - 3)
            Dim tmpid As New ID With {.UN = un, .PW = pw, .Cookie = cookie}
            IDList.Add(tmpid)
        Next
        IDUbd = IDList.Count - 1
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine(Time() + "导入马甲成功，共读入{0}个马甲。", IDUbd + 1)
    End Sub

    Private Sub Follow(ByVal TrIndex As Integer) '合并后的多线程刷粉
        TrIndex += StartIndex     ' 由序号转化成马甲列表中的下标
        For i As Integer = TrIndex To EndIndex Step TrNum
            If NdStop Then Exit For
            Try
                ProgressBar1.PerformStep()
                ' 登录
                Dim cookie As String = IDList(i).Cookie
                Dim re As New Regex("BDUSS=.{192}")
                Dim rm As Match = re.Match(cookie)
                If Not rm.Success Then Throw New Exception("Cookie格式错误！")
                cookie = rm.Value
                '获取参数
                Dim wc As New WizardHTTP
                wc.SetDefaultHeader()
                wc.Headers.Set(HttpRequestHeader.Cookie, cookie) '必须带cookie
                Dim retstream As String = wc.DownloadString("http://tieba.baidu.com/i/sys/user_json?un=" + URLEncoGBK(Target))
                'id
                Dim left As Integer = InStr(retstream, "id"":") + 4
                Dim right As Integer = InStr(left, retstream, ",")
                Dim id As String = Mid(retstream, left, right - left)
                'portrait
                left = InStr(retstream, "portrait") + 11
                right = InStr(left, retstream, """")
                Dim portrait As String = Mid(retstream, left, right - left)
                'tbs
                left = InStr(retstream, "tbs"":") + 6
                right = InStr(left, retstream, """")
                Dim tbs As String = Mid(retstream, left, right - left)

                '发送请求
                Dim is_succeed As Boolean = False
                Dim lasterror As String = ""
                wc = New WizardHTTP
                Select Case FollowType
                    Case 3 'Random
                        Dim ran As New Random()
                        Dim iran As Integer = ran.Next(1, 3)
                        If iran = 1 Then
                            GoTo Label_HTTP
                        ElseIf iran = 2 Then
                            GoTo Label_WAP
                        Else
                            GoTo Label_Client
                        End If
                        Exit Select
                    Case 0 'http
Label_HTTP:             Dim stamp As String = GetStamp() 'stamp
                        Dim poststr = "cmd=follow&tbs=" + tbs + "&portrait=" + portrait
                        wc.SetDefaultHeader()
                        wc.Headers.Set(HttpRequestHeader.Cookie, cookie)
                        retstream = wc.UploadString("http://tieba.baidu.com/i/commit?stamp=" + stamp, poststr)
                        left = InStr(retstream, "error_no") + 10
                        right = InStr(left, retstream, ",")
                        Dim errno As String = Mid(retstream, left, right - left)
                        If errno = "0" Then
                            is_succeed = True
                        Else
                            is_succeed = False
                            left = retstream.IndexOf("_info") + 8
                            right = retstream.IndexOf("""", left)
                            Dim errmsg As String = retstream.Substring(left, right - left)
                            lasterror = UnicodeDeco(errmsg)
                        End If
                        Exit Select
                    Case 1 'wap
Label_WAP:              wc.SetDefaultHeader()
                        wc.Encoding = Encoding.UTF8
                        wc.Headers.Set(HttpRequestHeader.Cookie, cookie)
                        retstream = wc.DownloadString("http://wapp.baidu.com/i/" + id + "?op=follow&it=2&portrait=" + portrait + "&pn=&rop=2&lp=7002&tbs=" + tbs + "&ssid=0&from=0&uid=&pu=&bd_page_type=1&pinf=")
                        left = InStr(retstream, "<div>") + 5
                        right = InStr(left, retstream, "<br/>")
                        Dim tmp As String = Mid(retstream, left, right - left)
                        If tmp.IndexOf("关注成功") <> -1 Then
                            is_succeed = True
                        Else
                            is_succeed = False
                            lasterror = tmp
                        End If
                        Exit Select
                    Case Else 'android
Label_Client:           wc.SetDefaultHeaderAdr()
                        wc.Headers.Set(HttpRequestHeader.Cookie, cookie)
                        Dim poststr As String = cookie + "&_client_id=" + GetStampAndroid() + "&_client_type=2&_client_version=1.0.1&_phone_imei=000000000000000&from=tieba&net_type=1&portrait=" + portrait + "&tbs=" + tbs
                        Dim sign As String = MD5Encrypt(poststr.Replace("&", "") + "tiebaclient!!!", Encoding.UTF8)
                        poststr += "&sign=" + sign
                        retstream = wc.UploadString("http://c.tieba.baidu.com/c/c/user/follow", poststr)
                        left = InStr(retstream, "error_code") + 12
                        right = InStr(left, retstream, ",")
                        Dim errcode As String = Mid(retstream, left, right - left)
                        If errcode = "0" Then
                            is_succeed = True
                        Else
                            is_succeed = False
                            left = retstream.IndexOf("error_msg") + 12
                            right = retstream.IndexOf("""", left)
                            Dim errmsg As String = retstream.Substring(left, right - left)
                            lasterror = UnicodeDeco(errmsg)
                        End If
                        Exit Select
                End Select
                If is_succeed Then
                    Console.ForegroundColor = ConsoleColor.Green
                    Console.WriteLine(Time() + IDList(i).UN + " 关注成功！")
                    Success = Success + 1
                Else
                    Console.ForegroundColor = ConsoleColor.Red
                    Console.WriteLine(Time() + IDList(i).UN + " 关注失败！" + lasterror)
                End If
                Thread.Sleep(Delay)
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine(Time() + ex.Message)
            End Try
        Next i
        EndCount -= 1
        If EndCount = 0 Then
            Dim tr As New Thread(AddressOf TrEnd)
            tr.Start()
        End If
    End Sub

    Public Sub New()

        ' 此调用是设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        FollowComboBox.SelectedIndex = 0
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.258ch.com/forum-48-1.html")
    End Sub
End Class